#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int
main(){
    setregid(getegid(), getegid());
    system("/bin/sh");

    return 0;
}
