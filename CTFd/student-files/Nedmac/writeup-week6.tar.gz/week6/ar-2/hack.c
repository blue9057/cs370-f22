#include <unistd.h>
#include <stdlib.h>

int main(){

    setregid(getegid(), getegid());
    system("sh");
}
