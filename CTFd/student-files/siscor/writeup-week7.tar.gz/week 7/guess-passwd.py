#!/usr/bin/env python

from pwn import *
import time
charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'
saved = 0
best = ''
buf = ''
while True:
        for char1 in charset:
                p = process('./guess-passwd')
                p.recv()
                p.sendline(buf + char1)
                t1 = time.time()
                p.readline()
                t2 = time.time()
                total = t2-t1
                p.close()
                if total > saved:
                        saved = total
                        best = char1
        buf += best
        saved = 0
        best = ''
        print(buf)
        sleep(0.1)