#!/bin/bash

mv flag holder

mv flag2 flag
