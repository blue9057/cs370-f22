#!/usr/bin/env python
from pwn import *


p = process('./2048')
while True:
        p.sendline('t')
        p.interactive()