#!/usr/bin/env python
from pwn import *
import time

pwnchar = '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
'''
for i in range(0, 62):
    p = process('./guess-passwd')
    first = pwnchar[i]
    payload = "sW33tC4ndYiSf0rcAND" + first
    print(payload)
    t1 = time.time()
    p.sendline(payload)
    data = p.recvuntil("!")
    t2 = time.time()
    time_diff = t2 - t1
    print(time_diff)
    if (time_diff > 0.02 * 19):
        print("congrats")
        print("i")
        break
'''
p = process('./guess-passwd')

print("-------------------")

payload = 'sW33tC4ndYiSf0rcAND'

p.sendline(payload)

p.interactive()
