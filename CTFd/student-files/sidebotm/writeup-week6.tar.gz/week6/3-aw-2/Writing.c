int main(){
    execl("/bin/sh", 0, 0);
}
