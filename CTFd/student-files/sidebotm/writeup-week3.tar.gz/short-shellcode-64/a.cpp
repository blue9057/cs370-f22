#include <iostream>

using namespace std;

int a_to_i(char c){
    return (int) c;
}

int main(){
    cout << "C is " << a_to_i('C') << endl;
}
