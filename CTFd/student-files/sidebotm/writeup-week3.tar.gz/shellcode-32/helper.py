from pwn import *

print(hex("/bin/sh"))
