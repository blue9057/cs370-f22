#! /bin/sh
cat flag > /home/users/sidebotm-go/week7/0-run-command/my-flag.txt
