#!/usr/bin/env python

import os

while True:
    os.unlink("a")
    with open("a", "w"):
        pass
    #os.unlink("a")
    #os.symlink("testfile", "a")
    os.unlink("a")
    os.symlink("flag", "a")
