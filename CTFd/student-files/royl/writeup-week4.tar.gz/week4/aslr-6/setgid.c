#include <unistd.h>

int main() {
    gid_t gid[3];
    getresgid(&gid[0], &gid[1], &gid[2]);
    setregid(gid[0], gid[2]);
    setregid(gid[2], gid[2]);

    printf("gid: %d, %d, %d\n", gid[0], gid[1], gid[2]);
    getresgid(&gid[0], &gid[1], &gid[2]);
    printf("gid: %d, %d, %d\n", gid[0], gid[1], gid[2]);

    execve("/bin/bash", NULL, NULL);
}
