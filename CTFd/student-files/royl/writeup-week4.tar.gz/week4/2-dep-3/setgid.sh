# Load bash FFI (https://github.com/taviso/ctypes.sh)
source ctypes.sh

dlcall -r pointer malloc 12
gid_ptr=${DLRETVAL##*:}
dlcall -r int getresgid pointer:$gid_ptr pointer:`printf "0x%x" $((gid_ptr + 4))` pointer:`printf "0x%x" $((gid_ptr + 8))`
gid=(int int int)
unpack pointer:$gid_ptr gid

dlcall -r int setregid "${gid[1]}" "${gid[2]}"
dlcall -r int setregid "${gid[2]}" "${gid[2]}"
