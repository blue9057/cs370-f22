#include <unistd.h>


int main(){
	setregid(getegid(), getegid());
	execve("/bin/sh", NULL, NULL);
}

