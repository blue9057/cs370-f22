#include <unistd.h>


int main(){
	setregid(getregid(), getregid());
	execve("/bin/sh", NULL, NULL);
}

