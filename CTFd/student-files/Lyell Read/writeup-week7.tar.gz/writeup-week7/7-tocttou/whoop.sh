#!/bin/bash

rm ./flag
ln -s /home/labs/week7/7-tocttou/flag ./flag
