#!/bin/bash

rm ./flag
echo "eep" > ./flag
