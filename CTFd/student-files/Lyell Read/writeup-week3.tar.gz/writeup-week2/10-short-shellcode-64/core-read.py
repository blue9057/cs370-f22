#!/usr/bin/env python

from pwn import *
import os

c = Core("./core")
shellcode_address = c.stack.find("\x90\x90\x90\x90")
print(hex(shellcode_address))