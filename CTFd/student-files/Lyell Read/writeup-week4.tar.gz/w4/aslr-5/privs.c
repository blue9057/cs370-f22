#define _GNU_SOURCE
#include <unistd.h>
#include <stdio.h>

int main(){

	gid_t rgid;
	gid_t egid;
	gid_t sgid;
	getresgid(&rgid, &egid, &sgid);
        setregid(egid, sgid);
        setregid(sgid, sgid);
	printf("r%d, e%d, s%d", rgid, egid, sgid);
	//setregid(50412, 50412);
        execve("/bin/sh", NULL, NULL);
	printf("r%d, e%d, s%d", rgid, egid, sgid);

}

