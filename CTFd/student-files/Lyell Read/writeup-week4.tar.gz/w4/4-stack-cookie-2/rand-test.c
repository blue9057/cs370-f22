#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>


int main(int argc, char** argv, char** envp) {
  srand((unsigned int)time(0));
  int j;
  while (1){
    j = rand();
    printf("%d\n", j);
  }
  return 0;
}

