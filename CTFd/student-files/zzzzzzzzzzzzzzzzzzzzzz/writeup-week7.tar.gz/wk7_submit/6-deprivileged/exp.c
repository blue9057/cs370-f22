#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main() {
    printf("we got em\n");

    char buf[100] = {0};

    lseek(3, 0, SEEK_SET);

    read(3, buf, 100);
    buf[strcspn(buf, "\0")] = '\n';

    write(1, buf, 100);

    int fd = open("readthis", O_WRONLY);
    write(fd, buf, 100);
    close(fd);

    return 0;
}
