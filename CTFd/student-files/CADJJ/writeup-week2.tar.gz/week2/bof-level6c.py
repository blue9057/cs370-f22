#!/usr/bin/env python

from pwn import *

#p = process('./bof-levelx')
p = process('./bof-level6')

buf = "A" * 0x80
p.sendline(buf)

c=Core('./core')
print(hex(c.stack.find(buf)))

