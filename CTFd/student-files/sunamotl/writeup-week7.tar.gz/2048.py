In this challenge I noticed that there was an integer underflow vulnerability. And so,
sent a bad move, "1" until my points suddenly were 4294967295 instead of -1. I then 
proceeded to send a good move "a" resulting in the following message:
Got 4294967295! You are deserved to have a flag!cand{Int3g3r_Und3rfl0w}.
