mkfifo a #create named pipe that makes program 'wait' for input
Run program. Open another terminal. rm -f a (remove pipe). ln -s a flag (create symlink). "cat flag".

