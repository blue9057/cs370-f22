#include <unistd.h>
#include <stdlib.h>

int main(){
    setregid(getegid(), getegid());
    system("/bin/sh");

    return 0;
}
