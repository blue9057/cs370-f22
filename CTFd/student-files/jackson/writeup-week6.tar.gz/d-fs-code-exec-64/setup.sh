#!/bin/sh
export PATH=$PATH:`pwd`
