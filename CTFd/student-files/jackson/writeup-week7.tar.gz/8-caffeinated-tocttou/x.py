#!/usr/bin/env python

from pwn import *
from os import path

p = process('./caffeinated-tocttou')

p.sendline("myflag")

p.interactive()
