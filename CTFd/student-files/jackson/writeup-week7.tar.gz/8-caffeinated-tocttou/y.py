#!/usr/bin/env python

import os

while True:
    os.unlink("myflag")
    with open("myflag", "w"):
        pass
    os.unlink("myflag")
    os.symlink("flag", "myflag")
