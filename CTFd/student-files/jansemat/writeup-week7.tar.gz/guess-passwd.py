#!/usr/bin/env python
from pwn import *
import time

charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
passwd= ""
len = len("0000000000000000000")

for i in range(len):
    times = []
    for c in charset:
        p = process("./guess-passwd")
        p.recv()
        t1 = time.time()
        p.sendline(passwd + c)
        data = p.recv()
        t2 = time.time()
        diff = t2 - t1
        times.append((diff,c))
        p.close()

    times.sort()
    fastest = times[-1]
    f_char = fastest[1]
    passwd += f_char
    print(passwd)
print("///" + passwd)
